"use client";

import AdminCompactField from "@/components/admin/AdminCompactField";
import AdminDetailSectionNav from "@/components/admin/AdminDetailSectionNav";
import AdminInlineEmpty from "@/components/admin/AdminInlineEmpty";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import AdminPageShell from "@/components/admin/AdminPageShell";
import { adminSurface, adminTypography } from "@/components/admin/admin-typography";
import AsyncState from "@/components/system/AsyncState";
import { AdminSemanticBadge as SemanticBadge } from "@/components/admin/AdminSemanticBadge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { showErrorToast, showSuccessToast } from "@/lib/toast";
import { cn } from "@/lib/utils";
import type {
  AdminPackageDetailDto,
  AdminPackageOperationHistoryDto,
  AdminPackageUsageHistoryDto,
  AdminPackageUsageHistoryResponseDto,
} from "@/types/admin/packages";
import { format, isValid, parseISO } from "date-fns";
import {
  ArrowLeft,
  Calendar,
  CalendarPlus,
  ChevronRight,
  Clock,
  Copy,
  CreditCard,
  Edit3,
  History,
  Loader2,
  Mail,
  MapPin,
  Minus,
  Package as PackageIcon,
  Phone,
  Plus,
  RotateCcw,
  Target,
  User,
  User2,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { type MouseEvent as ReactMouseEvent, useEffect, useState } from "react";
import useSWR from "swr";

import PackageCurrentStatusSelect from "@/app/features/packages/components/PackageCurrentStatusSelect";
import {
  getAdminPackageActivationLabel,
  getAdminPackageActivationBadgeSpec,
  getAdminPackageAttentionBadgeSpec,
  getAdminPackageAttentionReasonLabel,
  getAdminPackagePaymentLabel,
  getAdminPackageUsageBadgeSpec,
  getAdminPackageUsageLabel,
} from "@/app/admin/packages/_lib/packagesPageConfig";
import { adminMutator } from "@/lib/admin/adminFetcher";
import { getPaymentStatusBadgeSpec } from "@/lib/badge-style";
import { authenticatedSWRFetcher } from "@/lib/fetchers/authenticatedSWRFetcher";
import {
  UNSAVED_CHANGES_MESSAGE,
  useUnsavedChangesGuard,
} from "@/lib/hooks/useUnsavedChangesGuard";
import { getCommonPaymentStatusLabel } from "@/lib/status-labels/base";

type PackageDetail = AdminPackageDetailDto;
type OperationsHistoryItem = AdminPackageOperationHistoryDto;

const toDateSafe = (v: string | Date | null | undefined) => {
  if (!v) return null;
  const d = typeof v === "string" ? parseISO(v) : v;
  return isValid(d) ? d : null;
};
const fmtKDate = (v: string | Date | null | undefined) => {
  const d = toDateSafe(v);
  return d ? format(d, "yyyy. MM. dd.") : "-";
};
const fmtDate = (v?: string | Date | null) => {
  if (!v) return "-";
  try {
    return new Intl.DateTimeFormat("ko-KR", { dateStyle: "medium" }).format(new Date(v));
  } catch {
    return String(v);
  }
};
const fmtDateTime = (v?: string | Date | null) => {
  if (!v) return "-";
  try {
    return new Intl.DateTimeFormat("ko-KR", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(new Date(v));
  } catch {
    return String(v);
  }
};
const getPackagePaymentDisplayLabel = (status?: string | null) =>
  getCommonPaymentStatusLabel(status) ?? status ?? "결제대기";

function ExtensionHistoryList({ items }: { items: OperationsHistoryItem[] }) {
  if (!items || items.length === 0)
    return <AdminInlineEmpty>운영 내역이 없습니다.</AdminInlineEmpty>;

  return (
    <ol className="relative ml-1">
      {items.map((it) => {
        const adminLabel = it.adminName || it.adminEmail || "관리자";

        // 유형 판별
        const isExtend =
          it.eventType === "extend_expiry" ||
          (typeof it.extendedDays === "number" && it.extendedDays !== 0);
        const isAdjust =
          it.eventType === "adjust_sessions" ||
          (typeof it.extendedSessions === "number" && it.extendedSessions !== 0);
        const isPayment = it.eventType === "payment_status_change" || !!it.paymentStatus;

        // 칩 텍스트
        const chips: string[] = [];
        if (isExtend)
          chips.push(`${it.extendedDays! > 0 ? "+" : ""}${it.extendedDays ?? 0}일 연장`);
        if (isAdjust)
          chips.push(
            `${it.extendedSessions! > 0 ? "+" : ""}${it.extendedSessions ?? 0}회 ${it.extendedSessions! >= 0 ? "증가" : "감소"}`,
          );
        if (isPayment && it.paymentStatus)
          chips.push(`결제상태: ${getPackagePaymentDisplayLabel(it.paymentStatus)}`);

        // 스타일 (점/헤더색)
        const dotCls = isPayment
          ? it.paymentStatus === "결제완료"
            ? "bg-primary"
            : it.paymentStatus === "결제취소" || it.paymentStatus === "취소"
              ? "bg-destructive"
              : "bg-muted"
          : isExtend
            ? "bg-primary"
            : it.extendedSessions! < 0
              ? "bg-destructive"
              : "bg-primary";

        const headTextCls = isPayment
          ? it.paymentStatus === "결제완료"
            ? "text-primary"
            : it.paymentStatus === "결제취소" || it.paymentStatus === "취소"
              ? "text-destructive"
              : "text-primary"
          : isExtend
            ? "text-primary"
            : it.extendedSessions! < 0
              ? "text-destructive"
              : "text-primary";

        return (
          <li key={it.id} className="pl-8 py-4 border-l border-border relative">
            <span className={`absolute -left-[7px] top-6 h-3 w-3 rounded-full ${dotCls} shadow`} />
            <div className={cn("flex items-center gap-2 text-sm", headTextCls)}>
              {isPayment ? (
                <CreditCard className="h-4 w-4" />
              ) : isExtend ? (
                <CalendarPlus className="h-4 w-4" />
              ) : (
                <Target className="h-4 w-4" />
              )}
              <span className="font-medium">{chips.length ? chips.join(" · ") : "운영 기록"}</span>
            </div>

            {isExtend
              ? (it.from || it.to) && (
                  <div className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
                    <span>{fmtDate(it.from ?? null)}</span>
                    <ChevronRight className="h-4 w-4" />
                    <span className="font-medium text-foreground">{fmtDate(it.to ?? null)}</span>
                  </div>
                )
              : (typeof it.from === "number" || typeof it.to === "number") && (
                  <div className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
                    <span>{typeof it.from === "number" ? `${it.from}회` : "-"}</span>
                    <ChevronRight className="h-4 w-4" />
                    <span className="font-medium text-foreground">
                      {typeof it.to === "number" ? `${it.to}회` : "-"}
                    </span>
                  </div>
                )}

            {it.reason && (
              <p className="mt-2 whitespace-pre-wrap text-[13px] leading-5">{it.reason}</p>
            )}

            <div className="mt-2 text-xs text-muted-foreground flex items-center gap-2">
              <User2 className="h-3.5 w-3.5" />
              <span>처리자: {adminLabel}</span>
              <span>·</span>
              <span>{fmtDateTime(it.date)}</span>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

export default function PackageDetailClient({ packageId }: { packageId: string }) {
  const router = useRouter();

  const [isEditMode, setIsEditMode] = useState(false);
  const [editingSessions, setEditingSessions] = useState(false);
  const [showExtensionForm, setShowExtensionForm] = useState(false);
  const [isSavingExtend, setIsSavingExtend] = useState(false);
  const [isSavingAdjust, setIsSavingAdjust] = useState(false);
  const [isSyncingNice, setIsSyncingNice] = useState(false);

  const [extensionData, setExtensionData] = useState({
    sessions: 0,
    days: 0,
    reason: "",
  });
  const [sessionAdjustment, setSessionAdjustment] = useState({
    amount: 0,
    reason: "",
  });

  const {
    data: resp,
    error,
    isLoading,
    mutate,
  } = useSWR<{ item: PackageDetail }>(
    `/api/admin/package-orders/${packageId}`,
    authenticatedSWRFetcher,
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    },
  );

  const data = resp?.item;
  const [usageHistory, setUsageHistory] = useState<AdminPackageUsageHistoryDto[]>([]);
  const [usageCursor, setUsageCursor] = useState<string | null>(null);
  const [usageHasMore, setUsageHasMore] = useState(false);
  const [usageLoading, setUsageLoading] = useState(false);
  const operationsHistory = Array.isArray(data?.operationsHistory)
    ? data!.operationsHistory
    : Array.isArray(data?.extensionHistory)
      ? data!.extensionHistory
      : [];

  const [opsLimit, setOpsLimit] = useState(5);
  useEffect(() => setOpsLimit(5), [data?.id]);

  const loadUsageHistory = async (append: boolean) => {
    if (!packageId || usageLoading) return;
    setUsageLoading(true);
    try {
      const query = new URLSearchParams({ limit: "10" });
      if (append && usageCursor) query.set("cursor", usageCursor);
      const res = await authenticatedSWRFetcher<AdminPackageUsageHistoryResponseDto>(
        `/api/admin/package-orders/${packageId}/usage-history?${query.toString()}`,
      );
      setUsageCursor(res.nextCursor ?? null);
      setUsageHasMore(Boolean(res.hasMore));
      setUsageHistory((prev) => (append ? [...prev, ...res.items] : res.items));
    } catch {
      showErrorToast("사용 내역 조회에 실패했습니다.");
    } finally {
      setUsageLoading(false);
    }
  };

  useEffect(() => {
    setUsageHistory([]);
    setUsageCursor(null);
    setUsageHasMore(false);
    void loadUsageHistory(false);
  }, [packageId]);

  /**
   * 입력 이탈 경고(Unsaved Changes Guard)
   * - 이 페이지에서 실제 “입력 폼”은 모달 2개(연장/횟수조절)
   */
  const isExtensionDirty =
    showExtensionForm && (extensionData.days > 0 || extensionData.reason.trim().length > 0);
  const isAdjustDirty =
    editingSessions &&
    (sessionAdjustment.amount !== 0 || sessionAdjustment.reason.trim().length > 0);
  const isDirty = isExtensionDirty || isAdjustDirty;
  useUnsavedChangesGuard(isDirty);

  const onLeaveListClick = (e: ReactMouseEvent<HTMLAnchorElement>) => {
    if (!isDirty) return;
    if (window.confirm(UNSAVED_CHANGES_MESSAGE)) return;
    e.preventDefault();
    e.stopPropagation();
  };

  // 최신순 정렬(내림차순)
  const operationsHistorySorted = [...operationsHistory].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
  );

  // 화면에 보여줄 슬라이스
  const visibleOps = operationsHistorySorted.slice(0, opsLimit);
  const opsHasMore = operationsHistorySorted.length > opsLimit;

  if (error) {
    return (
      <AdminPageShell>
        <AsyncState
          kind="error"
          tone="admin"
          variant="page-center"
          resourceName="패키지 상세"
          onAction={() => {
            void mutate();
          }}
        />
      </AdminPageShell>
    );
  }

  const isInitialLoading = isLoading && !data;
  if (!data) {
    if (isInitialLoading) {
      return (
        <AdminPageShell variant="wide">
          <div className="space-y-6">
            <div className="flex gap-4 flex-row items-center justify-between">
              <Skeleton className="h-9 w-56" />
              <div className="flex gap-2">
                <Skeleton className="h-9 w-24" />
                <Skeleton className="h-9 w-24" />
              </div>
            </div>
            <div className="grid gap-4 grid-cols-5">
              {Array.from({ length: 5 }).map((_, index) => (
                <Skeleton key={index} className="h-24 rounded-xl" />
              ))}
            </div>
            <div className="grid gap-6 grid-cols-2">
              <Skeleton className="h-[360px] rounded-xl" />
              <Skeleton className="h-[360px] rounded-xl" />
            </div>
          </div>
        </AdminPageShell>
      );
    }
    return (
      <AdminPageShell>
        <AsyncState
          kind="empty"
          tone="admin"
          variant="page-center"
          resourceName="패키지 상세"
          title="패키지 정보를 찾을 수 없습니다"
          description="패키지 ID를 확인한 뒤 다시 시도해 주세요."
        />
      </AdminPageShell>
    );
  }

  // 서버 읽기 모델을 그대로 사용해 상태와 작업 가능 여부를 표시합니다.
  const expiry = toDateSafe(data.expiryDate);
  const hasSessionCounts =
    typeof data.usedSessions === "number" &&
    Number.isFinite(data.usedSessions) &&
    typeof data.remainingSessions === "number" &&
    Number.isFinite(data.remainingSessions);
  const progressPercentage =
    typeof data.progressPercent === "number" && Number.isFinite(data.progressPercent)
      ? Math.round(data.progressPercent)
      : null;
  const operationCapabilities = data.operationCapabilities;
  const isNicePayment =
    String(data.paymentProvider ?? "")
      .trim()
      .toLowerCase() === "nicepay";

  const canExtendPackage = operationCapabilities.canExtend;
  const canAdjustSessions = operationCapabilities.canAdjustSessions;
  const areAllOperationsBlocked = !canExtendPackage && !canAdjustSessions;
  const hasReason = (reason: string) => data.attentionReasons.includes(reason as never);
  const packageGuide = hasReason("terminal_payment_with_live_pass")
    ? {
        title: "결제 종료 상태와 이용권 상태가 일치하지 않습니다",
        description:
          "결제는 실패·취소·환불 상태이지만 연결 이용권이 사용 가능하거나 일시정지 상태입니다. 결제사와 이용권 상태를 모두 확인하세요.",
        toneClass: "border-destructive/30 bg-destructive/10 text-destructive",
      }
    : hasReason("payment_failed")
      ? {
          title: "결제 실패 상태를 확인하세요",
          description: "결제사 승인 결과와 주문 상태를 확인하세요.",
          toneClass: "border-warning/30 bg-warning/10 text-warning",
        }
      : hasReason("payment_refunding")
        ? {
            title: "환불 진행 상태를 확인하세요",
            description: "환불 처리 결과와 연결 이용권 상태를 확인하세요.",
            toneClass: "border-warning/30 bg-warning/10 text-warning",
          }
        : hasReason("payment_unknown")
          ? {
              title: "결제 상태를 확인하세요",
              description: "결제사와 주문의 최신 결제 상태를 확인하세요.",
              toneClass: "border-warning/30 bg-warning/10 text-warning",
            }
          : hasReason("pass_issue_pending")
            ? {
                title: "패스 발급 상태를 확인하세요",
                description: "결제는 확인됐지만 연결 패스가 아직 발급되지 않았습니다.",
                toneClass: "border-warning/30 bg-warning/10 text-warning",
              }
            : hasReason("pass_unknown")
              ? {
                  title: "이용권 상태를 확인하세요",
                  description: "연결 이용권의 최신 상태를 확인하세요.",
                  toneClass: "border-warning/30 bg-warning/10 text-warning",
                }
              : data.usageState === "paused"
                ? {
                    title: "패키지권이 일시정지되어 있습니다",
                    description: "일시정지 사유와 재개 가능 여부를 확인하세요.",
                    toneClass: "border-warning/30 bg-warning/10 text-warning",
                  }
                : data.usageState === "expired"
                  ? {
                      title: "기간이 만료된 패키지입니다",
                      description: "연장 후 횟수 조절이 가능합니다.",
                      toneClass: "border-warning/30 bg-warning/10 text-warning",
                    }
                  : data.usageState === "exhausted"
                    ? {
                        title: "잔여 횟수가 없습니다",
                        description: "추가 이용이 필요하면 횟수 조절 또는 새 패키지를 안내하세요.",
                        toneClass: "border-warning/30 bg-warning/10 text-warning",
                      }
                    : data.usageState === "cancelled" ||
                        data.paymentState === "cancelled" ||
                        data.paymentState === "refunded"
                      ? {
                          title: "종료된 패키지입니다",
                          description: "결제와 이용권 상태를 확인하세요.",
                          toneClass: "border-destructive/30 bg-destructive/10 text-destructive",
                        }
                      : data.paymentState === "paid" &&
                          data.usageState === "available" &&
                          !data.requiresAttention
                        ? {
                            title: "정상 이용 가능한 패키지입니다",
                            description: "사용 이력과 신청서 연결 상태를 확인하세요.",
                            toneClass: "border-primary/20 bg-primary/5 text-foreground",
                          }
                        : {
                            title: "최신 상태를 확인하세요",
                            description: "결제·이용권·활성화 상태를 확인하세요.",
                            toneClass: "border-warning/30 bg-warning/10 text-warning",
                          };

  const adjustedRemainingPreview =
    typeof data.remainingSessions === "number" && Number.isFinite(data.remainingSessions)
      ? Math.max(0, data.remainingSessions + sessionAdjustment.amount)
      : null;

  const currentExpiryDate = data?.expiryDate ? new Date(data.expiryDate) : null;
  const baseForPreview = ((): Date => {
    const now = new Date();
    return currentExpiryDate && currentExpiryDate > now ? currentExpiryDate : now;
  })();
  const previewExpiryDate =
    extensionData.days > 0
      ? new Date(baseForPreview.getTime() + extensionData.days * 86400000)
      : null;

  // 액션
  const handleExtension = async () => {
    if (isSavingExtend) return;
    if (extensionData.days <= 0) return showErrorToast("연장할 일수를 입력해주세요.");
    if (!extensionData.reason.trim()) return showErrorToast("연장 사유를 입력해주세요.");

    setIsSavingExtend(true);
    try {
      await adminMutator(`/api/admin/package-orders/${packageId}/extend`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: "days",
          days: extensionData.days,
          reason: extensionData.reason,
        }),
      });
      await mutate();
      showSuccessToast("패키지가 연장되었습니다.");
      setShowExtensionForm(false);
      setExtensionData({ sessions: 0, days: 0, reason: "" });
    } catch (e: unknown) {
      showErrorToast(e instanceof Error ? e.message : "연장 중 오류가 발생했습니다.");
    } finally {
      setIsSavingExtend(false);
    }
  };

  // 횟수 조절 처리
  const handleSessionAdjustment = async () => {
    if (isSavingAdjust) return;
    if (sessionAdjustment.amount === 0) return showErrorToast("조절할 횟수를 입력해주세요.");
    if (!sessionAdjustment.reason.trim()) return showErrorToast("조절 사유를 입력해주세요.");

    setIsSavingAdjust(true);
    try {
      await adminMutator(`/api/admin/package-orders/${packageId}/adjust-sessions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          delta: sessionAdjustment.amount,
          clampZero: true,
          reason: sessionAdjustment.reason,
        }),
      });
      await mutate();
      showSuccessToast("횟수가 조절되었습니다.");
      setEditingSessions(false);
      setSessionAdjustment({ amount: 0, reason: "" });
    } catch (e: unknown) {
      showErrorToast(e instanceof Error ? e.message : "횟수 조절 중 오류가 발생했습니다.");
    } finally {
      setIsSavingAdjust(false);
    }
  };

  const handleNiceSync = async () => {
    if (isSyncingNice) return;
    setIsSyncingNice(true);
    try {
      const json = await adminMutator<{ success?: boolean; error?: string }>(
        `/api/admin/payments/nice/package/sync/${packageId}`,
        { method: "POST" },
      );
      if (!json?.success) {
        throw new Error(json?.error || "PG 상태 재동기화에 실패했습니다.");
      }
      await mutate();
      showSuccessToast("NicePay 상태 재동기화를 완료했습니다.");
    } catch (e: any) {
      showErrorToast(e?.message || "PG 상태 재동기화 중 오류가 발생했습니다.");
    } finally {
      setIsSyncingNice(false);
    }
  };

  return (
    <AdminPageShell variant="wide" className="space-y-4">
      {isLoading ? (
        <div className="mb-4 rounded-lg border border-border bg-muted/20 px-4 py-2 text-sm text-muted-foreground">
          최신 상태를 확인하고 있습니다...
        </div>
      ) : null}
      <AdminPageHeader
        variant="detail"
        title={`패키지 ${data.id.slice(0, 8)}…${data.id.slice(-6)}`}
        description="결제 상태, 이용 횟수, 만료일과 패키지 운영 이력을 확인하고 관리합니다."
        icon={PackageIcon}
        scope={`패키지 ID: ${data.id}`}
        helperText="결제·이용권·활성화 상태를 함께 확인한 뒤 운영 작업을 진행하세요."
        className="flex-wrap"
        actions={<>
          <SemanticBadge
            tone={
              getPaymentStatusBadgeSpec(getAdminPackagePaymentLabel(data.paymentState)).tone
            }
          >
            결제 {getAdminPackagePaymentLabel(data.paymentState)}
          </SemanticBadge>
          <SemanticBadge {...getAdminPackageUsageBadgeSpec(data.usageState)}>
            이용권 {getAdminPackageUsageLabel(data.usageState)}
          </SemanticBadge>
          <SemanticBadge {...getAdminPackageActivationBadgeSpec(data.activationState)}>
            활성화 {getAdminPackageActivationLabel(data.activationState)}
          </SemanticBadge>
          <Button type="button" variant="ghost" size="sm" onClick={() => {
            navigator.clipboard.writeText(data.id);
            showSuccessToast("패키지 ID가 복사되었습니다.");
          }}>
            <Copy className="mr-1 h-3.5 w-3.5" />패키지 ID 복사
          </Button>
          <Button asChild variant="outline" size="sm">
            <Link href="/admin/packages" data-no-unsaved-guard onClick={onLeaveListClick}>
              <ArrowLeft className="mr-2 h-4 w-4" />목록으로
            </Link>
          </Button>
          <Button variant={isEditMode ? "destructive" : "outline"} size="sm" onClick={() => setIsEditMode((v) => !v)}>
            <Edit3 className="mr-1 h-4 w-4" />{isEditMode ? "편집 취소" : "편집 모드"}
          </Button>
        </>}
      />

      <AdminDetailSectionNav
        items={[
          { href: "#admin-package-next-action", label: "다음 처리" },
          { href: "#admin-package-payment", label: "상태·결제정보" },
          { href: "#admin-package-customer", label: "고객정보" },
          { href: "#admin-package-usage-history", label: "사용 내역" },
          { href: "#admin-package-operation-history", label: "운영 이력" },
        ]}
      />

        {/* 요약 KPI */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
          <div className={adminSurface.kpiCard}>
            <div className="flex items-center gap-2 mb-1.5">
              <PackageIcon className="h-4 w-4 text-muted-foreground" />
              <span className={adminTypography.caption}>패키지 유형</span>
            </div>
            <p className={adminTypography.kpiValueCompact}>{data.packageType}</p>
          </div>

          <div className={adminSurface.kpiCard}>
            <div className="flex items-center gap-2 mb-1.5">
              <Target className="h-4 w-4 text-muted-foreground" />
              <span className={adminTypography.caption}>남은 횟수</span>
            </div>
            <p className={adminTypography.kpiValueCompact}>
              {!data.hasIssuedPass
                ? "미발급"
                : typeof data.remainingSessions === "number" &&
                    Number.isFinite(data.remainingSessions)
                  ? `${data.remainingSessions}회`
                  : "확인 필요"}
            </p>
          </div>

          <div className={adminSurface.kpiCard}>
            <div className="flex items-center gap-2 mb-1.5">
              <CreditCard className="h-4 w-4 text-muted-foreground" />
              <span className={adminTypography.caption}>결제 금액</span>
            </div>
            <p className={adminTypography.kpiValueCompact}>
              {typeof data.price === "number" && Number.isFinite(data.price)
                ? new Intl.NumberFormat("ko-KR", { style: "currency", currency: "KRW" }).format(
                    data.price,
                  )
                : "금액 확인 필요"}
            </p>
          </div>

          <div className={adminSurface.kpiCard}>
            <div className="flex items-center gap-2 mb-1.5">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <span className={adminTypography.caption}>만료일</span>
            </div>
            <p className={adminTypography.kpiValueCompact}>
              {!data.hasIssuedPass ? "미발급" : data.expiryDate ? fmtKDate(expiry) : "확인 필요"}
            </p>
          </div>
          <div className={adminSurface.kpiCard}>
            <div className="flex items-center gap-2 mb-1.5">
              <CreditCard className="h-4 w-4 text-muted-foreground" />
              <span className={adminTypography.caption}>결제 상태</span>
            </div>
            <SemanticBadge
              tone={
                getPaymentStatusBadgeSpec(getAdminPackagePaymentLabel(data.paymentState)).tone
              }
            >
              {getAdminPackagePaymentLabel(data.paymentState)}
            </SemanticBadge>
          </div>
        </div>

      <Card id="admin-package-next-action" className={packageGuide.toneClass}>
        <CardContent className="p-4">
          <div>
              <p className="text-sm font-semibold">{packageGuide.title}</p>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                {packageGuide.description}
              </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        {/* 고객 정보 */}
        <Card id="admin-package-customer" className={cn(adminSurface.card, "overflow-hidden")}>
          <CardHeader className="border-b border-border/60 bg-background/70">
            <CardTitle className={cn("flex items-center gap-2", adminTypography.sectionTitle)}>
              <User className="h-5 w-5 text-foreground" />
              고객 정보
            </CardTitle>
            <CardDescription>구매자 연락처와 서비스 유형을 분리해 확인합니다.</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <AdminCompactField
                label={
                  <span className="inline-flex items-center gap-1.5">
                    <User className="h-4 w-4" />
                    이름
                  </span>
                }
                value={data.customer.name}
                emptyValue="이름 없음"
              />
              <AdminCompactField
                label={
                  <span className="inline-flex items-center gap-1.5">
                    <Mail className="h-4 w-4" />
                    이메일
                  </span>
                }
                value={data.customer.email}
                valueClassName="break-all"
              />
              <AdminCompactField
                label={
                  <span className="inline-flex items-center gap-1.5">
                    <Phone className="h-4 w-4" />
                    전화번호
                  </span>
                }
                value={data.customer.phone}
              />
              <AdminCompactField
                label={
                  <span className="inline-flex items-center gap-1.5">
                    <MapPin className="h-4 w-4" />
                    서비스 유형
                  </span>
                }
                value={data.serviceType}
              />
            </div>
          </CardContent>
        </Card>

        {/* 패키지 상태 */}
        <Card id="admin-package-payment" className={adminSurface.card}>
          <CardHeader className="border-b border-border/60 bg-background/70">
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <PackageIcon className="h-5 w-5 text-primary" />
                패키지 상태
              </span>
              {isEditMode && <Edit3 className="h-4 w-4 text-muted-foreground" />}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-3">
            <div className="flex items-center justify-between p-3 rounded-lg bg-card">
              <span className="text-sm text-muted-foreground">이용권 상태</span>
              <SemanticBadge {...getAdminPackageUsageBadgeSpec(data.usageState)}>
                {getAdminPackageUsageLabel(data.usageState)}
              </SemanticBadge>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg bg-card">
              <span className="text-sm text-muted-foreground">통합 상태 변경</span>
              {data.legacyPassStatus && data.legacyPaymentStatus ? (
                <PackageCurrentStatusSelect
                  orderId={packageId}
                  passStatus={data.legacyPassStatus}
                  paymentStatus={data.legacyPaymentStatus}
                  onUpdated={() => mutate()}
                />
              ) : (
                <span className="text-xs text-muted-foreground">
                  현재 상태는 통합 상태 변경에서 지원하지 않습니다. 결제 상태와 이용권 상태를 각각
                  확인해 주세요.
                </span>
              )}
            </div>

            <p className="rounded-lg border border-warning/30 bg-warning/10 p-3 text-xs text-warning">
              이 상태 변경 기능은 현재 결제 상태와 연결 패스 상태를 함께 변경합니다. 조회 상태와
              별개의 운영 작업이므로 변경 전 결제사 및 이용권 상태를 확인하세요.
            </p>
            <div className="p-3 rounded-lg bg-card space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">결제 상태</span>
                <SemanticBadge
                  tone={
                    getPaymentStatusBadgeSpec(getAdminPackagePaymentLabel(data.paymentState)).tone
                  }
                >
                  {getAdminPackagePaymentLabel(data.paymentState)}
                </SemanticBadge>
              </div>
              {isNicePayment && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleNiceSync}
                  disabled={isSyncingNice}
                >
                  {isSyncingNice ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      PG 상태 동기화 중...
                    </>
                  ) : (
                    "PG 상태 다시 확인"
                  )}
                </Button>
              )}
            </div>

            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              <div className="rounded-lg bg-card p-3 text-sm">
                활성화 상태:{" "}
                <SemanticBadge {...getAdminPackageActivationBadgeSpec(data.activationState)}>
                  {getAdminPackageActivationLabel(data.activationState)}
                </SemanticBadge>
              </div>
              <div className="rounded-lg bg-card p-3 text-sm">
                운영 확인:{" "}
                <SemanticBadge {...getAdminPackageAttentionBadgeSpec(data.requiresAttention)}>
                  {data.requiresAttention ? "확인 필요" : "확인 완료"}
                </SemanticBadge>
                {data.requiresAttention && (
                  <ul className="mt-2 list-disc pl-4 text-xs">
                    {(data.attentionReasons.length > 0 ? data.attentionReasons : [null]).map(
                      (reason) => (
                        <li key={reason ?? "unknown"}>
                          {reason
                            ? getAdminPackageAttentionReasonLabel(reason)
                            : "운영 확인 사유 미확인"}
                        </li>
                      ),
                    )}
                  </ul>
                )}
              </div>
            </div>

            <div className="p-3 rounded-lg bg-card">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-muted-foreground">이용 진행률</span>
                <span className="text-sm font-medium">
                  {!data.hasIssuedPass
                    ? "패스 미발급"
                    : !hasSessionCounts || progressPercentage === null
                      ? "횟수 정보 확인 필요"
                      : `${progressPercentage}%`}
                </span>
              </div>
              {data.hasIssuedPass && hasSessionCounts && progressPercentage !== null && (
                <div className="w-full h-2 rounded-full bg-muted dark:bg-card">
                  <div
                    className="h-2 rounded-full bg-primary transition-all"
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>
              )}
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>
                  사용: {!data.hasIssuedPass || !hasSessionCounts ? "-" : `${data.usedSessions}회`}
                </span>
                <span>
                  남은:{" "}
                  {!data.hasIssuedPass
                    ? "미발급"
                    : !hasSessionCounts
                      ? "-"
                      : `${data.remainingSessions}회`}
                </span>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-card">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">만료까지</span>
                <span
                  className={cn(
                    "text-sm font-medium",
                    data.usageState === "expired"
                      ? "text-muted-foreground"
                      : data.isExpirySoon
                        ? "text-warning"
                        : "text-primary",
                  )}
                >
                  {!data.hasIssuedPass
                    ? "패스 미발급"
                    : !data.expiryDate
                      ? "만료일 확인 필요"
                      : data.usageState === "expired"
                        ? "만료됨"
                        : typeof data.daysUntilExpiry === "number"
                          ? `${data.daysUntilExpiry}일 남음`
                          : "만료일 확인 필요"}
                </span>
              </div>
            </div>

            <div className="rounded-lg border border-border/60 bg-background/70 px-3 py-2 text-xs text-muted-foreground">
              <span className="text-foreground">작업 가능 여부</span>
              <span className="ml-2">
                연장 {canExtendPackage ? "가능" : "불가"} · 횟수 조절{" "}
                {canAdjustSessions ? "가능" : "불가"} ·{" "}
                {hasSessionCounts
                  ? `총 ${data.usedSessions! + data.remainingSessions!}회`
                  : "총 횟수 확인 필요"}
              </span>
              {operationCapabilities.blockReasons.length > 0 && (
                <ul
                  className={cn(
                    "mt-2 space-y-1",
                    areAllOperationsBlocked ? "text-destructive" : "text-muted-foreground",
                  )}
                >
                  {operationCapabilities.blockReasons.map((reason) => (
                    <li key={reason}>• {reason}</li>
                  ))}
                </ul>
              )}
            </div>
          </CardContent>

          {isEditMode && (
            <CardFooter className="flex flex-wrap justify-center gap-2 bg-card">
              <Button
                variant="outline"
                size="sm"
                disabled={!canExtendPackage}
                onClick={() => setShowExtensionForm(true)}
                className="border-border hover:bg-primary/10 dark:hover:bg-primary/20"
              >
                <RotateCcw className="mr-1 h-4 w-4" />
                패키지 연장
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={!canAdjustSessions}
                onClick={() => setEditingSessions(true)}
                className="border-border hover:bg-muted dark:hover:bg-muted"
              >
                <Target className="mr-1 h-4 w-4" />
                횟수 조절
              </Button>
            </CardFooter>
          )}
        </Card>

        <Card
          id="admin-package-usage-history"
          className={cn(
            "border-border bg-card dark:bg-card dark:border-border xl:col-span-2",
            adminSurface.tableCard,
          )}
        >
          <CardHeader className="border-b border-border/60 bg-background/70">
            <CardTitle className="flex items-center gap-2">
              <History className="h-5 w-5 text-primary" />
              잔여 횟수/만료/사용 이력
            </CardTitle>
            <CardDescription>
              패키지 횟수가 차감된 신청서 목록과 현재 사용 흐름을 먼저 확인하세요.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-5">
            {usageHistory.length === 0 && !usageLoading ? (
              <AdminInlineEmpty>사용 내역이 없습니다.</AdminInlineEmpty>
            ) : (
              <div className="space-y-4">
                {usageHistory.map((u) => (
                  <div
                    key={u.id}
                    className="border rounded-lg p-4 transition-colors border-border bg-card hover:bg-background dark:border-border dark:bg-card dark:hover:bg-card"
                  >
                    <div className="flex items-start gap-3 flex-row justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <SemanticBadge tone="danger" size="sm">
                            -{u.sessionsUsed}회 차감
                          </SemanticBadge>
                        </div>
                        <p className="font-medium mb-1">{u.summary}</p>
                        <p className="text-sm text-muted-foreground">
                          {u.applicationSummary || `신청서 #${u.applicationId.slice(-6)}`}
                        </p>
                        {u.adminNote && (
                          <p className="text-sm text-foreground mt-1">관리자 메모: {u.adminNote}</p>
                        )}
                      </div>
                      <Button variant="ghost" size="sm" asChild>
                        <Link
                          href={`/admin/applications/stringing/${u.applicationId}`}
                          target="_blank"
                          rel="noreferrer"
                        >
                          상세 보기
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
                <div className="pt-2 flex justify-center">
                  {usageHasMore ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => void loadUsageHistory(true)}
                      disabled={usageLoading}
                    >
                      {usageLoading ? (
                        <>
                          <Loader2 className="mr-1 h-4 w-4 animate-spin" />
                          불러오는 중
                        </>
                      ) : (
                        "더보기"
                      )}
                    </Button>
                  ) : null}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 운영 내역 */}
        <Card
          id="admin-package-operation-history"
          className={cn("xl:col-span-2", adminSurface.tableCard)}
        >
          <CardHeader className="border-b border-border/60 bg-background/70">
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-foreground" />
              운영 내역 (연장/횟수)
            </CardTitle>
            <CardDescription>패키지 연장 및 횟수 조절 기록입니다.</CardDescription>
          </CardHeader>
          <CardContent className="p-5">
            <span className="text-xs text-muted-foreground">
              총 {operationsHistorySorted.length}건 (현재 {visibleOps.length}건 표시)
            </span>

            {operationsHistorySorted.length === 0 ? (
              <AdminInlineEmpty className="mt-3">운영 내역이 없습니다.</AdminInlineEmpty>
            ) : (
              <>
                <ExtensionHistoryList items={visibleOps} />
                <div className="pt-4 flex justify-center items-center gap-2">
                  {opsHasMore ? (
                    <Button variant="outline" size="sm" onClick={() => setOpsLimit((n) => n + 5)}>
                      더 보기
                    </Button>
                  ) : operationsHistorySorted.length > 5 ? (
                    <>
                      <p className="text-xs text-muted-foreground">마지막 페이지입니다.</p>
                      <Button variant="ghost" size="sm" onClick={() => setOpsLimit(5)}>
                        접기
                      </Button>
                    </>
                  ) : null}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* 연장 모달 */}
      {showExtensionForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-overlay/50">
          <Card className="w-full max-w-md mx-4 border-border dark:bg-card">
            <CardHeader>
              <CardTitle>패키지 연장</CardTitle>
              <CardDescription>
                고객의 이용 가능 기간이 변경됩니다. 연장 일수와 사유를 확인한 뒤 진행해주세요.
              </CardDescription>
            </CardHeader>
            <CardContent
              className={cn("space-y-4", isSavingExtend && "opacity-70 pointer-events-none")}
            >
              <div>
                <Label htmlFor="days">연장 일수</Label>
                <div className="mt-2 text-sm">
                  <span className="text-muted-foreground">현재 만료일:</span>{" "}
                  <span>{fmtDate(currentExpiryDate)}</span>
                  {previewExpiryDate && (
                    <>
                      <ChevronRight className="inline h-4 w-4 mx-1 text-muted-foreground" />
                      <span className="font-medium text-primary">{fmtDate(previewExpiryDate)}</span>
                    </>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      setExtensionData((p) => ({
                        ...p,
                        days: Math.max(0, p.days - 1),
                      }))
                    }
                    disabled={isSavingExtend || extensionData.days <= 0}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <Input
                    id="days"
                    inputMode="numeric"
                    pattern="[0-9,]*"
                    className="text-center"
                    disabled={isSavingExtend}
                    value={String(extensionData.days)}
                    onChange={(e) => {
                      const v = e.target.value.replace(/[^\d]/g, "");
                      setExtensionData((p) => ({
                        ...p,
                        days: v === "" ? 0 : Number(v),
                      }));
                    }}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setExtensionData((p) => ({ ...p, days: p.days + 1 }))}
                    disabled={isSavingExtend}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div>
                <Label htmlFor="ext-reason">연장 사유</Label>
                <Textarea
                  id="ext-reason"
                  rows={3}
                  placeholder="연장 사유를 입력하세요"
                  value={extensionData.reason}
                  onChange={(e) =>
                    setExtensionData((p) => ({
                      ...p,
                      reason: e.target.value,
                    }))
                  }
                  disabled={isSavingExtend}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setShowExtensionForm(false)}
                disabled={isSavingExtend}
              >
                취소
              </Button>
              <Button onClick={handleExtension} disabled={isSavingExtend}>
                {isSavingExtend ? (
                  <>
                    <Loader2 className="mr-1 h-4 w-4 animate-spin" /> 저장 중…
                  </>
                ) : (
                  "연장"
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}

      {/* 횟수 조절 모달 */}
      {editingSessions && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-overlay/50">
          <Card className="w-full max-w-md mx-4 border-border dark:bg-card">
            <CardHeader>
              <CardTitle>횟수 조절</CardTitle>
              <CardDescription>
                고객의 이용 가능 횟수가 변경됩니다. 변경 전/후 값과 사유를 확인한 뒤 진행해주세요.
              </CardDescription>
            </CardHeader>
            <CardContent
              className={cn("space-y-4", isSavingAdjust && "opacity-70 pointer-events-none")}
            >
              <div>
                <Label htmlFor="adjustment">조절 수량</Label>
                <p className="text-sm text-muted-foreground mt-1">
                  현재 남은 횟수:{" "}
                  {typeof data.remainingSessions === "number" &&
                  Number.isFinite(data.remainingSessions)
                    ? `${data.remainingSessions}회`
                    : "확인 필요"}
                  {adjustedRemainingPreview === null ? (
                    <span className="ml-2">현재 잔여 횟수를 확인할 수 없습니다.</span>
                  ) : (
                    sessionAdjustment.amount !== 0 && (
                      <span
                        className={cn(
                          "ml-2 font-medium",
                          sessionAdjustment.amount > 0 ? "text-primary" : "text-destructive",
                        )}
                      >
                        → {adjustedRemainingPreview}회
                      </span>
                    )
                  )}
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={isSavingAdjust}
                    onClick={() =>
                      setSessionAdjustment((p) => ({
                        ...p,
                        amount: p.amount - 1,
                      }))
                    }
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <Input
                    id="adjustment"
                    type="number"
                    className="text-center"
                    disabled={isSavingAdjust}
                    value={sessionAdjustment.amount}
                    onChange={(e) =>
                      setSessionAdjustment((p) => ({
                        ...p,
                        amount: Number.parseInt(e.target.value) || 0,
                      }))
                    }
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={isSavingAdjust}
                    onClick={() =>
                      setSessionAdjustment((p) => ({
                        ...p,
                        amount: p.amount + 1,
                      }))
                    }
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div>
                <Label htmlFor="adjust-reason">조절 사유</Label>
                <Textarea
                  id="adjust-reason"
                  rows={3}
                  placeholder="횟수 조절 사유를 입력하세요"
                  value={sessionAdjustment.reason}
                  onChange={(e) =>
                    setSessionAdjustment((p) => ({
                      ...p,
                      reason: e.target.value,
                    }))
                  }
                  disabled={isSavingAdjust}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => setEditingSessions(false)}
                disabled={isSavingAdjust}
              >
                취소
              </Button>
              <Button onClick={handleSessionAdjustment} disabled={isSavingAdjust}>
                {isSavingAdjust ? (
                  <>
                    <Loader2 className="mr-1 h-4 w-4 animate-spin" /> 저장 중…
                  </>
                ) : (
                  "조정"
                )}
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}
    </AdminPageShell>
  );
}
