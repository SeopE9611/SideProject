"use client";
import AdminPageSection from "@/components/admin/AdminPageSection";
import { adminSurface, adminTypography } from "@/components/admin/admin-typography";
import { TabsContent } from "@/components/ui/tabs";
import type { TabErrorState } from "@/types/admin/settings";

export function PaymentSettingsTab({
  error,
  paymentMeta,
}: {
  error: TabErrorState;
  paymentMeta: {
    nicepay: {
      provider: "NICEPay";
      enabled: boolean;
      mode: "sandbox" | "production" | "unknown";
      approveApiBase: string | null;
      hasClientId: boolean;
      hasSecretKey: boolean;
    };
  };
}) {
  const nicepayStatus = paymentMeta.nicepay.enabled ? "활성" : "비활성";
  const nicepayModeLabel =
    paymentMeta.nicepay.mode === "sandbox"
      ? "sandbox"
      : paymentMeta.nicepay.mode === "production"
        ? "production"
        : "확인 필요";

  return (
    <TabsContent value="payment">
      <AdminPageSection
        title="결제 설정"
        description="배포 환경에 설정된 실제 NICEPay 결제 연동 상태를 확인합니다."
      >
        {error.message && (
          <div
            className={`${adminSurface.cardMuted} px-3 py-2 ${adminTypography.body} text-destructive`}
          >
            {error.message}
          </div>
        )}
        <div className="space-y-4">
          <div className={`${adminSurface.cardMuted} space-y-2 p-4`}>
            <p className={adminTypography.panelTitle}>NICEPay 상태</p>
            <p className={adminTypography.body}>사용 PG: {paymentMeta.nicepay.provider}</p>
            <p className={adminTypography.body}>결제 기능 상태: {nicepayStatus}</p>
            <p className={adminTypography.body}>결제 모드: {nicepayModeLabel}</p>
            <p className={`${adminTypography.body} break-all`}>
              승인 API Base URL: {paymentMeta.nicepay.approveApiBase ?? "미설정"}
            </p>
            <p className={adminTypography.body}>
              Client ID 설정 여부: {paymentMeta.nicepay.hasClientId ? "설정됨" : "미설정"}
            </p>
            <p className={adminTypography.body}>
              Secret Key 설정 여부: {paymentMeta.nicepay.hasSecretKey ? "설정됨" : "미설정"}
            </p>
          </div>

          <div className={`${adminSurface.cardMuted} space-y-1 p-4`}>
            <p className={adminTypography.panelTitle}>운영 안내</p>
            <p className={adminTypography.metaMuted}>
              NICEPay 환경변수는 배포 환경(Vercel)에서 관리합니다.
            </p>
            <p className={adminTypography.metaMuted}>
              주문/대여/패키지 결제 동기화는 각 상세 페이지에서 수행됩니다.
            </p>
            <p className={adminTypography.metaMuted}>
              실제 결제 취소/환불은 각 도메인 상세 페이지의 승인 흐름에서 처리됩니다.
            </p>
          </div>
        </div>
      </AdminPageSection>
    </TabsContent>
  );
}
