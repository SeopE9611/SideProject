"use client";
import { Save } from "lucide-react";
import AdminPageSection from "@/components/admin/AdminPageSection";
import { adminSurface, adminTypography } from "@/components/admin/admin-typography";
import type { UseFormReturn } from "react-hook-form";
import { TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import type { UserSettings, TabErrorState } from "@/types/admin/settings";

export function UserSettingsTab({
  form,
  isBootstrapping,
  onSubmit,
  error,
}: {
  form: UseFormReturn<UserSettings>;
  isBootstrapping: boolean;
  onSubmit: (data: UserSettings) => void;
  error: TabErrorState;
}) {
  return (
    <TabsContent value="user">
      <AdminPageSection
        title="사용자 설정"
        description="현재 실제 회원가입 정책에 적용되는 설정만 표시합니다."
      >
        {error.message && (
          <div
            className={`${adminSurface.cardMuted} px-3 py-2 ${adminTypography.body} text-destructive`}
          >
            {error.message}
          </div>
        )}
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>회원가입 허용</Label>
              <Switch
                checked={form.watch("allowRegistration")}
                onCheckedChange={(v) =>
                  form.setValue("allowRegistration", v, { shouldDirty: true })
                }
              />
            </div>
            <div>
              <Label htmlFor="minimumPasswordLength">최소 비밀번호 길이</Label>
              <Input
                id="minimumPasswordLength"
                type="number"
                {...form.register("minimumPasswordLength", {
                  valueAsNumber: true,
                })}
              />
            </div>
          </div>
          <div className="mt-5 flex">
            <Button
              disabled={isBootstrapping || form.formState.isSubmitting}
              type="submit"
              className="ml-auto"
            >
              <Save className="mr-2 h-4 w-4" />
              설정 저장
            </Button>
          </div>
        </form>
      </AdminPageSection>
    </TabsContent>
  );
}
