"use client";

import { useEffect, useMemo, useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import {
  defaultEmailSettings,
  defaultUserSettings,
  emailSettingsSchema,
  userSettingsSchema,
} from "@/lib/admin-settings";
import { AdminFetchError, adminMutator } from "@/lib/admin/adminFetcher";
import { showErrorToast, showSuccessToast } from "@/lib/toast";
import { UNSAVED_CHANGES_MESSAGE } from "@/lib/hooks/useUnsavedChangesGuard";
import type {
  EmailSettings,
  SettingsApiResponse,
  SettingsTab,
  TabErrorState,
  UserSettings,
} from "@/types/admin/settings";

type NicepayMode = "sandbox" | "production" | "unknown";
type NicepayMeta = {
  provider: "NICEPay";
  enabled: boolean;
  mode: NicepayMode;
  approveApiBase: string | null;
  hasClientId: boolean;
  hasSecretKey: boolean;
};
type EmailSource = "database" | "environment" | "unconfigured";

const DEFAULT_NICEPAY_META: NicepayMeta = {
  provider: "NICEPay",
  enabled: false,
  mode: "unknown",
  approveApiBase: null,
  hasClientId: false,
  hasSecretKey: false,
};

const AUTH_ERROR_MESSAGES = {
  unauthorized: "로그인이 만료되었습니다. 다시 로그인 후 시도해주세요.",
  forbidden: "관리자 권한이 없어 이 설정을 변경할 수 없습니다.",
} as const;

export function useAdminSettings() {
  const [activeTab, setActiveTab] = useState<SettingsTab>("user");
  const [isBootstrapping, setIsBootstrapping] = useState(true);
  const [tabErrors, setTabErrors] = useState<Record<SettingsTab, TabErrorState>>({
    user: { type: null, message: "" },
    email: { type: null, message: "" },
    payment: { type: null, message: "" },
  });
  const [emailMeta, setEmailMeta] = useState<{
    hasSmtpPassword: boolean;
    source: EmailSource;
  }>({ hasSmtpPassword: false, source: "unconfigured" });
  const [isSendingTestEmail, setIsSendingTestEmail] = useState(false);
  const [paymentMeta, setPaymentMeta] = useState({ nicepay: DEFAULT_NICEPAY_META });
  const [pendingTab, setPendingTab] = useState<SettingsTab | null>(null);

  const userForm = useForm<UserSettings>({
    resolver: zodResolver(userSettingsSchema),
    defaultValues: defaultUserSettings,
  });
  const emailForm = useForm<EmailSettings>({
    resolver: zodResolver(emailSettingsSchema),
    defaultValues: defaultEmailSettings,
  });
  const dirtyByTab = useMemo(
    () => ({
      user: userForm.formState.isDirty,
      email: emailForm.formState.isDirty,
      payment: false,
    }),
    [userForm.formState.isDirty, emailForm.formState.isDirty],
  );

  const isDirtyAny = Object.values(dirtyByTab).some(Boolean);
  const isSubmittingAny = userForm.formState.isSubmitting || emailForm.formState.isSubmitting;

  const parseTabError = async (res: Response): Promise<TabErrorState> => {
    const payload = await res.json().catch(() => ({}));
    const message = payload?.message || "요청 처리에 실패했습니다.";
    if (res.status === 401)
      return {
        type: "unauthorized",
        message: AUTH_ERROR_MESSAGES.unauthorized,
      };
    if (res.status === 403) return { type: "forbidden", message: AUTH_ERROR_MESSAGES.forbidden };
    return { type: null, message };
  };

  const setTabError = (tab: SettingsTab, next: TabErrorState) =>
    setTabErrors((prev) => ({ ...prev, [tab]: next }));
  const clearTabError = (tab: SettingsTab) => setTabError(tab, { type: null, message: "" });

  const loadTab = async <T>(
    tab: SettingsTab,
    endpoint: string,
    onSuccess: (json: SettingsApiResponse<T>) => void,
  ) => {
    const res = await fetch(endpoint, {
      method: "GET",
      credentials: "include",
      cache: "no-store",
    });
    if (!res.ok) {
      const nextError = await parseTabError(res);
      setTabError(tab, nextError);
      throw new Error(nextError.message);
    }
    clearTabError(tab);
    onSuccess((await res.json()) as SettingsApiResponse<T>);
  };

  const readNicepayMeta = (meta: Record<string, unknown> | undefined): NicepayMeta => {
    const candidate = meta?.nicepay;
    if (!candidate || typeof candidate !== "object") return DEFAULT_NICEPAY_META;
    const raw = candidate as Record<string, unknown>;
    const mode = raw.mode;
    const safeMode: NicepayMode =
      mode === "sandbox" || mode === "production" || mode === "unknown" ? mode : "unknown";
    return {
      provider: "NICEPay",
      enabled: Boolean(raw.enabled),
      mode: safeMode,
      approveApiBase:
        typeof raw.approveApiBase === "string" && raw.approveApiBase.trim()
          ? raw.approveApiBase
          : null,
      hasClientId: Boolean(raw.hasClientId),
      hasSecretKey: Boolean(raw.hasSecretKey),
    };
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setIsBootstrapping(true);
      try {
        await Promise.all([
          loadTab(
            "user",
            "/api/admin/settings/user",
            (json) => !cancelled && userForm.reset(json.data ?? defaultUserSettings),
          ),
          loadTab("email", "/api/admin/settings/email", (json) => {
            if (cancelled) return;
            emailForm.reset(json.data ?? defaultEmailSettings);
            setEmailMeta({
              hasSmtpPassword: Boolean(json?.meta?.hasSmtpPassword),
              source:
                json?.meta?.source === "database" || json?.meta?.source === "environment"
                  ? json.meta.source
                  : "unconfigured",
            });
          }),
          loadTab("payment", "/api/admin/settings/payment", (json) => {
            if (cancelled) return;
            setPaymentMeta({
              nicepay: readNicepayMeta(json.meta),
            });
          }),
        ]);
      } catch {
        showErrorToast("일부 설정을 불러오지 못했습니다. 권한 또는 서버 상태를 확인해주세요.");
      } finally {
        if (!cancelled) setIsBootstrapping(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const saveTab = async (tab: SettingsTab, endpoint: string, payload: unknown) => {
    try {
      const json = await adminMutator<SettingsApiResponse<unknown>>(endpoint, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      clearTabError(tab);
      return json;
    } catch (error: unknown) {
      if (error instanceof AdminFetchError) {
        if (error.status === 401) {
          const nextError = {
            type: "unauthorized" as const,
            message: AUTH_ERROR_MESSAGES.unauthorized,
          };
          setTabError(tab, nextError);
          throw new Error(nextError.message);
        }
        if (error.status === 403) {
          const nextError = {
            type: "forbidden" as const,
            message: AUTH_ERROR_MESSAGES.forbidden,
          };
          setTabError(tab, nextError);
          throw new Error(nextError.message);
        }
      }
      throw error;
    }
  };

  const onSubmitUserSettings = async (data: UserSettings) => {
    try {
      const json = await saveTab("user", "/api/admin/settings/user", data);
      userForm.reset(json.data ?? data);
      showSuccessToast("사용자 설정이 저장되었습니다.");
    } catch (error: unknown) {
      showErrorToast(error instanceof Error ? error.message : "사용자 설정 저장에 실패했습니다.");
    }
  };

  const onSubmitEmailSettings = async (data: EmailSettings) => {
    try {
      const json = await saveTab("email", "/api/admin/settings/email", data);
      emailForm.reset(json.data ?? data);
      setEmailMeta({
        hasSmtpPassword: Boolean(json?.meta?.hasSmtpPassword),
        source:
          json?.meta?.source === "database" || json?.meta?.source === "environment"
            ? json.meta.source
            : "unconfigured",
      });
      showSuccessToast("이메일 설정이 저장되었습니다.");
    } catch (error: unknown) {
      showErrorToast(error instanceof Error ? error.message : "이메일 설정 저장에 실패했습니다.");
    }
  };

  const sendTestEmail = async () => {
    if (emailForm.formState.isDirty) {
      showErrorToast("변경한 이메일 설정을 먼저 저장해주세요.");
      return;
    }
    if (isSendingTestEmail) return;

    setIsSendingTestEmail(true);
    try {
      await adminMutator("/api/admin/settings/email/test", { method: "POST" });
      showSuccessToast("테스트 이메일이 발송되었습니다.");
    } catch (error: unknown) {
      showErrorToast(
        error instanceof Error ? error.message : "테스트 이메일 전송에 실패했습니다.",
      );
    } finally {
      setIsSendingTestEmail(false);
    }
  };

  const requestTabChange = (nextTab: string) => {
    if (!["user", "email", "payment"].includes(nextTab) || nextTab === activeTab) return;
    const currentDirty = (dirtyByTab as Record<string, boolean>)[activeTab] ?? false;
    if (currentDirty) {
      setPendingTab(nextTab as SettingsTab);
      return;
    }
    setActiveTab(nextTab as SettingsTab);
  };

  const confirmTabChange = () => {
    if (!pendingTab) return;
    setActiveTab(pendingTab);
    setPendingTab(null);
  };

  const cancelTabChange = () => {
    setPendingTab(null);
  };

  return {
    activeTab,
    pendingTab,
    requestTabChange,
    confirmTabChange,
    cancelTabChange,
    isBootstrapping,
    tabErrors,
    isDirtyAny,
    isSubmittingAny,
    userForm,
    emailForm,
    emailMeta,
    isSendingTestEmail,
    paymentMeta,
    onSubmitUserSettings,
    onSubmitEmailSettings,
    sendTestEmail,
  };
}

export { UNSAVED_CHANGES_MESSAGE };
