import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "관리자 설정",
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
