"use client";

import { BulkActionsSection } from "@/app/admin/users/_components/users-client/BulkActionsSection";
import { DialogsSection } from "@/app/admin/users/_components/users-client/DialogsSection";
import { FiltersSection } from "@/app/admin/users/_components/users-client/FiltersSection";
import { TableSection } from "@/app/admin/users/_components/users-client/TableSection";
import { UsersKpiCards } from "@/app/admin/users/_components/users-client/UsersKpiCards";
import { useUserList } from "@/app/admin/users/_hooks/useUserList";
import {
  STATUS,
  badgeSm,
  buildPageItems,
  fullAddress,
  roleColors,
  shortAddress,
  splitDateTime,
  type UserStatusKey,
} from "@/app/admin/users/_lib/usersClientUtils";
import { adminDataTable } from "@/components/admin/AdminDataTable";
import AdminFilterBar from "@/components/admin/AdminFilterBar";
import {
  AdminListBody,
  AdminListCell,
  AdminListColumnHeader,
  AdminListPrimary,
  AdminListRow,
  AdminListTable,
  AdminRowActions,
  AdminStatusGroup,
} from "@/components/admin/AdminListTable";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import AdminPageShell from "@/components/admin/AdminPageShell";
import AdminReferencePopover from "@/components/admin/AdminReferencePopover";
import AdminRowActionMenu from "@/components/admin/AdminRowActionMenu";
import { AdminSemanticBadge as Badge } from "@/components/admin/AdminSemanticBadge";
import { adminTypography } from "@/components/admin/admin-typography";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { runAdminActionWithToast } from "@/lib/admin/adminActionHelpers";
import { adminFetcher, adminMutator, getAdminErrorMessage } from "@/lib/admin/adminFetcher";
import { getUserRoleLabel, isAdminRole } from "@/lib/admin/roles";
import { useAdminListQueryState } from "@/lib/admin/useAdminListQueryState";
import { formatKoreanPhone } from "@/lib/phone";
import { showErrorToast, showInfoToast, showSuccessToast } from "@/lib/toast";
import { cn } from "@/lib/utils";
import type { UserCleanupPreviewCandidateDto } from "@/types/admin/users";
import {
  AlertCircle,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Filter,
  Loader2,
  Mail,
  Search,
  Trash2,
  UserCheck,
  UserX,
} from "lucide-react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

interface BulkActionResponse {
  message?: string;
  modifiedCount?: number;
  skipped?: {
    already?: string[];
    incompatible?: string[];
  };
}

interface AdminDeleteResponse {
  deletedCount?: number;
  message?: string;
  previewHash?: string;
}

interface SystemActionPreviewResponse {
  candidates?: unknown;
  previewHash?: string;
  requestHash?: string;
  confirmationToken?: string;
  reconfirmText?: string;
}

const asPreviewCandidates = (value: unknown): UserCleanupPreviewCandidateDto[] =>
  Array.isArray(value)
    ? value.map((item) => ({
        _id:
          typeof item === "object" && item && "_id" in item
            ? String((item as { _id?: unknown })._id ?? "")
            : "",
        name:
          typeof item === "object" &&
          item &&
          "name" in item &&
          typeof (item as { name?: unknown }).name === "string"
            ? (item as { name: string }).name
            : undefined,
        email:
          typeof item === "object" &&
          item &&
          "email" in item &&
          typeof (item as { email?: unknown }).email === "string"
            ? (item as { email: string }).email
            : undefined,
      }))
    : [];

const UserPointsDialog = dynamic(() => import("@/app/admin/users/_components/UserPointsDialog"), {
  loading: () => null,
});

const AdminConfirmDialog = dynamic(() => import("@/components/admin/AdminConfirmDialog"), {
  loading: () => null,
});

type UserListQueryState = {
  page: number;
  searchQuery: string;
  roleFilter: "all" | "user" | "admin" | "superadmin";
  statusFilter: "all" | "active" | "deleted" | "suspended";
  loginFilter: "all" | "nologin" | "recent30" | "recent90";
  signupFilter: "all" | "local" | "kakao" | "naver" | "apps_in_toss";
  sort: "created_desc" | "created_asc" | "name_asc" | "name_desc";
};

const USER_LIST_DEFAULTS: UserListQueryState = {
  page: 1,
  searchQuery: "",
  roleFilter: "all",
  statusFilter: "all",
  loginFilter: "all",
  signupFilter: "all",
  sort: "created_desc",
};

const USER_LIST_PAGE_RESET_KEYS: (keyof UserListQueryState)[] = [
  "searchQuery",
  "roleFilter",
  "statusFilter",
  "loginFilter",
  "signupFilter",
  "sort",
];

const USER_LIST_COLUMNS =
  "grid-cols-[40px_minmax(260px,1.3fr)_minmax(250px,1.15fr)_minmax(190px,0.85fr)_minmax(170px,0.75fr)_116px]";

function parseUserListQueryState(
  params: URLSearchParams,
  defaults: UserListQueryState,
): UserListQueryState {
  const role = params.get("role");
  const status = params.get("status");
  const login = params.get("login");
  const signup = params.get("signup");
  const sort = params.get("sort");

  return {
    page: Math.max(
      1,
      Number.parseInt(params.get("page") || String(defaults.page), 10) || defaults.page,
    ),
    searchQuery: params.get("q") || defaults.searchQuery,
    roleFilter:
      role === "all" || role === "user" || role === "admin" || role === "superadmin"
        ? role
        : defaults.roleFilter,
    statusFilter:
      status === "all" || status === "active" || status === "deleted" || status === "suspended"
        ? status
        : defaults.statusFilter,
    loginFilter:
      login === "all" || login === "nologin" || login === "recent30" || login === "recent90"
        ? login
        : defaults.loginFilter,
    signupFilter:
      signup === "all" ||
      signup === "local" ||
      signup === "kakao" ||
      signup === "naver" ||
      signup === "apps_in_toss"
        ? signup
        : defaults.signupFilter,
    sort:
      sort === "created_desc" ||
      sort === "created_asc" ||
      sort === "name_asc" ||
      sort === "name_desc"
        ? sort
        : defaults.sort,
  };
}

function toUserListQueryParams(queryState: UserListQueryState) {
  return {
    page: queryState.page === 1 ? undefined : queryState.page,
    q: queryState.searchQuery.trim(),
    role: queryState.roleFilter,
    status: queryState.statusFilter,
    login: queryState.loginFilter,
    signup: queryState.signupFilter,
    sort: queryState.sort,
  };
}

export default function UsersClient() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  // 서버 페이징 & 필터
  const [limit] = useState(10);
  const { state, patchState, setPage } = useAdminListQueryState<UserListQueryState>({
    pathname: pathname || "/admin/users",
    searchParams,
    replace: router.replace,
    defaults: USER_LIST_DEFAULTS,
    parse: parseUserListQueryState,
    toQueryParams: toUserListQueryParams,
    pageResetKeys: USER_LIST_PAGE_RESET_KEYS,
  });

  const { page, searchQuery, roleFilter, signupFilter, sort, statusFilter, loginFilter } = state;

  const { data, isLoading, mutate, rows, total, hasResolvedData, hasDataError, errorMessage } =
    useUserList({
      page,
      limit,
      searchQuery,
      roleFilter,
      statusFilter,
      loginFilter,
      signupFilter,
      sort,
    });

  // 선택된 사용자 ID 목록 상태
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);

  useEffect(() => {
    setSelectedUsers([]);
  }, [searchQuery, roleFilter, statusFilter, loginFilter, signupFilter, sort, page]);

  // 포인트(적립금) 다이얼로그 상태
  const [pointsDialogOpen, setPointsDialogOpen] = useState(false);
  const [pointsTarget, setPointsTarget] = useState<{
    id: string;
    name?: string;
  } | null>(null);

  // 유저별 포인트 다이얼로그 열기
  const openPointsDialog = (userId: string, userName?: string) => {
    setPointsTarget({ id: userId, name: userName });
    setPointsDialogOpen(true);
  };

  // 선택된 행의 현재 상태를 계산
  const safeRows = rows ?? [];

  const selectedRows = useMemo(
    () => (selectedUsers.length ? safeRows.filter((r) => selectedUsers.includes(r.id)) : []),
    [safeRows, selectedUsers],
  );

  // 각각 가능 여부
  const canSuspend = useMemo(
    () => selectedRows.some((u) => !u.isDeleted && !u.isSuspended),
    [selectedRows],
  );
  const canUnsuspend = useMemo(
    () => selectedRows.some((u) => !u.isDeleted && u.isSuspended),
    [selectedRows],
  );
  const hasSelection = selectedUsers.length > 0;
  const canSoftDelete = useMemo(() => selectedRows.some((u) => !u.isDeleted), [selectedRows]);

  const hasResolvedTotal = hasResolvedData && !hasDataError && typeof total === "number";
  const totalPages = hasResolvedTotal ? Math.max(1, Math.ceil(total / limit)) : 1;
  const shouldShowResolvedPagination = hasResolvedTotal && !hasDataError;
  const pageItems = shouldShowResolvedPagination ? buildPageItems(page, totalPages) : [];

  const kpiValues = useMemo(() => {
    const counters = data?.counters;

    return {
      active: counters?.active ?? safeRows.filter((u) => !u.isDeleted && !u.isSuspended).length,
      deleted: counters?.deleted ?? safeRows.filter((u) => u.isDeleted).length,
      admins: counters?.admins ?? safeRows.filter((u) => isAdminRole(u.role)).length,
      suspended:
        counters?.suspended ?? safeRows.filter((u) => u.isSuspended && !u.isDeleted).length,
      total: counters?.total ?? (typeof total === "number" ? total : 0),
    };
  }, [data, safeRows, total]);

  const kpiStatus = useMemo<"loading" | "error" | "ready">(() => {
    if (isLoading && !data) return "loading";
    if (hasDataError) return "error";
    return "ready";
  }, [data, hasDataError, isLoading]);

  const hasCustomFilters =
    searchQuery.trim().length > 0 ||
    roleFilter !== "all" ||
    statusFilter !== "all" ||
    loginFilter !== "all" ||
    signupFilter !== "all" ||
    sort !== "created_desc";

  const currentViewLabel = !hasCustomFilters
    ? "전체 회원"
    : searchQuery.trim().length > 0
      ? "검색 결과"
      : statusFilter === "active" &&
          roleFilter === "all" &&
          loginFilter === "all" &&
          signupFilter === "all"
        ? "활성 회원"
        : statusFilter === "suspended" &&
            roleFilter === "all" &&
            loginFilter === "all" &&
            signupFilter === "all"
          ? "비활성 회원"
          : statusFilter === "deleted" &&
              roleFilter === "all" &&
              loginFilter === "all" &&
              signupFilter === "all"
            ? "삭제됨(탈퇴)"
            : roleFilter === "admin" &&
                statusFilter === "all" &&
                loginFilter === "all" &&
                signupFilter === "all"
              ? "관리자"
              : loginFilter === "nologin" &&
                  roleFilter === "all" &&
                  statusFilter === "all" &&
                  signupFilter === "all"
                ? "미로그인 회원"
                : "사용자 지정 조건";

  const activeKpiKey = !hasCustomFilters
    ? "total"
    : statusFilter === "active" &&
        roleFilter === "all" &&
        loginFilter === "all" &&
        signupFilter === "all" &&
        !searchQuery.trim()
      ? "active"
      : statusFilter === "suspended" &&
          roleFilter === "all" &&
          loginFilter === "all" &&
          signupFilter === "all" &&
          !searchQuery.trim()
        ? "suspended"
        : statusFilter === "deleted" &&
            roleFilter === "all" &&
            loginFilter === "all" &&
            signupFilter === "all" &&
            !searchQuery.trim()
          ? "deleted"
          : roleFilter === "admin" &&
              statusFilter === "all" &&
              loginFilter === "all" &&
              signupFilter === "all" &&
              !searchQuery.trim()
            ? "admins"
            : null;

  const applyUserQuickFilter = (
    next: Partial<{
      searchQuery: string;
      roleFilter: "all" | "user" | "admin" | "superadmin";
      statusFilter: "all" | "active" | "deleted" | "suspended";
      loginFilter: "all" | "nologin" | "recent30" | "recent90";
      signupFilter: "all" | "local" | "kakao" | "naver" | "apps_in_toss";
      sort: "created_desc" | "created_asc" | "name_asc" | "name_desc";
    }>,
  ) => {
    patchState({
      page: 1,
      searchQuery: "",
      roleFilter: "all",
      statusFilter: "all",
      loginFilter: "all",
      signupFilter: "all",
      sort: "created_desc",
      ...next,
    });
  };

  const resetUserFilters = () => {
    applyUserQuickFilter({});
  };

  // 테이블 상태 분기: loading -> error -> actual empty -> data rows
  const shouldShowLoadingRows = isLoading && !hasResolvedData;
  const shouldShowErrorRow = hasDataError;
  const shouldShowEmptyRow =
    !shouldShowLoadingRows && !shouldShowErrorRow && hasResolvedData && safeRows.length === 0;
  const shouldShowDataRows = !shouldShowLoadingRows && !shouldShowErrorRow && safeRows.length > 0;

  // 선택
  const isAllSelected = safeRows.length > 0 && selectedUsers.length === safeRows.length;
  const isPartiallySelected = selectedUsers.length > 0 && selectedUsers.length < safeRows.length;

  // 삭제된 회원이 하나라도 선택
  const hasDeletedSelected = useMemo(() => selectedRows.some((u) => u.isDeleted), [selectedRows]);
  const selectedAppsInTossCount = useMemo(
    () => selectedRows.filter((u) => !u.isDeleted && u.appsInTossLinked).length,
    [selectedRows],
  );

  const handleSelectAll = () => setSelectedUsers(isAllSelected ? [] : safeRows.map((u) => u.id));
  const handleSelectUser = (id: string) =>
    setSelectedUsers((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  const goToPage = (p: number) => setPage(Math.max(1, Math.min(totalPages, p)));

  // 공용: 선택된 row의 이메일
  const selectedEmails = safeRows
    .filter((r) => selectedUsers.includes(r.id))
    .map((r) => r.email)
    .filter(Boolean);

  // 메일 발송(초기 구현은 mailto로 기본 메일 클라이언트 호출)
  const handleBulkMail = () => {
    if (selectedEmails.length === 0) return;
    const bcc = encodeURIComponent(selectedEmails.join(","));
    window.location.href = `mailto:?bcc=${bcc}`;
  };

  //  비활성화/해제
  const bulkSuspend = async (suspend: boolean) => {
    try {
      const json = await adminMutator<BulkActionResponse>("/api/admin/users/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          op: suspend ? "suspend" : "unsuspend",
          ids: selectedUsers,
        }),
      });

      const modified = Number(json.modifiedCount || 0);
      const alreadyCnt = Array.isArray(json?.skipped?.already) ? json.skipped.already.length : 0;
      const incompatibleCnt = Array.isArray(json?.skipped?.incompatible)
        ? json.skipped.incompatible.length
        : 0;

      if (modified > 0) {
        showSuccessToast(`${suspend ? "비활성화" : "비활성 해제"} ${modified}건 완료`);
      }
      if (alreadyCnt > 0) {
        showInfoToast(`${alreadyCnt}건은 이미 ${suspend ? "비활성" : "활성"} 상태여서 건너뜀`);
      }
      if (incompatibleCnt > 0 && suspend) {
        // 비활성화 시도에서만 안내: 삭제 계정 비활성화 불가
        showInfoToast(`${incompatibleCnt}건은 삭제 상태라 비활성화할 수 없음`);
      }

      if (modified === 0 && alreadyCnt + incompatibleCnt > 0) {
        // 실제 변경 없음
        showInfoToast("변경된 항목이 없습니다.");
      }

      setSelectedUsers([]);
      mutate?.();
    } catch (e: unknown) {
      showErrorToast(getAdminErrorMessage(e));
    }
  };

  // 삭제(소프트 삭제)
  const bulkSoftDelete = async () => {
    try {
      const json = await adminMutator<BulkActionResponse>("/api/admin/users/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ op: "softDelete", ids: selectedUsers }),
      });

      const modified = Number(json.modifiedCount || 0);
      const alreadyCnt = Array.isArray(json?.skipped?.already) ? json.skipped.already.length : 0;

      if (modified > 0) showSuccessToast(`삭제(탈퇴) ${modified}건 완료`);
      if (alreadyCnt > 0) showInfoToast(`${alreadyCnt}건은 이미 삭제 상태여서 건너뜀`);
      if (modified === 0 && alreadyCnt > 0) showInfoToast("변경된 항목이 없습니다.");

      setSelectedUsers([]);
      mutate?.();
    } catch (e: unknown) {
      showErrorToast(getAdminErrorMessage(e));
    }
  };
  const [softDeleteDialogOpen, setSoftDeleteDialogOpen] = useState(false);

  // --- Cleanup(7일) 모달 상태 ---
  const [cleanupOpen, setCleanupOpen] = useState(false);
  const [cleanupPreview, setCleanupPreview] = useState<UserCleanupPreviewCandidateDto[]>([]);
  const [cleanupLoading, setCleanupLoading] = useState(false);
  const [cleanupSubmitting, setCleanupSubmitting] = useState(false);
  const [cleanupAck, setCleanupAck] = useState(false);
  const [cleanupPreviewHash, setCleanupPreviewHash] = useState("");
  const [cleanupRequestHash, setCleanupRequestHash] = useState("");
  const [cleanupConfirmationToken, setCleanupConfirmationToken] = useState("");
  const [cleanupExpectedText, setCleanupExpectedText] = useState("");
  const [cleanupConfirmText, setCleanupConfirmText] = useState("");

  // --- Purge(1년) 모달 상태 ---
  const [purgeOpen, setPurgeOpen] = useState(false);
  const [purgePreview, setPurgePreview] = useState<UserCleanupPreviewCandidateDto[]>([]);
  const [purgeLoading, setPurgeLoading] = useState(false);
  const [purgeSubmitting, setPurgeSubmitting] = useState(false);
  const [purgeAck, setPurgeAck] = useState(false);
  const [purgePreviewHash, setPurgePreviewHash] = useState("");
  const [purgeRequestHash, setPurgeRequestHash] = useState("");
  const [purgeConfirmationToken, setPurgeConfirmationToken] = useState("");
  const [purgeExpectedText, setPurgeExpectedText] = useState("");
  const [purgeConfirmText, setPurgeConfirmText] = useState("");

  // --- 미리보기 요청 ---
  const fetchCleanupPreview = async () => {
    setCleanupLoading(true);
    try {
      const json = await adminFetcher<SystemActionPreviewResponse>(
        "/api/admin/system/cleanup/preview",
      );
      setCleanupPreview(asPreviewCandidates(json?.candidates));
      setCleanupPreviewHash(typeof json?.previewHash === "string" ? json.previewHash : "");
      setCleanupRequestHash(typeof json?.requestHash === "string" ? json.requestHash : "");
      setCleanupConfirmationToken(
        typeof json?.confirmationToken === "string" ? json.confirmationToken : "",
      );
      setCleanupExpectedText(typeof json?.reconfirmText === "string" ? json.reconfirmText : "");
    } catch {
      setCleanupPreview([]);
      setCleanupPreviewHash("");
      setCleanupRequestHash("");
      setCleanupConfirmationToken("");
      setCleanupExpectedText("");
    } finally {
      setCleanupLoading(false);
    }
  };

  const fetchPurgePreview = async () => {
    setPurgeLoading(true);
    try {
      const json = await adminFetcher<SystemActionPreviewResponse>(
        "/api/admin/system/purge/preview",
      );
      setPurgePreview(asPreviewCandidates(json?.candidates));
      setPurgePreviewHash(typeof json?.previewHash === "string" ? json.previewHash : "");
      setPurgeRequestHash(typeof json?.requestHash === "string" ? json.requestHash : "");
      setPurgeConfirmationToken(
        typeof json?.confirmationToken === "string" ? json.confirmationToken : "",
      );
      setPurgeExpectedText(typeof json?.reconfirmText === "string" ? json.reconfirmText : "");
    } catch {
      setPurgePreview([]);
      setPurgePreviewHash("");
      setPurgeRequestHash("");
      setPurgeConfirmationToken("");
      setPurgeExpectedText("");
    } finally {
      setPurgeLoading(false);
    }
  };

  // --- 실행(DELETE): dry-run 선검증 -> execute 확정 실행 ---
  const confirmCleanup = async () => {
    console.info("[admin-confirm-dialog]", {
      event: "confirm",
      eventKey: "admin-users-cleanup",
      count: cleanupPreview.length,
    });
    setCleanupSubmitting(true);
    try {
      const dryRun = await runAdminActionWithToast<AdminDeleteResponse>({
        action: () =>
          adminMutator("/api/admin/system/cleanup", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ mode: "dry-run" }),
          }),
        fallbackErrorMessage: "삭제 대상 검증 실패",
      });

      if (!dryRun) return;

      if (
        !dryRun.previewHash ||
        dryRun.previewHash !== cleanupPreviewHash ||
        cleanupRequestHash !== cleanupPreviewHash
      ) {
        showErrorToast("미리보기 대상이 변경되었습니다. 목록을 새로고침한 뒤 다시 시도해 주세요.");
        await fetchCleanupPreview();
        return;
      }

      const json = await runAdminActionWithToast<AdminDeleteResponse>({
        action: () =>
          adminMutator("/api/admin/system/cleanup", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              mode: "execute",
              previewHash: cleanupPreviewHash,
              requestHash: cleanupRequestHash,
              confirmationToken: cleanupConfirmationToken,
              confirmationText: cleanupConfirmText,
            }),
          }),
        fallbackErrorMessage: "삭제 실패",
      });
      if (json) {
        showSuccessToast(`삭제된 계정 수: ${json.deletedCount ?? 0}`);
        setCleanupOpen(false);
        setCleanupAck(false);
        setCleanupConfirmText("");
        mutate?.();
      }
    } finally {
      setCleanupSubmitting(false);
    }
  };

  const confirmPurge = async () => {
    console.info("[admin-confirm-dialog]", {
      event: "confirm",
      eventKey: "admin-users-purge",
      count: purgePreview.length,
    });
    setPurgeSubmitting(true);
    try {
      const dryRun = await runAdminActionWithToast<AdminDeleteResponse>({
        action: () =>
          adminMutator("/api/admin/system/purge", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ mode: "dry-run" }),
          }),
        fallbackErrorMessage: "완전 삭제 대상 검증 실패",
      });

      if (!dryRun) return;

      if (
        !dryRun.previewHash ||
        dryRun.previewHash !== purgePreviewHash ||
        purgeRequestHash !== purgePreviewHash
      ) {
        showErrorToast("미리보기 대상이 변경되었습니다. 목록을 새로고침한 뒤 다시 시도해 주세요.");
        await fetchPurgePreview();
        return;
      }

      const json = await runAdminActionWithToast<AdminDeleteResponse>({
        action: () =>
          adminMutator("/api/admin/system/purge", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              mode: "execute",
              previewHash: purgePreviewHash,
              requestHash: purgeRequestHash,
              confirmationToken: purgeConfirmationToken,
              confirmationText: purgeConfirmText,
            }),
          }),
        fallbackErrorMessage: "완전 삭제 실패",
      });
      if (json) {
        showSuccessToast(`완전 삭제된 계정 수: ${json.deletedCount ?? 0}`);
        setPurgeOpen(false);
        setPurgeAck(false);
        setPurgeConfirmText("");
        mutate?.();
      }
    } finally {
      setPurgeSubmitting(false);
    }
  };

  return (
    <AdminPageShell variant="wide">
      <AdminPageHeader
        variant="compact"
        title="회원 관리"
        description="회원 정보, 권한, 상태, 활동 이력을 한 곳에서 확인하고 관리합니다."
        icon={UserCheck}
      />
      <UsersKpiCards
        status={kpiStatus}
        values={kpiValues}
        activeKey={activeKpiKey}
        onSelect={(key) => {
          if (key === "total") {
            resetUserFilters();
            return;
          }

          if (key === "active") {
            applyUserQuickFilter({ statusFilter: "active" });
            return;
          }

          if (key === "suspended") {
            applyUserQuickFilter({ statusFilter: "suspended" });
            return;
          }

          if (key === "deleted") {
            applyUserQuickFilter({ statusFilter: "deleted" });
            return;
          }

          if (key === "admins") {
            applyUserQuickFilter({ roleFilter: "admin" });
          }
        }}
      />

      <FiltersSection>
        <AdminFilterBar
          className="mb-4"
          actions={
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={resetUserFilters}
              disabled={!hasCustomFilters}
              className="h-9"
            >
              필터 초기화
            </Button>
          }
          activeFilters={
            <>
              {searchQuery.trim() ? (
                <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                  검색어: {searchQuery.trim()}
                </span>
              ) : null}
              <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                상태:{" "}
                {statusFilter === "active"
                  ? "활성"
                  : statusFilter === "suspended"
                    ? "비활성"
                    : statusFilter === "deleted"
                      ? "삭제됨"
                      : "전체"}
              </span>
              <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                역할:{" "}
                {roleFilter === "user"
                  ? "일반"
                  : roleFilter === "admin"
                    ? "관리자"
                    : roleFilter === "superadmin"
                      ? "최고 관리자"
                      : "전체"}
              </span>
              <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                가입 유형:{" "}
                {signupFilter === "local"
                  ? "일반 가입"
                  : signupFilter === "kakao"
                    ? "카카오"
                    : signupFilter === "naver"
                      ? "네이버"
                      : signupFilter === "apps_in_toss"
                        ? "Apps in Toss"
                        : "전체"}
              </span>
              <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                로그인 이력:{" "}
                {loginFilter === "recent30"
                  ? "최근 30일"
                  : loginFilter === "recent90"
                    ? "최근 90일"
                    : loginFilter === "nologin"
                      ? "미로그인"
                      : "전체"}
              </span>
              <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                정렬:{" "}
                {sort === "created_asc"
                  ? "가입일 ↑"
                  : sort === "name_asc"
                    ? "이름 A→Z"
                    : sort === "name_desc"
                      ? "이름 Z→A"
                      : "가입일 ↓"}
              </span>
              <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1 tabular-nums">
                전체 회원: {typeof total === "number" ? `${total.toLocaleString("ko-KR")}명` : "-"}
              </span>
            </>
          }
        >
          <div className="grid grid-cols-1 gap-2 md:grid-cols-2 xl:grid-cols-7">
            <div className="relative w-full xl:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="이름/이메일/전화 검색"
                value={searchQuery}
                onChange={(e) => patchState({ searchQuery: e.target.value })}
                className="h-9 pl-9"
                aria-label="회원 검색"
              />
            </div>

            {/* 상태 */}
            <Select
              value={statusFilter}
              onValueChange={(v) => {
                if (v === "all" || v === "active" || v === "deleted" || v === "suspended")
                  patchState({ statusFilter: v });
              }}
            >
              <SelectTrigger
                className="h-9 w-full min-w-0 text-ui-label"
                aria-label="회원 상태 필터"
              >
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  <SelectValue placeholder="상태" />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">모든 상태</SelectItem>
                <SelectItem value="active">활성</SelectItem>
                <SelectItem value="suspended">비활성</SelectItem>
                <SelectItem value="deleted">삭제됨</SelectItem>
              </SelectContent>
            </Select>

            {/* 역할 */}
            <Select
              value={roleFilter}
              onValueChange={(v) => {
                if (v === "all" || v === "user" || v === "admin" || v === "superadmin")
                  patchState({ roleFilter: v });
              }}
            >
              <SelectTrigger
                className="h-9 w-full min-w-0 text-ui-label"
                aria-label="회원 역할 필터"
              >
                <SelectValue placeholder="역할" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">역할 전체</SelectItem>
                <SelectItem value="user">일반</SelectItem>
                <SelectItem value="admin">관리자</SelectItem>
                <SelectItem value="superadmin">최고 관리자</SelectItem>
              </SelectContent>
            </Select>

            {/* 가입유형 (SNS) */}
            <Select
              value={signupFilter}
              onValueChange={(v) => {
                patchState({
                  signupFilter: v as "all" | "local" | "kakao" | "naver" | "apps_in_toss",
                });
              }}
            >
              <SelectTrigger
                className="h-9 w-full min-w-0 text-ui-label"
                aria-label="회원 가입 유형 필터"
              >
                <SelectValue placeholder="가입유형" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">가입유형 전체</SelectItem>
                <SelectItem value="local">일반 가입</SelectItem>
                <SelectItem value="kakao">카카오 가입</SelectItem>
                <SelectItem value="naver">네이버 가입</SelectItem>
                <SelectItem value="apps_in_toss">Apps in Toss</SelectItem>
              </SelectContent>
            </Select>

            {/* 로그인 필터 */}
            <Select
              value={loginFilter}
              onValueChange={(v) => {
                patchState({
                  loginFilter: v as "all" | "nologin" | "recent30" | "recent90",
                });
              }}
            >
              <SelectTrigger
                className="h-9 w-full min-w-0 text-ui-label"
                aria-label="회원 로그인 이력 필터"
              >
                <SelectValue placeholder="로그인" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">로그인 전체</SelectItem>
                <SelectItem value="recent30">최근 30일 로그인</SelectItem>
                <SelectItem value="recent90">최근 90일 로그인</SelectItem>
                <SelectItem value="nologin">미로그인</SelectItem>
              </SelectContent>
            </Select>

            {/* 정렬 */}
            <Select
              value={sort}
              onValueChange={(v) => {
                if (
                  v === "created_desc" ||
                  v === "created_asc" ||
                  v === "name_asc" ||
                  v === "name_desc"
                )
                  patchState({ sort: v });
              }}
            >
              <SelectTrigger
                className="h-9 w-full min-w-0 text-ui-label"
                aria-label="회원 정렬 기준"
              >
                <SelectValue placeholder="정렬" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="created_desc">가입일 ↓</SelectItem>
                <SelectItem value="created_asc">가입일 ↑</SelectItem>
                <SelectItem value="name_asc">이름 A→Z</SelectItem>
                <SelectItem value="name_desc">이름 Z→A</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </AdminFilterBar>
      </FiltersSection>

      <BulkActionsSection>
        {/* 선택 액션바 */}
        {selectedUsers.length > 0 && (
          <div className="mb-3 rounded-md bg-card border border-border p-4">
            <div className="flex flex-row items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-primary">
                  {selectedUsers.length}명의 회원이 선택됨
                </span>
              </div>

              <div className="flex flex-wrap gap-2 ml-auto">
                <Button variant="outline" size="sm" onClick={handleBulkMail}>
                  <Mail className="mr-2 h-3.5 w-3.5" />
                  메일 발송
                </Button>

                {/* 상태 변경: 삭제 선택 시 비활성, 그 외 토글/드롭다운 */}
                {hasDeletedSelected ? (
                  <Button
                    variant="outline"
                    size="sm"
                    disabled
                    title="삭제(탈퇴)된 회원은 상태 변경/복구가 불가합니다. 재가입을 안내하세요."
                  >
                    상태 변경
                  </Button>
                ) : (
                  <>
                    {/* 전원 활성 → 비활성화만 가능 */}
                    {canSuspend && !canUnsuspend && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => bulkSuspend(true)}
                        title={!hasSelection ? "선택된 회원이 없습니다" : undefined}
                        disabled={!hasSelection}
                      >
                        <UserX className="mr-2 h-3.5 w-3.5" />
                        비활성화
                      </Button>
                    )}

                    {/* 전원 비활성 → 활성화만 가능 */}
                    {!canSuspend && canUnsuspend && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => bulkSuspend(false)}
                        title={!hasSelection ? "선택된 회원이 없습니다" : undefined}
                        disabled={!hasSelection}
                      >
                        <UserCheck className="mr-2 h-3.5 w-3.5" />
                        활성화
                      </Button>
                    )}

                    {/* 혼합 선택 → 드롭다운 */}
                    {canSuspend && canUnsuspend && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            title={
                              !hasSelection
                                ? "선택된 회원이 없습니다"
                                : "선택된 회원의 상태를 일괄 변경"
                            }
                            disabled={!hasSelection}
                          >
                            상태 변경
                            <ChevronDown className="ml-1 h-3.5 w-3.5" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="start">
                          <DropdownMenuItem onClick={() => bulkSuspend(false)}>
                            <UserCheck className="mr-2 h-3.5 w-3.5" />
                            활성화
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => bulkSuspend(true)}>
                            <UserX className="mr-2 h-3.5 w-3.5" />
                            비활성화
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </>
                )}

                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => setSoftDeleteDialogOpen(true)}
                  disabled={!canSoftDelete}
                  title={!canSoftDelete ? "선택 항목이 이미 삭제 상태입니다" : undefined}
                >
                  <Trash2 className="mr-2 h-3.5 w-3.5" />
                  삭제
                </Button>
              </div>
            </div>

            {((canSuspend && canUnsuspend) || hasDeletedSelected) && (
              <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
                {canSuspend && canUnsuspend && (
                  <>
                    <Badge variant="info" className="gap-1 px-2 py-1">
                      <UserCheck className="h-3.5 w-3.5" />
                      활성화 가능 {selectedRows.filter((u) => !u.isDeleted && u.isSuspended).length}
                      건
                    </Badge>
                    <Badge variant="brand" className="gap-1 px-2 py-1">
                      <UserX className="h-3.5 w-3.5" />
                      비활성화 가능{" "}
                      {selectedRows.filter((u) => !u.isDeleted && !u.isSuspended).length}건
                    </Badge>
                  </>
                )}

                {/* 삭제 선택 시: 경고 칩 */}
                {hasDeletedSelected && (
                  <Badge variant="warning" className="gap-1 px-2 py-1">
                    <AlertCircle className="h-3.5 w-3.5" />
                    삭제(탈퇴)된 회원은 복구할 수 없습니다. 재가입만 가능합니다.
                  </Badge>
                )}
              </div>
            )}
          </div>
        )}
      </BulkActionsSection>

      <TableSection>
        <AdminListTable
          title="회원 목록"
          viewLabel={currentViewLabel}
          resultLabel={
            hasDataError
              ? "불러오기 실패"
              : typeof total === "number"
                ? `총 ${total.toLocaleString("ko-KR")}명`
                : "불러오는 중…"
          }
          description="회원 계정, 연락처, 활동과 포인트, 권한·상태 및 관리 작업을 한 행에서 확인합니다."
          columnsClassName={USER_LIST_COLUMNS}
          ariaLabel="회원 관리 목록"
        >
          <AdminListColumnHeader columnsClassName={USER_LIST_COLUMNS}>
            <div role="columnheader" className="min-w-0 px-0 py-2.5 text-center">
              <Checkbox
                checked={isAllSelected ? true : isPartiallySelected ? "indeterminate" : false}
                onCheckedChange={() => handleSelectAll()}
                aria-label="현재 페이지 회원 전체 선택"
                className="mx-auto"
              />
            </div>
            <div role="columnheader" className="min-w-0 px-4 py-2.5">
              회원 / 계정
            </div>
            <div role="columnheader" className="min-w-0 px-4 py-2.5">
              연락처 / 주소
            </div>
            <div role="columnheader" className="min-w-0 px-4 py-2.5 text-right">
              활동 / 포인트
            </div>
            <div role="columnheader" className="min-w-0 px-4 py-2.5">
              권한 / 상태
            </div>
            <div role="columnheader" className="min-w-0 px-4 py-2.5 text-right">
              작업
            </div>
          </AdminListColumnHeader>

          <AdminListBody>
            {shouldShowLoadingRows &&
              Array.from({ length: 8 }).map((_, i) => (
                <AdminListRow key={`sk-${i}`} columnsClassName={USER_LIST_COLUMNS}>
                  <AdminListCell align="center" className="px-0">
                    <Skeleton className="h-4 w-4" />
                  </AdminListCell>
                  <AdminListCell>
                    <Skeleton className="h-4 w-40" />
                    <Skeleton className="mt-2 h-3 w-28" />
                  </AdminListCell>
                  <AdminListCell>
                    <Skeleton className="h-4 w-44" />
                    <Skeleton className="mt-2 h-3 w-36" />
                  </AdminListCell>
                  <AdminListCell align="end">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="mt-2 h-3 w-24" />
                  </AdminListCell>
                  <AdminListCell>
                    <Skeleton className="h-5 w-28" />
                  </AdminListCell>
                  <AdminListCell align="end">
                    <Skeleton className="h-8 w-20" />
                  </AdminListCell>
                </AdminListRow>
              ))}

            {shouldShowErrorRow && (
              <AdminListRow columnsClassName={USER_LIST_COLUMNS}>
                <AdminListCell className="col-span-6 py-10 text-center text-destructive">
                  회원 목록을 불러오지 못했습니다. {errorMessage || "잠시 후 다시 시도해 주세요."}
                </AdminListCell>
              </AdminListRow>
            )}

            {shouldShowEmptyRow && (
              <AdminListRow columnsClassName={USER_LIST_COLUMNS}>
                <AdminListCell className="col-span-6 py-16 text-center">
                  {hasCustomFilters
                    ? "현재 조건에 맞는 회원이 없습니다."
                    : "등록된 회원이 없습니다."}
                </AdminListCell>
              </AdminListRow>
            )}

            {shouldShowDataRows &&
              safeRows.map((u) => {
                const statusKey: UserStatusKey = u.isDeleted
                  ? "deleted"
                  : u.isSuspended
                    ? "suspended"
                    : "active";
                const joined = splitDateTime(u.createdAt ?? undefined);
                const last = splitDateTime(u.lastLoginAt ?? undefined);
                const signupMethods = [
                  u.socialProviders?.includes("kakao") ? "카카오" : null,
                  u.socialProviders?.includes("naver") ? "네이버" : null,
                  u.appsInTossLinked ? "Apps in Toss" : null,
                ].filter((value): value is string => Boolean(value));
                const signupLabel = signupMethods.join(" · ") || "이메일 계정";

                return (
                  <AdminListRow key={u.id} columnsClassName={USER_LIST_COLUMNS}>
                    <AdminListCell align="center" className="px-0">
                      <Checkbox
                        checked={selectedUsers.includes(u.id)}
                        onCheckedChange={() => handleSelectUser(u.id)}
                        aria-label={`${u.name || "사용자"} 선택`}
                      />
                    </AdminListCell>
                    <AdminListCell>
                      <AdminListPrimary
                        title={u.name || "(이름없음)"}
                        meta={
                          <>
                            <span>{u.email}</span>
                            <span>{signupLabel}</span>
                          </>
                        }
                        supporting={
                          <AdminReferencePopover
                            title={`${u.name || "회원"} 계정 참조`}
                            trigger={
                              <button type="button" className={adminDataTable.referenceTrigger}>
                                계정 참조 보기
                              </button>
                            }
                            items={[
                              { label: "회원 ID", value: u.id, copyValue: u.id },
                              { label: "이메일", value: u.email, copyValue: u.email || undefined },
                              { label: "가입 경로", value: signupLabel },
                              {
                                label: "Apps in Toss",
                                value: u.appsInTossLinked ? "연결됨" : "미연결",
                              },
                            ]}
                          />
                        }
                      />
                    </AdminListCell>
                    <AdminListCell>
                      <div className={adminDataTable.cellStack}>
                        <span className={adminDataTable.primaryLine}>
                          {u.phone ? formatKoreanPhone(u.phone) || u.phone : "전화 미등록"}
                        </span>
                        <span className={adminDataTable.secondaryLine}>
                          {shortAddress(u.address) || "주소 미등록"}
                        </span>
                        <AdminReferencePopover
                          title={`${u.name || "회원"} 연락처`}
                          trigger={
                            <button type="button" className={adminDataTable.referenceTrigger}>
                              전체 연락처 보기
                            </button>
                          }
                          items={[
                            { label: "이메일", value: u.email, copyValue: u.email || undefined },
                            {
                              label: "전화",
                              value: formatKoreanPhone(u.phone || "") || u.phone,
                              href: u.phone ? `tel:${u.phone}` : undefined,
                              copyValue: u.phone || undefined,
                            },
                            {
                              label: "주소",
                              value: fullAddress(u.postalCode, u.address, u.addressDetail),
                            },
                          ]}
                        />
                      </div>
                    </AdminListCell>
                    <AdminListCell align="end">
                      <div className="flex flex-col items-end gap-1 whitespace-nowrap tabular-nums">
                        <span className={adminTypography.tablePrimary}>
                          로그인 {last.time ? `${last.date} ${last.time}` : "-"}
                        </span>
                        <span className={adminTypography.tableSecondary}>가입 {joined.date}</span>
                        <span className={adminTypography.meta}>
                          보유 {u.pointsBalance.toLocaleString("ko-KR")}P
                        </span>
                      </div>
                    </AdminListCell>
                    <AdminListCell>
                      <AdminStatusGroup
                        primary={
                          <>
                            <Badge
                              className={cn(
                                badgeSm,
                                roleColors[u.role],
                                "shrink-0 whitespace-nowrap",
                              )}
                            >
                              {getUserRoleLabel(u.role)}
                            </Badge>
                            <Badge
                              className={cn(
                                badgeSm,
                                STATUS[statusKey],
                                "shrink-0 whitespace-nowrap",
                              )}
                            >
                              {statusKey === "active"
                                ? "활성"
                                : statusKey === "suspended"
                                  ? "비활성"
                                  : "삭제됨"}
                            </Badge>
                          </>
                        }
                      />
                    </AdminListCell>
                    <AdminListCell align="end">
                      <AdminRowActions>
                        <Button asChild size="sm" variant="outline">
                          <Link href={`/admin/users/${u.id}`}>상세</Link>
                        </Button>
                        <AdminRowActionMenu
                          ariaLabel={`${u.name || u.email || "회원"} 작업 메뉴 열기`}
                        >
                          <DropdownMenuItem
                            className="whitespace-nowrap"
                            onSelect={(e) => {
                              e.preventDefault();
                              openPointsDialog(u.id, u.name);
                            }}
                          >
                            포인트 내역/조정
                          </DropdownMenuItem>
                        </AdminRowActionMenu>
                      </AdminRowActions>
                    </AdminListCell>
                  </AdminListRow>
                );
              })}
          </AdminListBody>

          <div role="rowgroup" className="border-t border-border">
            <div role="row">
              <div
                role="cell"
                aria-colspan={6}
                className="flex flex-wrap items-center justify-center gap-1 px-4 py-3"
              >
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => goToPage(1)}
                  disabled={!shouldShowResolvedPagination || page <= 1}
                  aria-label="첫 페이지"
                >
                  <ChevronsLeft className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => goToPage(page - 1)}
                  disabled={!shouldShowResolvedPagination || page <= 1}
                  aria-label="이전"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                {!shouldShowResolvedPagination ? (
                  <span className="select-none px-2 text-muted-foreground">-</span>
                ) : (
                  pageItems.map((it, i) =>
                    typeof it === "number" ? (
                      <Button
                        key={i}
                        variant={it === page ? "default" : "outline"}
                        className="h-8 min-w-8 px-2"
                        onClick={() => goToPage(it)}
                        aria-current={it === page ? "page" : undefined}
                      >
                        {it}
                      </Button>
                    ) : (
                      <span key={i} className="select-none px-2 text-muted-foreground">
                        …
                      </span>
                    ),
                  )
                )}
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => goToPage(page + 1)}
                  disabled={!shouldShowResolvedPagination || page >= totalPages}
                  aria-label="다음"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => goToPage(totalPages)}
                  disabled={!shouldShowResolvedPagination || page >= totalPages}
                  aria-label="끝 페이지"
                >
                  <ChevronsRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </AdminListTable>
      </TableSection>

      <DialogsSection>
        <div className="mt-6">
          <Card className="border-destructive/30 bg-destructive/10 dark:bg-destructive/15">
            <CardHeader className="pb-2">
              <CardTitle className="text-destructive text-sm">
                탈퇴 회원 정리 (Danger zone)
              </CardTitle>
              <CardDescription className="text-xs text-muted-foreground">
                7일 경과 탈퇴 계정은 정리, 1년 경과 탈퇴 계정은 완전 삭제합니다. 실행 전 미리보기
                목록을 확인하세요.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-2">
              {/* 탈퇴 회원 자동 삭제 실행 (7일 경과) */}
              <AlertDialog
                open={cleanupOpen}
                onOpenChange={(o) => {
                  setCleanupOpen(o);
                  console.info("[admin-confirm-dialog]", {
                    event: o ? "open" : "cancel",
                    eventKey: "admin-users-cleanup",
                  });
                  if (o) {
                    setCleanupAck(false);
                    setCleanupConfirmText("");
                    fetchCleanupPreview();
                  }
                }}
              >
                <AlertDialogTrigger asChild>
                  <Button variant="destructive">7일 이상 경과한 탈퇴 회원 자동 삭제 실행</Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>탈퇴 회원 자동 삭제</AlertDialogTitle>
                    <AlertDialogDescription>{`영향 개수: ${cleanupPreview.length}개 계정\n탈퇴 후 7일이 지난 계정을 영구 삭제합니다. 이 작업은 되돌릴 수 없습니다.`}</AlertDialogDescription>
                  </AlertDialogHeader>

                  {/* 미리보기 리스트 */}
                  <div className="border rounded-md p-3 max-h-64 overflow-auto">
                    {cleanupLoading ? (
                      <div className="space-y-2" aria-label="탈퇴 회원 미리보기 로딩 중">
                        {Array.from({ length: 2 }).map((_, index) => (
                          <div
                            key={`cleanup-preview-skeleton-${index}`}
                            className="flex items-center justify-between gap-2"
                          >
                            <Skeleton className="h-4 w-32" />
                            <Skeleton className="h-3 w-28" />
                          </div>
                        ))}
                      </div>
                    ) : cleanupPreview.length === 0 ? (
                      <div className="text-sm text-muted-foreground">
                        삭제 예정인 탈퇴 회원이 없습니다.
                      </div>
                    ) : (
                      <ul className="text-sm space-y-1">
                        {cleanupPreview.map((u) => (
                          <li
                            key={String(u._id)}
                            className="flex items-center justify-between gap-2"
                          >
                            <span className="truncate">{u.name || u.email || u._id}</span>
                            <span className="text-xs text-muted-foreground">{u.email}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  {/* 동의 체크 */}
                  <div className="mt-3 flex items-center gap-2">
                    <Checkbox
                      id="cleanup-ack"
                      checked={cleanupAck}
                      onCheckedChange={(v) => setCleanupAck(Boolean(v))}
                    />
                    <label htmlFor="cleanup-ack" className="text-xs text-muted-foreground">
                      위 목록을 확인했으며, 영구 삭제에 동의합니다.
                    </label>
                  </div>

                  <div className="mt-3 space-y-1">
                    <label htmlFor="cleanup-reconfirm" className="text-xs text-muted-foreground">
                      재확인 문구 입력:{" "}
                      <span className="font-mono">{cleanupExpectedText || "-"}</span>
                    </label>
                    <Input
                      id="cleanup-reconfirm"
                      value={cleanupConfirmText}
                      onChange={(e) => setCleanupConfirmText(e.target.value)}
                      placeholder={cleanupExpectedText || "재확인 문구"}
                      autoComplete="off"
                    />
                  </div>

                  <AlertDialogFooter>
                    <AlertDialogCancel disabled={cleanupSubmitting}>취소</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={confirmCleanup}
                      disabled={
                        cleanupSubmitting ||
                        cleanupLoading ||
                        !cleanupAck ||
                        cleanupPreview.length === 0 ||
                        !cleanupPreviewHash ||
                        !cleanupRequestHash ||
                        cleanupConfirmText.trim() !== cleanupExpectedText
                      }
                    >
                      {cleanupSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      영구 삭제 실행
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              {/* 1년 이상 경과한 탈퇴 회원 완전 삭제 */}
              <AlertDialog
                open={purgeOpen}
                onOpenChange={(o) => {
                  setPurgeOpen(o);
                  console.info("[admin-confirm-dialog]", {
                    event: o ? "open" : "cancel",
                    eventKey: "admin-users-purge",
                  });
                  if (o) {
                    setPurgeAck(false);
                    setPurgeConfirmText("");
                    fetchPurgePreview();
                  }
                }}
              >
                <AlertDialogTrigger asChild>
                  <Button variant="destructive">1년 이상 경과한 탈퇴 회원 완전 삭제</Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>탈퇴 1년 경과 계정 완전 삭제</AlertDialogTitle>
                    <AlertDialogDescription>{`영향 개수: ${purgePreview.length}개 계정\n탈퇴 1년 경과 계정을 완전 삭제합니다. 이 작업은 되돌릴 수 없습니다.\n실행 전 재확인 문구("${purgeExpectedText || "-"}")를 정확히 입력해야 합니다.`}</AlertDialogDescription>
                  </AlertDialogHeader>

                  {/* 미리보기 리스트 */}
                  <div className="border rounded-md p-3 max-h-64 overflow-auto">
                    {purgeLoading ? (
                      <div className="space-y-2" aria-label="완전 삭제 대상 미리보기 로딩 중">
                        {Array.from({ length: 2 }).map((_, index) => (
                          <div
                            key={`purge-preview-skeleton-${index}`}
                            className="flex items-center justify-between gap-2"
                          >
                            <Skeleton className="h-4 w-32" />
                            <Skeleton className="h-3 w-28" />
                          </div>
                        ))}
                      </div>
                    ) : purgePreview.length === 0 ? (
                      <div className="text-sm text-muted-foreground">
                        완전 삭제 대상 계정이 없습니다.
                      </div>
                    ) : (
                      <ul className="text-sm space-y-1">
                        {purgePreview.map((u) => (
                          <li
                            key={String(u._id)}
                            className="flex items-center justify-between gap-2"
                          >
                            <span className="truncate">{u.name || u.email || u._id}</span>
                            <span className="text-xs text-muted-foreground">{u.email}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  {/* 동의 체크 */}
                  <div className="mt-3 flex items-center gap-2">
                    <Checkbox
                      id="purge-ack"
                      checked={purgeAck}
                      onCheckedChange={(v) => setPurgeAck(Boolean(v))}
                    />
                    <label htmlFor="purge-ack" className="text-xs text-muted-foreground">
                      위 목록을 확인했으며, 완전 삭제에 동의합니다.
                    </label>
                  </div>

                  <div className="mt-3 space-y-1">
                    <label htmlFor="purge-reconfirm" className="text-xs text-muted-foreground">
                      재확인 문구 입력:{" "}
                      <span className="font-mono">{purgeExpectedText || "-"}</span>
                    </label>
                    <Input
                      id="purge-reconfirm"
                      value={purgeConfirmText}
                      onChange={(e) => setPurgeConfirmText(e.target.value)}
                      placeholder={purgeExpectedText || "재확인 문구"}
                      autoComplete="off"
                    />
                  </div>

                  <AlertDialogFooter>
                    <AlertDialogCancel disabled={purgeSubmitting}>취소</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={confirmPurge}
                      disabled={
                        purgeSubmitting ||
                        purgeLoading ||
                        !purgeAck ||
                        purgePreview.length === 0 ||
                        !purgePreviewHash ||
                        !purgeRequestHash ||
                        purgeConfirmText.trim() !== purgeExpectedText
                      }
                    >
                      {purgeSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      완전 삭제 실행
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </div>
      </DialogsSection>
      <AdminConfirmDialog
        open={softDeleteDialogOpen}
        onOpenChange={setSoftDeleteDialogOpen}
        onConfirm={() => {
          setSoftDeleteDialogOpen(false);
          void bulkSoftDelete();
        }}
        title="회원 삭제(탈퇴) 처리 확인"
        description={`영향 개수: ${selectedUsers.length}명\n선택한 회원을 삭제(탈퇴) 상태로 변경합니다. 이 작업은 되돌릴 수 없습니다.${selectedAppsInTossCount > 0 ? `\n\n선택한 회원 중 Apps in Toss 연결 계정 ${selectedAppsInTossCount}명이 포함되어 있습니다. 삭제하면 해당 계정의 도깨비테니스 미니앱 로그인이 차단됩니다.` : ""}`}
        confirmText="삭제(탈퇴) 처리"
        severity="danger"
        eventKey="admin-users-soft-delete"
        eventMeta={{
          selectedCount: selectedUsers.length,
          appsInTossLinkedCount: selectedAppsInTossCount,
        }}
      />
      <UserPointsDialog
        open={pointsDialogOpen}
        onOpenChange={setPointsDialogOpen}
        userId={pointsTarget?.id ?? null}
        userName={pointsTarget?.name}
      />
    </AdminPageShell>
  );
}
