"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import useSWR from "swr";

import { UserActivityTabsSection } from "@/app/admin/users/_components/UserActivityTabsSection";
import { useUserSessions } from "@/app/admin/users/_hooks/useUserSessions";
import AdminDetailSectionNav from "@/components/admin/AdminDetailSectionNav";
import AdminInlineEmpty from "@/components/admin/AdminInlineEmpty";
import AdminInternalNotesCard from "@/components/admin/AdminInternalNotesCard";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import AdminPageShell from "@/components/admin/AdminPageShell";
import { InfoItem } from "@/components/admin/InfoItem";
import { Section, SectionBody, SectionHeader } from "@/components/admin/Section";
import StatusBadge from "@/components/admin/StatusBadge";
import { adminSurface } from "@/components/admin/admin-typography";
import AsyncState from "@/components/system/AsyncState";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { AdminSemanticBadge as Badge } from "@/components/admin/AdminSemanticBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Skeleton } from "@/components/ui/skeleton";
import { TooltipProvider } from "@/components/ui/tooltip";
import { runAdminActionWithToast } from "@/lib/admin/adminActionHelpers";
import { adminMutator } from "@/lib/admin/adminFetcher";
import { getUserRoleLabel, isAdminRole, isSuperAdminRole } from "@/lib/admin/roles";
import { asRecord, safeArray, safeNumber } from "@/lib/admin/parsers";
import {
  getCurrentSessionBadgeSpec,
  getSessionDeviceBadgeSpec,
  getUserRoleBadgeSpec,
} from "@/lib/badge-style";
import { authenticatedSWRFetcher } from "@/lib/fetchers/authenticatedSWRFetcher";
import {
  UNSAVED_CHANGES_MESSAGE,
  useUnsavedChangesGuard,
} from "@/lib/hooks/useUnsavedChangesGuard";
import { useCurrentUser } from "@/lib/hooks/useCurrentUser";
import { loadDaumPostcode } from "@/lib/loadDaumPostcode";
import { showErrorToast, showSuccessToast } from "@/lib/toast";
import { cn } from "@/lib/utils";
import { formatKoreanPhone } from "@/lib/phone";
import {
  Activity as ActivityIcon,
  CalendarDays,
  ChevronLeft,
  ListTree,
  LogIn,
  MapPin,
  MonitorSmartphone,
  Pencil,
  Phone,
  RefreshCw,
  ShieldAlert,
  ShoppingBag,
  Smartphone,
  Star,
  UserCog,
  Wrench,
} from "lucide-react";

// 변경이력 포맷터 유틸
const AUDIT_LABELS: Record<string, string> = {
  name: "이름",
  email: "이메일",
  phone: "전화번호",
  address: "주소",
  addressDetail: "상세주소",
  postalCode: "우편번호",
  role: "권한",
  isSuspended: "상태",
  isDeleted: "상태",
};

function humanizeAuditDetail(action: string, raw?: string) {
  if (!raw) return "";
  let obj: Record<string, unknown>;
  try {
    obj = asRecord(JSON.parse(raw));
  } catch {
    return ""; // JSON 아니면 숨김
  }
  if (Object.keys(obj).length === 0) return "";

  const entries = Object.entries(obj);

  // isSuspended / isDeleted만 있는 경우는 제목(액션)으로 충분하니 생략
  if (entries.length === 1 && (entries[0][0] === "isSuspended" || entries[0][0] === "isDeleted")) {
    return "";
  }

  const parts = entries.map(([k, v]) => {
    const label = AUDIT_LABELS[k] ?? k;
    if (k === "isSuspended") return `${label}: ${v ? "비활성화" : "비활성 해제"}`;
    if (k === "isDeleted") return `${label}: ${v ? "삭제됨" : "—"}`;
    if (k === "role") return `${label}: ${getUserRoleLabel(String(v))}`;
    const val = v === "" || v === null || v === undefined ? "—" : String(v);
    return `${label}: ${val}`;
  });

  return parts.join(" · ");
}

// list 응답 파싱: Array | {items} | {data} | {results} | {rows}
function asTotal(val: unknown): number | undefined {
  const record = asRecord(val);
  const total = safeNumber(record.total, Number.NaN);
  if (Number.isFinite(total)) return total;
  const count = safeNumber(record.count, Number.NaN);
  if (Number.isFinite(count)) return count;
  if (Array.isArray(val)) return val.length;
  return undefined;
}

type Role = "user" | "admin" | "superadmin";
interface UserDetail {
  id: string;
  email: string;
  name?: string;
  phone?: string;
  address?: string;
  addressDetail?: string;
  postalCode?: string;
  role: Role;
  isDeleted: boolean;
  isSuspended?: boolean;
  createdAt?: string;
  updatedAt?: string;
  lastLoginAt?: string;
  appsInTossLinked: boolean;
}

type AuditLog = {
  id?: string;
  action: string;
  detail?: string;
  at: string;
  by?: string;
  actorId?: unknown;
  actorName?: string | null;
  actorEmail?: string | null;
  actorRole?: string | null;
  diff?: {
    actorName?: string | null;
    actorEmail?: string | null;
    actorRole?: string | null;
    metadata?: {
      actor?: {
        id?: unknown;
        name?: string | null;
        email?: string | null;
        role?: string | null;
      } | null;
    } | null;
  } | null;
};

type UserPatchPayload = Partial<UserDetail> & { confirmText?: string };

function getRoleConfirmPhrase(before: Role, after: Role) {
  if (after === "superadmin" && before !== "superadmin") return "최고 관리자로 변경";
  if (before === "user" && after === "admin") return "관리자로 변경";
  if (isAdminRole(before) && after === "user") return "권한 변경";
  if (before === "superadmin" && after !== "superadmin") return "권한 변경";
  return "권한 변경";
}

function normalizeActorId(value: unknown): string | null {
  if (typeof value === "string") return value;
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    if (typeof record.$oid === "string") return record.$oid;
    if (typeof record.toString === "function") {
      const stringified = record.toString();
      if (typeof stringified === "string" && stringified !== "[object Object]") {
        return stringified;
      }
    }
  }
  return null;
}

function getAuditActorDisplay(log: AuditLog): {
  label: string;
  title?: string;
} {
  const actor = log?.diff?.metadata?.actor;
  const name = actor?.name ?? log?.diff?.actorName ?? log?.actorName ?? null;
  const email = actor?.email ?? log?.diff?.actorEmail ?? log?.actorEmail ?? null;
  const role = actor?.role ?? log?.diff?.actorRole ?? log?.actorRole ?? null;
  const actorId =
    normalizeActorId(actor?.id) ?? normalizeActorId(log?.actorId) ?? normalizeActorId(log?.by);

  const principal = name ? (email ? `${name} <${email}>` : name) : email;

  if (principal) {
    return {
      label: role ? `${principal} · ${role}` : principal,
    };
  }

  if (actorId) {
    const shortId = actorId.length > 12 ? `${actorId.slice(0, 4)}...${actorId.slice(-4)}` : actorId;
    return { label: `actorId: ${shortId}`, title: actorId };
  }

  return { label: "알 수 없음" };
}

export default function UserDetailClient({ id }: { id: string }) {
  const { user: currentAdmin } = useCurrentUser();
  const { data, error, isLoading, mutate } = useSWR<UserDetail>(
    `/api/admin/users/${id}`,
    authenticatedSWRFetcher,
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    },
  );

  // 다음 주소 API
  type DaumPostcodeData = {
    zonecode?: string;
    roadAddress?: string;
    jibunAddress?: string;
  };
  type DaumPostcodeApi = {
    Postcode: new (options: { oncomplete: (data: DaumPostcodeData) => void }) => {
      open: () => void;
    };
  };
  type DaumWindow = typeof window & { daum?: DaumPostcodeApi };
  // 주소 팝업 핸들러
  const handleOpenPostcode = async () => {
    try {
      await loadDaumPostcode();
    } catch {
      showErrorToast("주소 검색 모듈을 불러오지 못했습니다. 잠시 후 다시 시도해주세요.");
      return;
    }
    const w = window as DaumWindow;
    if (!w.daum?.Postcode) return;
    new w.daum!.Postcode({
      oncomplete: (data: DaumPostcodeData) => {
        const postal = data.zonecode ?? "";
        const addr = data.roadAddress || data.jibunAddress || "";
        // 폼 상태 갱신(컨트롤드 값으로 바로 반영)
        setForm((prev) => ({
          ...prev,
          postalCode: postal,
          address: addr,
          addressDetail: "", // 상세주소는 비워두기
        }));
      },
    }).open();
  };

  // 비밀번호 초기화 다이얼로그 상태
  const [pwDialogOpen, setPwDialogOpen] = useState(false);
  const [tmpPw, setTmpPw] = useState<string | null>(null);

  // 비번 초기화 실행 전 입력 확인용
  const [pwConfirmOpen, setPwConfirmOpen] = useState(false);
  const [pwConfirmText, setPwConfirmText] = useState("");
  const [deleteConfirmText, setDeleteConfirmText] = useState("");
  const [roleConfirmOpen, setRoleConfirmOpen] = useState(false);
  const [roleConfirmText, setRoleConfirmText] = useState("");
  const [pendingRolePatch, setPendingRolePatch] = useState<UserPatchPayload | null>(null);

  // KPI
  const { data: kpi } = useSWR<{
    orders: number;
    applications: number;
    reviews: number;
  }>(`/api/admin/users/${id}/kpi`, authenticatedSWRFetcher, {
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
  });

  // 최근 항목
  const { data: ordersResp } = useSWR<unknown>(
    `/api/admin/users/${id}/orders?limit=5`,
    authenticatedSWRFetcher,
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    },
  );
  const { data: appsResp } = useSWR<unknown>(
    `/api/admin/users/${id}/applications/stringing?limit=5`,
    authenticatedSWRFetcher,
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    },
  );
  const { data: reviewsResp } = useSWR<unknown>(
    `/api/admin/users/${id}/reviews?limit=5`,
    authenticatedSWRFetcher,
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    },
  );
  const { data: auditResp } = useSWR<{ items?: AuditLog[] } | AuditLog[] | null>(
    `/api/admin/users/${id}/audit?limit=5`,
    authenticatedSWRFetcher,
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
    },
  );
  const { data: sessionsResp, mutate: mutateSessions } = useUserSessions(id, 5);
  const orders = safeArray(ordersResp);
  const apps = safeArray(appsResp);
  const reviews = safeArray(reviewsResp);

  // 세션 정리
  const [cleanupOpen, setCleanupOpen] = useState(false);
  const [cleanupDays, setCleanupDays] = useState<"0" | "30" | "90" | "180">("90"); // 기본 90일

  //kpi 안전 가드
  const kpiSafe = useMemo(
    () => ({
      orders: kpi?.orders ?? asTotal(ordersResp) ?? orders?.length ?? 0,
      applications: kpi?.applications ?? asTotal(appsResp) ?? apps?.length ?? 0,
      reviews: kpi?.reviews ?? asTotal(reviewsResp) ?? reviews?.length ?? 0,
    }),
    [kpi, ordersResp, appsResp, reviewsResp, orders, apps, reviews],
  );

  const [localAudit, setLocalAudit] = useState<AuditLog[]>([]);
  const audit: AuditLog[] = Array.isArray(auditResp) ? auditResp : (auditResp?.items ?? []);
  const auditMerged = [...(audit || []), ...localAudit]
    .sort((a, b) => +new Date(b.at) - +new Date(a.at))
    .slice(0, 5);

  // 폼 로컬 상태 (미저장 변경 탐지)
  const [form, setForm] = useState<Partial<UserDetail>>({});
  const hasDirty = useMemo(() => Object.keys(form).length > 0, [form]);
  const confirmLeaveIfDirty = () => !hasDirty || window.confirm(UNSAVED_CHANGES_MESSAGE);

  // 입력 중 이탈 방지(뒤로가기/탭닫기/링크이동)
  useUnsavedChangesGuard(hasDirty);

  const user = data;
  const currentAdminRole = String(currentAdmin?.role ?? "");
  const isCurrentSuperAdmin = isSuperAdminRole(currentAdminRole);
  const isSelf = currentAdmin?.id ? String(currentAdmin.id) === id : false;
  const onChange = (k: keyof UserDetail, v: UserDetail[keyof UserDetail]) =>
    setForm((prev) => ({ ...prev, [k]: v }));

  const [pending, setPending] = useState(false);

  function pushAudit(action: string, detail?: string) {
    setLocalAudit((prev) =>
      [{ action, detail, at: new Date().toISOString(), by: "admin" }, ...prev].slice(0, 5),
    );
  }

  // 서버 PATCH
  async function patchUser(patch: UserPatchPayload, auditLabel?: string) {
    try {
      setPending(true);
      const result = await runAdminActionWithToast({
        action: () =>
          adminMutator(`/api/admin/users/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(patch),
          }),
        successMessage: "저장되었습니다.",
        fallbackErrorMessage: "처리 중 오류",
      });
      if (!result) return;
      if (auditLabel) pushAudit(auditLabel, JSON.stringify(patch));
    } finally {
      setPending(false);
    }
  }

  // 폼 저장
  const save = async () => {
    if (!hasDirty || pending) return;

    const patch = { ...form };
    const nextRole = patch.role;
    if (nextRole && user && nextRole !== user.role) {
      if (!isCurrentSuperAdmin || isSelf) return;
      setPendingRolePatch(patch);
      setRoleConfirmText("");
      setRoleConfirmOpen(true);
      return;
    }

    await submitPatch(patch);
  };

  const submitPatch = async (patch: UserPatchPayload) => {
    try {
      setPending(true);

      const result = await runAdminActionWithToast({
        action: () =>
          adminMutator(`/api/admin/users/${id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(patch),
          }),
        successMessage: "저장되었습니다.",
        fallbackErrorMessage: "저장에 실패했습니다.",
      });

      if (!result) return;

      await mutate();
      pushAudit("프로필 수정", JSON.stringify(patch));
      setForm({});
    } finally {
      setPending(false);
    }
  };

  // 소프트 삭제
  const softDelete = async () => {
    try {
      await patchUser({ isDeleted: true }, "탈퇴(삭제)");
      await mutate();
    } catch {
      /* handled */
    }
  };

  // 복사 유틸
  const copy = async (txt: string) => {
    try {
      await navigator.clipboard.writeText(txt);
      showSuccessToast("클립보드에 복사되었습니다.");
    } catch {
      showErrorToast("복사 실패");
    }
  };

  // 상태 -> StatusBadge 매핑
  const statusKey = (u?: UserDetail) =>
    !u ? "active" : u.isDeleted ? "deleted" : u.isSuspended ? "suspended" : "active";

  const fmt = (iso?: string) =>
    iso
      ? new Date(iso).toLocaleString("ko-KR", {
          dateStyle: "medium",
          timeStyle: "short",
        })
      : "-";

  if (error) {
    return (
      <AsyncState
        kind="error"
        tone="admin"
        variant="page-center"
        resourceName="회원 상세"
        onAction={() => {
          void mutate();
        }}
      />
    );
  }

  const isInitialLoading = isLoading && !data;

  if (isInitialLoading) {
    return (
      <div className="relative">
        <div
          aria-hidden
          className={[
            "pointer-events-none absolute inset-0 -z-10",
            "bg-muted/30",
            "before:content-[''] before:absolute before:inset-0 before:bg-border/10 before:opacity-30",
          ].join(" ")}
        />
        <div className="sticky top-[64px] z-20 -mx-2 px-2 pt-2 pb-3 border-b border-border bg-card/80 dark:bg-card backdrop-blur supports-[backdrop-filter]:bg-card supports-[backdrop-filter]:dark:bg-card">
          <div className="mx-auto w-full max-w-[1500px] flex items-center justify-between gap-2">
            <Skeleton className="h-9 w-28" />
            <div className="flex items-center gap-2">
              <Skeleton className="h-9 w-20" />
              <Skeleton className="h-9 w-20" />
              <Skeleton className="h-9 w-24" />
            </div>
          </div>
        </div>
        <div className="mx-auto w-full max-w-[1500px] p-6 space-y-6">
          <div className="grid gap-4 grid-cols-3">
            <Skeleton className="h-28 rounded-xl" />
            <Skeleton className="h-28 rounded-xl" />
            <Skeleton className="h-28 rounded-xl" />
          </div>
          <div className="grid gap-6 grid-cols-[1.4fr_1fr]">
            <Skeleton className="h-[460px] rounded-xl" />
            <Skeleton className="h-[460px] rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <AsyncState
        kind="empty"
        tone="admin"
        variant="page-center"
        resourceName="회원 상세"
        title="회원 정보를 찾을 수 없습니다"
        description="회원 ID를 확인한 뒤 다시 시도해 주세요."
      />
    );
  }

  const roleValue = form.role ?? user.role;
  const roleChanged = roleValue !== user.role;
  const roleConfirmPhrase = roleChanged ? getRoleConfirmPhrase(user.role, roleValue) : "";
  const deleteConfirmPhrase = user.email?.trim() || "회원 삭제";
  const canUseDangerousUserActions = isCurrentSuperAdmin && !isSelf;
  const dangerousActionDisabledReason = isSelf
    ? "자기 자신의 권한 변경과 삭제는 할 수 없습니다."
    : !isCurrentSuperAdmin
      ? "권한 변경과 삭제는 최고 관리자만 가능합니다."
      : "";

  // 비밀번호 초기화
  async function resetPassword() {
    try {
      setPending(true);
      const json = await runAdminActionWithToast<{ tempPassword?: string }>({
        action: () =>
          adminMutator(`/api/admin/users/${id}/password/reset`, {
            method: "POST",
          }),
        successMessage: "임시 비밀번호가 생성되었습니다.",
        fallbackErrorMessage: "초기화 실패",
      });
      if (!json) return;

      setTmpPw(json?.tempPassword || null); // 한 번만 보여줄 PW
      setPwDialogOpen(true);
      pushAudit("비밀번호 초기화");
    } finally {
      setPending(false);
    }
  }

  // 세션 정리 모달
  async function cleanupSessions() {
    try {
      setPending(true);
      const json = await runAdminActionWithToast<{ deleted?: number }>({
        action: () =>
          adminMutator(`/api/admin/users/${id}/sessions/cleanup`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ olderThanDays: Number(cleanupDays) }),
          }),
        fallbackErrorMessage: "정리에 실패했습니다.",
      });
      if (!json) return;
      showSuccessToast(`세션 로그 ${json?.deleted ?? 0}건 정리 완료`);
      setCleanupOpen(false);
      await mutateSessions(); // 최신 세션 목록 새로고침
    } finally {
      setPending(false);
    }
  }

  return (
    <AdminPageShell variant="wide" className="space-y-4">
      <TooltipProvider>
        <AdminPageHeader
          variant="detail"
          title={user.name ?? "(이름없음)"}
          description={`${user.email} 회원 정보를 관리합니다.`}
          icon={UserCog}
          scope={`회원 ID: ${user.id}`}
          helperText={`가입일 ${fmt(user.createdAt)} · 마지막 로그인 ${fmt(sessionsResp?.items?.[0]?.at ?? user.lastLoginAt)}`}
          className="flex-wrap"
          actions={
            <>
              {(() => {
                const roleSpec = getUserRoleBadgeSpec(user.role);
                return <Badge variant={roleSpec.variant}>{getUserRoleLabel(user.role)}</Badge>;
              })()}
              <StatusBadge status={statusKey(user)} />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => copy(user.id)}
                title={user.id}
              >
                ID 복사
              </Button>
              <Button type="button" variant="outline" size="sm" asChild>
                <Link
                  href="/admin/users"
                  data-no-unsaved-guard
                  onClick={(event) => {
                    if (!confirmLeaveIfDirty()) event.preventDefault();
                  }}
                >
                  <ChevronLeft className="mr-1 h-4 w-4" />
                  회원 목록
                </Link>
              </Button>
              <Button
                type="button"
                variant={hasDirty ? "destructive" : "outline"}
                size="sm"
                onClick={() => setForm({})}
                disabled={!hasDirty}
              >
                {hasDirty ? "편집 취소" : "편집 중"}
              </Button>
            </>
          }
        />

        <AdminDetailSectionNav
          items={[
            { href: "#admin-user-account", label: "기본정보" },
            { href: "#admin-user-danger", label: "권한·상태" },
            { href: "#admin-user-activity", label: "활동" },
            { href: "#admin-user-security", label: "세션" },
            { href: "#admin-user-audit", label: "감사 로그" },
            { href: "#admin-user-notes", label: "내부 메모" },
          ]}
        />

        {/* 상단 스티키 액션바 */}
        <div className="sticky top-[64px] z-20 -mx-2 px-2 pt-2 pb-3 border-b border-border bg-card/80 dark:bg-card backdrop-blur supports-[backdrop-filter]:bg-card supports-[backdrop-filter]:dark:bg-card">
          <div className="mx-auto flex w-full max-w-[1500px] flex-wrap items-center justify-end gap-2">
            {/* 모든 주요 액션 */}
            <div className="flex flex-wrap items-center gap-2">
              {/* 비활성/해제 토글 */}
              <Button
                type="button"
                variant="outline"
                className="whitespace-nowrap shrink-0"
                disabled={pending}
                onClick={async () => {
                  const next = !user.isSuspended;
                  await patchUser({ isSuspended: next }, next ? "비활성화" : "비활성 해제");
                  await mutate();
                }}
              >
                {user.isSuspended ? "비활성 해제" : "비활성화"}
              </Button>

              {/* 비밀번호 초기화 (실수 방지: 확인 다이얼로그 1단계) */}
              <AlertDialog
                open={pwConfirmOpen}
                onOpenChange={(o) => {
                  setPwConfirmOpen(o);
                  if (!o) setPwConfirmText("");
                }}
              >
                <AlertDialogTrigger asChild>
                  <Button
                    type="button"
                    variant="secondary"
                    className="whitespace-nowrap shrink-0"
                    disabled={pending || (isAdminRole(user.role) && !isCurrentSuperAdmin) || isSelf}
                  >
                    비밀번호 초기화
                  </Button>
                </AlertDialogTrigger>

                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>비밀번호 초기화 실행</AlertDialogTitle>
                    <AlertDialogDescription>
                      이 회원의 비밀번호를 임시 비밀번호로 재설정합니다. 실행 즉시{" "}
                      <b>임시 비밀번호가 1회 표시</b>되며, 사용자는 로그인 후 비밀번호 변경이{" "}
                      <b>강제</b>됩니다.
                      <br />
                      실수 클릭 방지를 위해 아래 확인 문구를 입력해 주세요.
                    </AlertDialogDescription>
                  </AlertDialogHeader>

                  <div className="space-y-2">
                    <Label>확인 문구</Label>
                    <div className="text-xs text-muted-foreground">
                      아래 입력창에 <code>초기화</code> 라고 입력하면 실행 버튼이 활성화됩니다.
                    </div>
                    <Input
                      value={pwConfirmText}
                      onChange={(e) => setPwConfirmText(e.target.value)}
                      placeholder="초기화"
                    />
                  </div>

                  <AlertDialogFooter>
                    <AlertDialogCancel>취소</AlertDialogCancel>
                    <AlertDialogAction
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      disabled={pwConfirmText !== "초기화" || pending}
                      onClick={async () => {
                        await resetPassword(); // ← 실제 초기화 호출(기존 함수 그대로 사용)
                        setPwConfirmOpen(false); // 다이얼로그 닫기
                        setPwConfirmText(""); // 입력값 초기화
                      }}
                    >
                      초기화 실행
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              {/* 탈퇴(삭제) */}
              {user.isDeleted ? (
                <Button variant="secondary" className="whitespace-nowrap shrink-0" disabled>
                  삭제됨
                </Button>
              ) : (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      type="button"
                      variant="destructive"
                      className="whitespace-nowrap shrink-0"
                      disabled={pending || !canUseDangerousUserActions}
                    >
                      탈퇴(삭제)
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>탈퇴(삭제) 처리</AlertDialogTitle>
                      <AlertDialogDescription>
                        이 회원을 삭제(탈퇴) 처리합니다. 진행 후에는 복구할 수 없습니다.
                        {user.appsInTossLinked && (
                          <>
                            <br />
                            이 회원은 Apps in Toss 로그인과 연결되어 있습니다. 삭제하면 해당
                            사용자의 도깨비테니스 미니앱 로그인이 차단됩니다.
                          </>
                        )}
                        <br />
                        아래 입력창에 <code>{deleteConfirmPhrase}</code> 를 정확히 입력해 주세요.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <div className="space-y-2">
                      <Label htmlFor="deleteConfirmText">확인 문구</Label>
                      <Input
                        id="deleteConfirmText"
                        value={deleteConfirmText}
                        onChange={(e) => setDeleteConfirmText(e.target.value)}
                        placeholder={deleteConfirmPhrase}
                      />
                    </div>
                    <AlertDialogFooter>
                      <AlertDialogCancel>취소</AlertDialogCancel>
                      <AlertDialogAction
                        disabled={deleteConfirmText !== deleteConfirmPhrase || pending}
                        onClick={async () => {
                          await patchUser(
                            { isDeleted: true, confirmText: deleteConfirmText },
                            "탈퇴(삭제)",
                          );
                          setDeleteConfirmText("");
                          await mutate();
                        }}
                      >
                        삭제(탈퇴) 실행
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}

              {/* 저장 */}
              {hasDirty && <Badge variant="outline">미저장 변경</Badge>}
              <Button type="button" onClick={save} disabled={pending || !hasDirty}>
                {pending ? "저장 중..." : "저장"}
              </Button>
            </div>
          </div>
        </div>

        <AlertDialog
          open={roleConfirmOpen}
          onOpenChange={(open) => {
            setRoleConfirmOpen(open);
            if (!open) {
              setRoleConfirmText("");
              setPendingRolePatch(null);
            }
          }}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>회원 권한 변경 확인</AlertDialogTitle>
              <AlertDialogDescription>
                회원 권한을 <b>{getUserRoleLabel(user.role)}</b>에서{" "}
                <b>{getUserRoleLabel(roleValue)}</b>로 변경합니다.
                <br />
                아래 입력창에 <code>{roleConfirmPhrase}</code> 를 정확히 입력해 주세요.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <div className="space-y-2">
              <Label htmlFor="roleConfirmText">확인 문구</Label>
              <Input
                id="roleConfirmText"
                value={roleConfirmText}
                onChange={(e) => setRoleConfirmText(e.target.value)}
                placeholder={roleConfirmPhrase}
              />
            </div>
            <AlertDialogFooter>
              <AlertDialogCancel>취소</AlertDialogCancel>
              <AlertDialogAction
                disabled={roleConfirmText !== roleConfirmPhrase || pending || !pendingRolePatch}
                onClick={async () => {
                  if (!pendingRolePatch) return;
                  await submitPatch({ ...pendingRolePatch, confirmText: roleConfirmText });
                  setRoleConfirmOpen(false);
                  setRoleConfirmText("");
                  setPendingRolePatch(null);
                }}
              >
                권한 변경 실행
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* 좌: 요약/보안/액티비티 KPI/최근 항목 탭  |  우: 프로필 수정 */}
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-[minmax(0,1.15fr)_minmax(22rem,0.85fr)]">
          {/* 좌측 스택 */}
          <div className="space-y-6">
            {/* 계정 요약 */}
            <div id="admin-user-account">
              <Section>
                <SectionHeader
                  title="계정 요약"
                  aside={<UserCog className="h-4 w-4 text-muted-foreground" />}
                />
                <SectionBody className="space-y-3">
                  <InfoItem
                    icon={<Phone className="h-3.5 w-3.5" />}
                    label="전화"
                    value={
                      user.phone ? (
                        <a
                          className="underline decoration-dotted"
                          data-no-unsaved-guard
                          href={`tel:${user.phone}`}
                        >
                          {formatKoreanPhone(user.phone) || user.phone}
                        </a>
                      ) : (
                        <span className="text-muted-foreground">미등록</span>
                      )
                    }
                    onCopy={user.phone ? () => copy(user.phone!) : undefined}
                    mono
                  />
                  <InfoItem
                    icon={<MapPin className="h-3.5 w-3.5" />}
                    label="주소"
                    value={
                      user.address ? (
                        <span className="break-words">
                          {user.address} {user.addressDetail ? ` ${user.addressDetail}` : ""}{" "}
                          {user.postalCode ? ` [${user.postalCode}]` : ""}
                        </span>
                      ) : (
                        <span className="text-muted-foreground">미등록</span>
                      )
                    }
                    onCopy={
                      user.address || user.postalCode
                        ? () =>
                            copy(
                              `${user.address ?? ""} ${user.addressDetail ?? ""} ${user.postalCode ? `[${user.postalCode}]` : ""}`.trim(),
                            )
                        : undefined
                    }
                  />
                </SectionBody>
              </Section>
            </div>

            <div id="admin-user-notes">
              <AdminInternalNotesCard targetType="user" targetId={user.id} />
            </div>

            {/* 보안 & 최근 활동 */}
            <div id="admin-user-security">
              <Section>
                <SectionHeader
                  title="보안 & 최근 활동"
                  aside={<ShieldAlert className="h-4 w-4 text-muted-foreground" />}
                />
                <SectionBody className="space-y-3">
                  <InfoItem
                    icon={<CalendarDays className="h-3.5 w-3.5" />}
                    label="가입일"
                    value={fmt(user.createdAt)}
                  />
                  <InfoItem
                    icon={<LogIn className="h-3.5 w-3.5" />}
                    label="마지막 로그인"
                    value={
                      <>
                        <span className="block">
                          {fmt(sessionsResp?.items?.[0]?.at ?? user.lastLoginAt)}
                        </span>
                        <span className="block text-xs text-muted-foreground">
                          {fromNowK(sessionsResp?.items?.[0]?.at ?? user.lastLoginAt)}
                        </span>
                      </>
                    }
                  />

                  {/* 최근 로그인 장치 */}
                  <div className="mt-2 rounded-xl border bg-card border-border p-2">
                    <div className="mb-2 flex items-center justify-between">
                      <div className="text-sm font-medium text-foreground">최근 로그인 장치</div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCleanupOpen(true)}
                        className="whitespace-nowrap"
                      >
                        세션 로그 정리
                      </Button>
                    </div>

                    {sessionsResp?.items?.length ? (
                      <div className="space-y-2">
                        {sessionsResp.items.map((s, i) => (
                          <SessionRow key={i} s={s} highlight={i === 0} />
                        ))}
                      </div>
                    ) : (
                      <AdminInlineEmpty>최근 로그인 기록이 없습니다.</AdminInlineEmpty>
                    )}
                  </div>
                </SectionBody>
              </Section>
            </div>

            <AlertDialog open={cleanupOpen} onOpenChange={setCleanupOpen}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>세션 로그 정리</AlertDialogTitle>
                  <AlertDialogDescription>
                    선택한 기간 <b>이전</b>의 로그인 세션 기록을 영구 삭제합니다. 현재 로그인
                    세션에는 영향이 없습니다.
                  </AlertDialogDescription>
                </AlertDialogHeader>

                <div className="mt-2 space-y-3">
                  <RadioGroup
                    value={cleanupDays}
                    onValueChange={(v: "0" | "30" | "90" | "180") => setCleanupDays(v)}
                  >
                    <div className="flex items-center gap-2">
                      <RadioGroupItem id="days30" value="30" />
                      <Label htmlFor="days30">30일 이전 로그 삭제</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <RadioGroupItem id="days90" value="90" />
                      <Label htmlFor="days90">90일 이전 로그 삭제</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <RadioGroupItem id="days180" value="180" />
                      <Label htmlFor="days180">180일 이전 로그 삭제</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <RadioGroupItem id="days0" value="0" />
                      <Label htmlFor="days0" className="text-destructive">
                        전체 삭제
                      </Label>
                    </div>
                  </RadioGroup>
                  <p className="text-xs text-muted-foreground">
                    * 삭제 후에는 복구할 수 없습니다. 감사 로그에 삭제 내역이 기록됩니다.
                  </p>
                </div>

                <AlertDialogFooter>
                  <AlertDialogCancel>취소</AlertDialogCancel>
                  <AlertDialogAction
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    onClick={cleanupSessions}
                  >
                    삭제 실행
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            {/* 액티비티 KPI */}
            <div id="admin-user-activity">
              <Section>
                <SectionHeader
                  title="액티비티"
                  aside={<ActivityIcon className="h-4 w-4 text-muted-foreground" />}
                />
                <SectionBody>
                  <div className="grid gap-3 grid-cols-3">
                    <StatCard
                      tone="emerald"
                      icon={<ShoppingBag className="h-4 w-4" />}
                      label="주문"
                      value={kpiSafe.orders}
                      href="/admin/orders"
                    />
                    <StatCard
                      tone="sky"
                      icon={<Wrench className="h-4 w-4" />}
                      label="신청(스트링)"
                      value={kpiSafe.applications}
                      href="/admin/applications/stringing"
                    />
                    <StatCard
                      tone="violet"
                      icon={<Star className="h-4 w-4" />}
                      label="리뷰"
                      value={kpiSafe.reviews}
                      href="/admin/reviews"
                    />
                  </div>
                </SectionBody>
              </Section>
            </div>

            {/* 최근 항목 탭 (주문/신청/리뷰) */}
            <Section>
              <SectionHeader
                title={
                  <div>
                    <div>최근 항목</div>
                    <div className="mt-1 text-xs text-muted-foreground font-normal">
                      * 최근 5개만 표시됩니다.
                    </div>
                  </div>
                }
                aside={<ListTree className="h-4 w-4 text-muted-foreground" />}
              />
              <SectionBody>
                <UserActivityTabsSection
                  orders={orders}
                  apps={apps}
                  reviews={reviews}
                  MiniList={MiniList}
                  Row={Row}
                />
              </SectionBody>
            </Section>

            {/* 감사 로그 (Audit) */}
            <div id="admin-user-audit">
              <Section>
                <SectionHeader
                  title={
                    <div>
                      <div>변경 이력</div>
                      <div className="mt-1 text-xs text-muted-foreground font-normal">
                        * 최근 5개만 표시됩니다.
                      </div>
                    </div>
                  }
                  aside={<Pencil className="h-4 w-4 text-muted-foreground" />}
                />
                <SectionBody>
                  <MiniList
                    empty="변경 이력이 없습니다."
                    items={auditMerged}
                    render={(log: AuditLog) => (
                      <Row
                        title={log.action}
                        subtitle={[
                          getAuditActorDisplay(log).label,
                          humanizeAuditDetail(log.action, log.detail),
                        ]
                          .filter(Boolean)
                          .join(" · ")}
                        right={new Date(log.at).toLocaleString("ko-KR", {
                          dateStyle: "short",
                          timeStyle: "short",
                        })}
                      />
                    )}
                  />
                </SectionBody>
              </Section>
            </div>
          </div>

          {/* 우측: 프로필 수정 */}
          <div id="admin-user-danger" className="space-y-6">
            <Section>
              <SectionHeader
                title={
                  <div className="flex items-center gap-2">
                    <span>프로필 수정</span>
                    {hasDirty && <Badge variant="outline">미저장 변경</Badge>}
                  </div>
                }
                aside={<RefreshCw className="h-4 w-4 text-muted-foreground" />}
              />
              <SectionBody>
                <div className="grid gap-4 grid-cols-2">
                  <FormRow label="이름" htmlFor="name">
                    <Input
                      id="name"
                      value={form.name ?? user.name ?? ""}
                      onChange={(e) => onChange("name", e.target.value)}
                    />
                  </FormRow>

                  <FormRow label="권한" htmlFor="role">
                    <select
                      id="role"
                      className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                      value={roleValue}
                      disabled={!canUseDangerousUserActions}
                      onChange={(e) => onChange("role", e.target.value as Role)}
                    >
                      <option value="user">일반</option>
                      <option value="admin">관리자</option>
                      <option value="superadmin">최고 관리자</option>
                    </select>
                    {dangerousActionDisabledReason ? (
                      <p className="mt-1 text-xs text-muted-foreground">
                        {dangerousActionDisabledReason}
                      </p>
                    ) : null}
                    {roleChanged ? (
                      <p className="mt-1 text-xs text-muted-foreground">
                        저장 시 확인 문구 <code>{roleConfirmPhrase}</code> 입력이 필요합니다.
                      </p>
                    ) : null}
                  </FormRow>

                  <FormRow label="전화번호" htmlFor="phone">
                    <Input
                      id="phone"
                      value={form.phone ?? user.phone ?? ""}
                      onChange={(e) => onChange("phone", e.target.value)}
                    />
                  </FormRow>

                  {/* 우편번호 */}
                  <FormRow label="우편번호" htmlFor="postal">
                    <div className="flex gap-2">
                      <Input
                        id="postal"
                        readOnly
                        aria-readonly
                        value={form.postalCode ?? user.postalCode ?? ""}
                        className="bg-muted/40 text-foreground"
                        onClick={handleOpenPostcode} // 클릭만으로도 검색 열기 원하면 유지
                      />
                      <Button
                        variant="outline"
                        className="shrink-0 whitespace-nowrap"
                        onClick={handleOpenPostcode}
                      >
                        주소 검색
                      </Button>
                    </div>
                  </FormRow>

                  {/* 주소 */}
                  <FormRow label="주소" htmlFor="addr" colSpan>
                    <Input
                      id="addr"
                      readOnly
                      aria-readonly
                      value={form.address ?? user.address ?? ""}
                      className="bg-muted/40 text-foreground"
                      onClick={handleOpenPostcode}
                    />
                  </FormRow>

                  {/* 상세주소 */}
                  <FormRow label="상세주소" htmlFor="addr2" colSpan>
                    <Input
                      id="addr2"
                      value={form.addressDetail ?? user.addressDetail ?? ""}
                      onChange={(e) => onChange("addressDetail", e.target.value)}
                      placeholder="동/호수, 층 등"
                    />
                  </FormRow>
                </div>

                {/* 상태 토글 */}
                <div className="mt-5 flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="ghost"
                    className="whitespace-nowrap"
                    disabled={!hasDirty || pending}
                    onClick={() => setForm({})}
                  >
                    변경사항 되돌리기
                  </Button>

                  <Button
                    type="button"
                    className="whitespace-nowrap"
                    disabled={!hasDirty || pending}
                    onClick={save}
                  >
                    {pending ? "저장 중..." : "프로필 저장"}
                  </Button>
                </div>
              </SectionBody>
            </Section>
          </div>
        </div>

        {/* 임시 비밀번호 안내 모달 */}
        <AlertDialog
          open={pwDialogOpen}
          onOpenChange={(o) => {
            setPwDialogOpen(o);
            if (!o) setTmpPw(null); // 닫을 때 메모리에서 지움 (보안)
          }}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>임시 비밀번호</AlertDialogTitle>
              <AlertDialogDescription>
                아래 비밀번호는 <b>이번 한 번만</b> 표시됩니다. 사용자가 로그인한 후 비밀번호를
                변경하도록 안내하세요.
              </AlertDialogDescription>
            </AlertDialogHeader>

            <div className="space-y-2">
              <Label>생성된 임시 비밀번호</Label>
              <div className="flex items-center gap-2">
                <Input readOnly value={tmpPw ?? ""} />
                <Button variant="outline" onClick={() => tmpPw && copy(tmpPw)}>
                  복사
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                * 서버에는 해시만 저장됩니다. 이 값은 창을 닫으면 다시 볼 수 없습니다.
              </p>
            </div>

            <AlertDialogFooter>
              <AlertDialogCancel>닫기</AlertDialogCancel>
              <AlertDialogAction onClick={() => setPwDialogOpen(false)}>확인</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </TooltipProvider>
    </AdminPageShell>
  );
}

/* -----------작은 조각들 모음--------------  */

// 상대시간 포맷: "5분 전", "3시간 전", "2일 전"
function fromNowK(iso?: string) {
  if (!iso) return "";
  const d = new Date(iso).getTime();
  const diff = Math.max(0, Date.now() - d);
  const m = Math.floor(diff / 60000);
  if (m < 1) return "방금 전";
  if (m < 60) return `${m}분 전`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}시간 전`;
  const day = Math.floor(h / 24);
  return `${day}일 전`;
}

// IP 표기 정규화
function normalizeIp(ip?: string) {
  if (!ip) return "-";
  const t = ip.trim().toLowerCase();
  // IPv6 loopback → 로컬
  if (t === "::1" || t === "0:0:0:0:0:0:0:1") return "127.0.0.1 (로컬)";
  // IPv4-mapped IPv6 → 순수 IPv4 추출 (::ffff:192.168.0.10)
  const v4 = t.match(/::ffff:(\d+\.\d+\.\d+\.\d+)/)?.[1];
  if (v4) return v4;
  return t; // 나머지 IPv6는 그대로
}

// 한 줄 UI
function SessionRow({
  s,
  highlight = false,
}: {
  s: { at: string; ip: string; os: string; browser: string; isMobile: boolean };
  highlight?: boolean;
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-3 p-3 rounded-lg border",
        "border-border bg-card/80 dark:bg-card",
        highlight && "ring-1 ring-ring",
      )}
    >
      <div
        className={cn(
          "grid size-9 place-items-center rounded-lg",
          s.isMobile
            ? "bg-muted text-foreground dark:bg-muted dark:text-foreground"
            : "bg-muted text-foreground dark:bg-muted dark:text-foreground",
        )}
      >
        {s.isMobile ? (
          <Smartphone className="h-4 w-4" />
        ) : (
          <MonitorSmartphone className="h-4 w-4" />
        )}
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2 text-sm font-medium truncate">
          {s.browser} · {s.os}
          {highlight &&
            (() => {
              const currentSpec = getCurrentSessionBadgeSpec(true);
              return <Badge variant={currentSpec.variant}>현재</Badge>;
            })()}
          {(() => {
            const deviceSpec = getSessionDeviceBadgeSpec(s.isMobile ? "mobile" : "desktop");
            return (
              <Badge variant={deviceSpec.variant} className="inline-block">
                {s.isMobile ? "모바일" : "데스크탑"}
              </Badge>
            );
          })()}
        </div>
        <div className="mt-0.5 flex items-center justify-between gap-3 text-xs text-muted-foreground">
          <code className="rounded bg-background px-1.5 py-0.5 dark:bg-card">
            {normalizeIp(s.ip)}
          </code>
          <span className="shrink-0">
            {new Date(s.at).toLocaleString("ko-KR", {
              dateStyle: "medium",
              timeStyle: "short",
            })}{" "}
            · {fromNowK(s.at)}
          </span>
        </div>
      </div>
    </div>
  );
}

function FormRow({
  label,
  htmlFor,
  children,
  colSpan,
}: {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
  colSpan?: boolean;
}) {
  return (
    <div className={cn("space-y-2", colSpan && "col-span-2")}>
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  href,
  tone = "emerald", // 'emerald' | 'sky' | 'violet' | 'slate'
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  href?: string;
  tone?: "emerald" | "sky" | "violet" | "slate";
}) {
  const toneMap: Record<string, string> = {
    emerald: "bg-primary/10 text-primary dark:bg-primary/20 dark:text-primary",
    sky: "bg-muted text-foreground dark:bg-muted dark:text-foreground",
    violet: "bg-muted text-foreground dark:bg-muted dark:text-foreground",
    slate: "bg-background text-muted-foreground dark:bg-card dark:text-muted-foreground",
  };

  const content = (
    <div className="flex items-center gap-3 rounded-xl border border-border p-3 bg-card shadow-sm">
      <div className={cn("grid size-8 place-items-center rounded-lg", toneMap[tone])}>{icon}</div>
      <div className="flex-1">
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="text-base font-semibold">{value}</div>
      </div>
    </div>
  );

  return href ? (
    <Link
      href={href}
      target="_blank"
      rel="noreferrer"
      className="rounded-xl transition-[box-shadow,border-color,background-color] duration-200 hover:shadow-md"
    >
      {content}
    </Link>
  ) : (
    content
  );
}

function MiniList<T>({
  items,
  render,
  empty,
}: {
  items: T[];
  render: (item: T) => React.ReactNode;
  empty: string;
}) {
  if (!items?.length) {
    return <AdminInlineEmpty>{empty}</AdminInlineEmpty>;
  }
  return (
    <ul className="divide-y divide-border">
      {items.map((it, idx) => (
        <li key={idx} className="py-2">
          {render(it)}
        </li>
      ))}
    </ul>
  );
}

function Row({
  title,
  subtitle,
  right,
  href,
}: {
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  right?: React.ReactNode;
  href?: string;
}) {
  const core = (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0">
        <div className="truncate text-sm font-medium">{title}</div>
        {subtitle ? <div className="truncate text-xs text-muted-foreground">{subtitle}</div> : null}
      </div>
      {right ? (
        <div className="text-xs text-muted-foreground whitespace-nowrap">{right}</div>
      ) : null}
    </div>
  );
  return href ? (
    <Link
      href={href}
      target="_blank"
      rel="noreferrer"
      className="block hover:bg-background dark:hover:bg-card rounded-lg px-2 -mx-2 py-2 transition-colors"
    >
      {core}
    </Link>
  ) : (
    core
  );
}

function truncate(s = "", n = 80) {
  return s.length > n ? s.slice(0, n) + "…" : s;
}
