"use client";

import { useState } from "react";
import useSWR from "swr";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import AdminConfirmDialog from "@/components/admin/AdminConfirmDialog";
import { showSuccessToast, showErrorToast } from "@/lib/toast";
import { adminFetcher, adminMutator } from "@/lib/admin/adminFetcher";
import { runAdminActionWithToast } from "@/lib/admin/adminActionHelpers";
import {
  Wrench,
  Loader2,
  Database,
  ListChecks,
  RefreshCw,
  ShieldCheck,
  Lock,
  Unlock,
  Info,
} from "lucide-react";

type Action = "createIndexes" | "dedup" | "rebuildSummary" | "all";

type LockStatus = {
  locked: boolean;
  lockedUntil?: string;
  lockedBy?: string | null;
};

export default function AdminReviewMaintenancePanel() {
  const [loading, setLoading] = useState<Action | null>(null);
  const [lastResult, setLastResult] = useState<any>(null);
  const [lastRunAt, setLastRunAt] = useState<string | null>(null);
  const [pendingConfirm, setPendingConfirm] = useState<"dedup" | "all" | "unlock" | null>(null);

  const { data: lockStatus = { locked: false }, mutate: mutateLockStatus } = useSWR<LockStatus>(
    "/api/admin/reviews/maintenance",
    async (url: string) => {
      const payload = await adminFetcher<{
        locked?: boolean;
        lockedUntil?: string;
        lockedBy?: string | null;
      }>(url, { method: "GET" });
      return {
        locked: !!payload?.locked,
        lockedUntil: payload?.lockedUntil,
        lockedBy: payload?.lockedBy ?? null,
      };
    },
    {
      fallbackData: { locked: false },
      refreshInterval: loading ? 1500 : 0,
      revalidateOnFocus: false,
      shouldRetryOnError: false,
    },
  );

  async function run(action: Action) {
    setLoading(action);
    setLastResult(null);
    try {
      const json = await adminMutator<{
        ok?: boolean;
        error?: string;
        reason?: string;
        message?: string;
        duplicates?: { product?: number; rental?: number; service?: number };
        result?: unknown;
      }>("/api/admin/reviews/maintenance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });

      if (!json?.ok) {
        if (json?.reason === "duplicateReviewsDetected") {
          throw new Error(
            [
              "중복 후기가 발견되어 전체 유지보수를 중단했습니다.",
              `상품 후기 중복 그룹: ${json.duplicates?.product ?? 0}`,
              `대여 후기 중복 그룹: ${json.duplicates?.rental ?? 0}`,
              `교체서비스 후기 중복 그룹: ${json.duplicates?.service ?? 0}`,
              "먼저 중복 진단 결과를 확인한 뒤 별도 정리해 주세요.",
            ].join("\n"),
          );
        }
        if (json?.reason === "indexDefinitionMismatch") {
          throw new Error(
            "후기 인덱스 정의가 현재 정책과 다릅니다. 자동으로 삭제하거나 교체하지 않았습니다.",
          );
        }
        throw new Error(json?.message || json?.error || "실행 실패");
      }

      setLastResult(json.result);
      setLastRunAt(new Date().toLocaleString("ko-KR"));
      showSuccessToast("완료되었습니다.");
    } catch (e: any) {
      showErrorToast(e?.message || "실행 중 오류가 발생했습니다.");
    } finally {
      setLoading(null);
      // 실행이 끝났으니 최신 잠금 상태 반영
      mutateLockStatus();
    }
  }

  async function forceUnlock() {
    try {
      const result = await runAdminActionWithToast({
        action: () => adminMutator("/api/admin/reviews/maintenance", { method: "DELETE" }),
        successMessage: "잠금을 해제했습니다.",
        fallbackErrorMessage: "강제 해제 중 오류",
      });
      if (result) mutateLockStatus({ locked: false }, false);
    } catch (e: any) {
      showErrorToast(e?.message || "강제 해제 중 오류");
    }
  }

  const disabled = loading !== null;

  return (
    <Card className="border-0 shadow-md bg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Wrench className="h-5 w-5" />
          후기 유지보수
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="rounded-xl border border-warning/40 bg-warning/10 p-4" role="alert">
          <p className="font-semibold text-warning">실행 전 영향 범위를 확인하세요.</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-foreground">
            <li>인덱스·중복 후기·집계·작업 잠금 등 후기 관련 데이터를 변경합니다.</li>
            <li>전체 후기 데이터와 목록 노출 결과에 영향을 줄 수 있습니다.</li>
            <li>일부 정비 작업은 실행 후 자동으로 되돌릴 수 없습니다.</li>
            <li>실행 전에 대상 데이터, 최근 백업, 현재 작업 잠금 상태를 확인하세요.</li>
          </ul>
        </div>
        {/* 액션 버튼들 */}
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            onClick={() => run("createIndexes")}
            disabled={disabled}
            variant="outline"
          >
            {loading === "createIndexes" ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Database className="mr-2 h-4 w-4" />
            )}
            인덱스 보장
          </Button>
          <Button size="sm" onClick={() => setPendingConfirm("dedup")} disabled={disabled} variant="outline">
            {loading === "dedup" ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <ListChecks className="mr-2 h-4 w-4" />
            )}
            중복 후기 정리
          </Button>
          <Button
            size="sm"
            onClick={() => run("rebuildSummary")}
            disabled={disabled}
            variant="outline"
          >
            {loading === "rebuildSummary" ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="mr-2 h-4 w-4" />
            )}
            후기 요약 재집계
          </Button>
          <p className="basis-full text-ui-label text-muted-foreground">
            상품과 라켓 목록의 후기 수·평점을 상세 페이지의 공개 통합 후기 기준으로 다시 계산합니다.
          </p>
          <Button size="sm" onClick={() => setPendingConfirm("all")} disabled={disabled} variant="default">
            {loading === "all" ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <ShieldCheck className="mr-2 h-4 w-4" />
            )}
            전체 실행
          </Button>
        </div>

        {/* 잠금 상태 / 강제 해제 */}
        <div className="flex flex-wrap items-center gap-3 text-sm">
          {loading ? (
            <div className="inline-flex items-center gap-2 text-muted-foreground">
              <Lock className="h-4 w-4" />
              유지보수 실행 중… (다른 탭에서는 잠시 실행 불가)
            </div>
          ) : lockStatus.locked ? (
            <>
              <div className="inline-flex items-center gap-2 text-primary">
                <Lock className="h-4 w-4" />
                다른 유지보수 작업이 실행 중입니다.
                {lockStatus.lockedUntil && (
                  <span className="text-primary">
                    해제 예정: {new Date(lockStatus.lockedUntil).toLocaleString("ko-KR")}
                  </span>
                )}
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setPendingConfirm("unlock")}
                className="h-7 px-2 text-xs"
              >
                <Unlock className="h-3.5 w-3.5 mr-1" />
                강제 해제
              </Button>
            </>
          ) : lastRunAt ? (
            <div className="text-muted-foreground">마지막 실행: {lastRunAt}</div>
          ) : (
            <div className="text-muted-foreground">아직 실행 내역이 없습니다.</div>
          )}
          {!loading && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => mutateLockStatus()}
              className="h-7 px-2 text-xs"
            >
              새로고침
            </Button>
          )}
        </div>

        {/* 기능 설명 */}
        <div className="rounded-md bg-card p-3 text-sm text-foreground space-y-2">
          <div className="flex items-start gap-2">
            <Info className="mt-0.5 h-4 w-4 shrink-0" />
            <div>
              <span className="font-medium">인덱스 보장</span> — 리뷰 컬렉션에 필요한 인덱스를
              생성/갱신합니다. (예: 활성 리뷰 고유성 및 조회 성능용 인덱스)
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Info className="mt-0.5 h-4 w-4 shrink-0" />
            <div>
              <span className="font-medium">중복 후기 정리</span> — 동일 사용자·상품 조합에서 최신
              1개만 남기고 나머지는 소프트 삭제하여 중복을 제거합니다.
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Info className="mt-0.5 h-4 w-4 shrink-0" />
            <div>
              <span className="font-medium">후기 요약 재집계</span> — 상품과 라켓의 공개 후기
              평점·개수를 다시 계산하여 목록용 후기 요약 캐시를 갱신합니다.
            </div>
          </div>
        </div>

        {/* 결과 출력 */}
        {lastResult && (
          <pre className="mt-2 max-h-[360px] overflow-auto whitespace-pre-wrap break-words rounded-md bg-card p-3 text-xs [overflow-wrap:anywhere]">
            {JSON.stringify(lastResult, null, 2)}
          </pre>
        )}
      </CardContent>
      <AdminConfirmDialog
        open={pendingConfirm !== null}
        onOpenChange={(open) => !open && setPendingConfirm(null)}
        severity="danger"
        title={pendingConfirm === "dedup" ? "중복 후기 정리" : pendingConfirm === "all" ? "전체 유지보수 실행" : "작업 잠금 강제 해제"}
        description={pendingConfirm === "dedup"
          ? "작업명: 중복 후기 정리\n범위: 동일 사용자·대상의 중복 후기 전체(최신 1개 제외)\n자동 복구: 소프트 삭제되지만 자동 복구되지 않습니다.\n실행 중 다른 후기 유지보수 작업이 제한될 수 있습니다."
          : pendingConfirm === "all"
            ? "작업명: 전체 유지보수 실행\n범위: 후기 인덱스, 중복 후기 및 후기 요약 집계 전체\n자동 복구: 일부 변경은 자동 복구할 수 없습니다.\n실행 중 다른 후기 유지보수 작업이 제한될 수 있습니다."
            : "작업명: 작업 잠금 강제 해제\n범위: 현재 후기 유지보수 작업 잠금\n자동 복구: 해제한 잠금은 자동 복구되지 않습니다.\n실행 중인 작업이 있다면 다른 유지보수 작업과 겹칠 수 있습니다."
        }
        confirmText={pendingConfirm === "dedup" ? "중복 후기 정리 실행" : pendingConfirm === "all" ? "전체 유지보수 실행" : "작업 잠금 강제 해제"}
        eventKey={`review-maintenance-${pendingConfirm ?? "none"}`}
        onConfirm={() => {
          const action = pendingConfirm;
          setPendingConfirm(null);
          if (action === "dedup" || action === "all") void run(action);
          if (action === "unlock") void forceUnlock();
        }}
      />
    </Card>
  );
}
