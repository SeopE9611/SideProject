"use client";

import { useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import {
  Eye,
  EyeOff,
  RefreshCcw,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  ExternalLink,
  MessageSquare,
  ThumbsUp,
  BarChart3,
  FileText,
  AlertTriangle,
  Trash2,
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AdminSemanticBadge as Badge } from "@/components/admin/AdminSemanticBadge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import AdminFilterBar from "@/components/admin/AdminFilterBar";
import { adminDataTable } from "@/components/admin/AdminDataTable";
import { adminSurface, adminTypography } from "@/components/admin/admin-typography";
import { cn } from "@/lib/utils";
import { buildAdminBoardDetailUrl, buildBoardPublicUrl } from "@/lib/board-public-url-policy";
import { adminMutator } from "@/lib/admin/adminFetcher";
import {
  adminPostVisibilityBadgeVariant,
  adminReportStatusBadgeVariant,
} from "@/lib/badge-style";
import { showErrorToast, showSuccessToast } from "@/lib/toast";
import { authenticatedSWRFetcher } from "@/lib/fetchers/authenticatedSWRFetcher";

type PostItem = {
  id: string;
  type: string;
  postNo: number | null;
  title: string;
  nickname: string;
  status: "public" | "hidden";
  createdAt: string;
  views: number;
  likes: number;
  commentsCount: number;
};

type ReportItem = {
  id: string;
  targetType: "post" | "comment";
  boardType: string;
  reason: string;
  status: "pending" | "resolved" | "rejected";
  reporterNickname: string;
  reporterDisplay?: string;
  createdAt: string;
  resolvedAt: string | null;
  post: {
    id: string | null;
    title: string;
    postNo: number | null;
    status: string;
  } | null;
  comment: {
    id: string | null;
    content: string;
    nickname: string;
    status: string;
  } | null;
};

type PostsResponse = { items?: PostItem[]; total?: number };
type ReportsResponse = { items?: ReportItem[]; total?: number };

const boardLabel: Record<string, string> = {
  notice: "공지",
  qna: "Q&A",
  free: "자유",
  gear: "장비",
  market: "중고",
  hot: "인기",
  brand: "브랜드",
};

/**
 * 레거시 게시판 타입 별칭 맵.
 * - 서버/DB에 과거 데이터(brands)가 남아 있어도 관리자 화면 텍스트/배지가 깨지지 않도록 임시 유지한다.
 * - 신규 타입 표준은 brand이며, 필터 옵션 등 신규 입력은 brand만 노출한다.
 */
const legacyBoardTypeAlias: Record<string, string> = {
  brands: "brand",
};

/**
 * 화면 표기 전용 게시판 타입 정규화.
 * - 관리자 목록/신고 목록 badge 라벨 조회 시 사용한다.
 * - API 전송 타입까지 강제 치환하지 않고, 표시 계층에서만 별칭 호환을 보장한다.
 */
function resolveBoardLabel(type: string) {
  const nextType = legacyBoardTypeAlias[type] ?? type;
  return boardLabel[nextType] ?? type;
}

function fmt(dt: string) {
  try {
    return new Date(dt).toLocaleString("ko-KR");
  } catch {
    return dt;
  }
}

const LIMIT = 20;

function getBoardLinkBlockedReason(
  reason: "missing_type_route" | "private_post" | "missing_identifier" | null,
  hasAdminFallback: boolean,
) {
  if (reason === "private_post") {
    return hasAdminFallback
      ? "비공개/숨김 게시글은 공개 페이지로 이동할 수 없어 관리자 상세로 대체됩니다."
      : "비공개/숨김 게시글은 공개 페이지로 이동할 수 없습니다.";
  }

  if (reason === "missing_type_route") {
    return hasAdminFallback
      ? "게시판 타입 라우팅 규칙이 없어 관리자 상세로 대체됩니다."
      : "게시판 타입 라우팅 규칙이 없어 링크를 열 수 없습니다.";
  }

  if (reason === "missing_identifier") {
    return hasAdminFallback
      ? "공개 URL 식별자(postNo)가 없어 관리자 상세로 대체됩니다."
      : "공개 URL 식별자(postNo)가 없어 링크를 열 수 없습니다.";
  }

  return hasAdminFallback
    ? "공개 URL 생성 실패로 관리자 상세로 대체됩니다."
    : "링크를 생성할 수 없습니다.";
}

export default function BoardsClient() {
  const router = useRouter();
  const sp = useSearchParams();

  const tab = sp.get("tab") === "reports" ? "reports" : "posts";

  // 게시글 필터
  const [postType, setPostType] = useState<string>("all");
  const [postStatus, setPostStatus] = useState<string>("all");
  const [postQ, setPostQ] = useState<string>("");
  const [postPage, setPostPage] = useState<number>(1);

  // 신고 필터
  const [reportType, setReportType] = useState<string>("all");
  const [reportStatus, setReportStatus] = useState<string>("pending");
  const [reportQ, setReportQ] = useState<string>("");
  const [reportPage, setReportPage] = useState<number>(1);

  const postsUrl = useMemo(() => {
    const qs = new URLSearchParams({
      page: String(postPage),
      limit: String(LIMIT),
      type: postType,
      status: postStatus,
      q: postQ,
      sort: "createdAt",
      dir: "desc",
    });
    return `/api/admin/community/posts?${qs.toString()}`;
  }, [postPage, postType, postStatus, postQ]);

  const reportsUrl = useMemo(() => {
    const qs = new URLSearchParams({
      page: String(reportPage),
      limit: String(LIMIT),
      boardType: reportType,
      status: reportStatus,
      q: reportQ,
    });
    return `/api/admin/community/reports?${qs.toString()}`;
  }, [reportPage, reportType, reportStatus, reportQ]);

  const {
    data: postsData,
    error: postsErr,
    isLoading: postsLoading,
    mutate: mutatePosts,
  } = useSWR<PostsResponse>(tab === "posts" ? postsUrl : null, authenticatedSWRFetcher, {
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
  });

  const {
    data: reportsData,
    error: reportsErr,
    isLoading: reportsLoading,
    mutate: mutateReports,
  } = useSWR<ReportsResponse>(tab === "reports" ? reportsUrl : null, authenticatedSWRFetcher, {
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
  });

  const hasResolvedPostsData = !!postsData;
  const hasPostsDataError = !!postsErr;
  const hasResolvedPostsTotal = hasResolvedPostsData && typeof postsData?.total === "number";
  const postsRaw: PostItem[] | null = hasResolvedPostsData
    ? Array.isArray(postsData?.items)
      ? postsData.items
      : []
    : null;

  const posts: PostItem[] = useMemo(() => {
    return (postsRaw ?? []).map((item: any) => {
      // 서버 스키마 정합성: views/likes/commentsCount 실필드만 사용
      const views = Number(item?.views ?? 0);
      const likes = Number(item?.likes ?? 0);
      const commentsCount = Number(item?.commentsCount ?? 0);

      return {
        ...item,
        views: Number.isFinite(views) ? views : 0,
        likes: Number.isFinite(likes) ? likes : 0,
        commentsCount: Number.isFinite(commentsCount) ? commentsCount : 0,
      } as PostItem;
    });
  }, [postsRaw]);
  const postsTotal: number | null = hasResolvedPostsTotal ? (postsData?.total ?? 0) : null;
  const postsTotalPages = postsTotal === null ? null : Math.max(1, Math.ceil(postsTotal / LIMIT));

  const hasResolvedReportsData = !!reportsData;
  const hasReportsDataError = !!reportsErr;
  const hasResolvedReportsTotal = hasResolvedReportsData && typeof reportsData?.total === "number";
  const reports: ReportItem[] | null = hasResolvedReportsData
    ? Array.isArray(reportsData?.items)
      ? reportsData.items
      : []
    : null;
  const reportsTotal: number | null = hasResolvedReportsTotal ? (reportsData?.total ?? 0) : null;
  const reportsTotalPages =
    reportsTotal === null ? null : Math.max(1, Math.ceil(reportsTotal / LIMIT));

  const postsPublicCount = postsRaw ? posts.filter((p) => p.status === "public").length : null;
  const postsHiddenCount = postsRaw ? posts.filter((p) => p.status === "hidden").length : null;
  const reportsPendingCount = reports ? reports.filter((r) => r.status === "pending").length : null;

  const hasPostFilterApplied =
    postType !== "all" || postStatus !== "all" || postQ.trim().length > 0;
  const [selectedPostIds, setSelectedPostIds] = useState<string[]>([]);

  const currentPagePostIds = useMemo(() => posts.map((p) => p.id), [posts]);
  const currentPagePostIdSet = useMemo(() => new Set(currentPagePostIds), [currentPagePostIds]);

  useEffect(() => {
    setSelectedPostIds((prev) => {
      const next = prev.filter((id) => currentPagePostIdSet.has(id));
      const isSame = next.length === prev.length && next.every((id, index) => id === prev[index]);

      return isSame ? prev : next;
    });
  }, [currentPagePostIdSet]);

  const isCurrentPageAllSelected =
    posts.length > 0 && posts.every((p) => selectedPostIds.includes(p.id));

  const togglePostSelect = (postId: string) => {
    setSelectedPostIds((prev) =>
      prev.includes(postId) ? prev.filter((id) => id !== postId) : [...prev, postId],
    );
  };

  const toggleSelectAllCurrentPage = (checked: boolean) => {
    setSelectedPostIds(checked ? currentPagePostIds : []);
  };

  const deleteSelectedPosts = async () => {
    if (selectedPostIds.length === 0) return;
    const ok = window.confirm(
      `선택한 게시글 ${selectedPostIds.length}개를 삭제하시겠습니까?\n삭제된 게시글과 연결된 댓글/좋아요/신고 데이터가 함께 정리될 수 있습니다.\n이 작업은 되돌릴 수 없습니다.`,
    );
    if (!ok) return;

    try {
      await adminMutator("/api/admin/community/posts/bulk", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: selectedPostIds }),
      });
      showSuccessToast("선택한 게시글을 삭제했습니다.");
      setSelectedPostIds([]);
      mutatePosts();
    } catch (e: any) {
      showErrorToast(e?.message ?? "선택 삭제에 실패했습니다.");
    }
  };

  const shouldShowPostsEmptyState =
    hasResolvedPostsData && !hasPostsDataError && !!postsRaw && postsRaw.length === 0;
  const isPostsActualEmptyState = shouldShowPostsEmptyState && !hasPostFilterApplied;
  const isPostsSearchEmptyState = shouldShowPostsEmptyState && hasPostFilterApplied;

  const shouldShowReportsEmptyState =
    hasResolvedReportsData && !hasReportsDataError && !!reports && reports.length === 0;

  const switchTab = (next: "posts" | "reports") => {
    const qs = new URLSearchParams(sp.toString());
    if (next === "reports") qs.set("tab", "reports");
    else qs.delete("tab");
    router.replace(`/admin/boards?${qs.toString()}`);
  };

  const togglePostVisibility = async (p: PostItem) => {
    try {
      const next = p.status === "public" ? "hidden" : "public";
      await adminMutator(`/api/admin/community/posts/${p.id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: next }),
      });
      showSuccessToast(
        next === "hidden" ? "게시글을 숨김 처리했습니다." : "게시글을 공개 처리했습니다.",
      );
      mutatePosts();
    } catch (e: any) {
      showErrorToast(e?.message ?? "상태 변경 실패");
    }
  };

  const processReport = async (
    r: ReportItem,
    action: "resolve" | "reject" | "resolve_hide_target",
  ) => {
    try {
      await adminMutator(`/api/admin/community/reports/${r.id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      showSuccessToast("신고 처리가 완료되었습니다.");
      mutateReports();
      // 대상 숨김까지 했다면 게시글 목록도 최신화하는 게 안전
      mutatePosts();
    } catch (e: any) {
      showErrorToast(e?.message ?? "신고 처리 실패");
    }
  };

  return (
    <TooltipProvider>
      <div className="space-y-6 p-6">
        <AdminPageHeader
          variant="compact"
          title="게시판 관리"
          description="커뮤니티 게시글과 신고 내역을 확인하고 공개 상태를 관리합니다."
          icon={MessageSquare}
          scope="범위: 게시글 + 신고"
          helperText="고정 공지와 게시글 상세 수정은 각 게시글 화면에서 처리합니다."
        />
        <div className="grid gap-5 grid-cols-4">
          <Card className={adminSurface.kpiCard}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary dark:bg-primary/20">
                  <FileText className="h-6 w-6" />
                </div>
                <div>
                  <p className={adminTypography.caption}>전체 게시글</p>
                  <p className={adminTypography.kpiValueCompact}>
                    {postsTotal === null ? "-" : postsTotal.toLocaleString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className={adminSurface.kpiCard}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary dark:bg-primary/20">
                  <Eye className="h-6 w-6" />
                </div>
                <div>
                  <p className={adminTypography.caption}>공개 게시글</p>
                  <p className={adminTypography.kpiValueCompact}>
                    {postsPublicCount === null ? "-" : postsPublicCount.toLocaleString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className={adminSurface.kpiCard}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10 text-destructive dark:bg-destructive/15">
                  <AlertTriangle className="h-6 w-6" />
                </div>
                <div>
                  <p className={adminTypography.caption}>대기 중 신고</p>
                  <p className={adminTypography.kpiValueCompact}>
                    {reportsPendingCount === null ? "-" : reportsPendingCount.toLocaleString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className={adminSurface.kpiCard}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                  <EyeOff className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className={adminTypography.caption}>숨김 게시글</p>
                  <p className={adminTypography.kpiValueCompact}>
                    {postsHiddenCount === null ? "-" : postsHiddenCount.toLocaleString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className={cn(adminSurface.card, "overflow-hidden")}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-6">
            <div>
              <CardTitle className={adminTypography.sectionTitle}>게시글·신고 목록</CardTitle>
              <p className={cn("mt-1", adminTypography.metaMuted)}>커뮤니티 게시글 및 신고 관리</p>
            </div>

            <Tabs value={tab} onValueChange={(v) => switchTab(v as any)}>
              <TabsList className="bg-muted/50">
                <TabsTrigger value="posts" className="gap-2">
                  <FileText className="h-4 w-4" />
                  게시글
                </TabsTrigger>
                <TabsTrigger value="reports" className="gap-2">
                  <ShieldAlert className="h-4 w-4" />
                  신고
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </CardHeader>

          <div className="px-6 pb-2">
            <AdminFilterBar
              actions={
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() =>
                    tab === "posts"
                      ? (setPostPage(1), mutatePosts())
                      : (setReportPage(1), mutateReports())
                  }
                  aria-label={tab === "posts" ? "게시글 목록 새로고침" : "신고 목록 새로고침"}
                >
                  <RefreshCcw className="h-4 w-4" />
                </Button>
              }
              activeFilters={
                tab === "posts" ? (
                  <>
                    {postType !== "all" ? (
                      <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                        게시판 유형: {resolveBoardLabel(postType)}
                      </span>
                    ) : null}
                    {postStatus !== "all" ? (
                      <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                        공개 상태: {postStatus === "public" ? "공개" : "숨김"}
                      </span>
                    ) : null}
                    {postQ.trim() ? (
                      <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                        검색어: {postQ.trim()}
                      </span>
                    ) : null}
                    <span>
                      전체 게시글 {postsTotal === null ? "-" : postsTotal.toLocaleString()}건
                    </span>
                  </>
                ) : (
                  <>
                    {reportType !== "all" ? (
                      <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                        게시판 유형: {resolveBoardLabel(reportType)}
                      </span>
                    ) : null}
                    <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                      처리 상태:{" "}
                      {reportStatus === "pending"
                        ? "대기"
                        : reportStatus === "resolved"
                          ? "완료"
                          : reportStatus === "rejected"
                            ? "반려"
                            : "전체"}
                    </span>
                    {reportQ.trim() ? (
                      <span className="rounded-full border border-border/70 bg-muted/40 px-2.5 py-1">
                        검색어: {reportQ.trim()}
                      </span>
                    ) : null}
                    <span>
                      전체 신고 {reportsTotal === null ? "-" : reportsTotal.toLocaleString()}건
                    </span>
                  </>
                )
              }
            >
              {tab === "posts" ? (
                <div className="grid grid-cols-1 gap-2 xl:grid-cols-[minmax(140px,1fr)_minmax(140px,1fr)_minmax(260px,2fr)]">
                  <div className="min-w-0">
                    <Select
                      value={postType}
                      onValueChange={(v) => (setPostPage(1), setPostType(v))}
                    >
                      <SelectTrigger className="w-full min-w-0 bg-background/50">
                        <SelectValue placeholder="게시판" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">전체</SelectItem>
                        {Object.keys(boardLabel).map((k) => (
                          <SelectItem key={k} value={k}>
                            {boardLabel[k]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="min-w-0">
                    <Select
                      value={postStatus}
                      onValueChange={(v) => (setPostPage(1), setPostStatus(v))}
                    >
                      <SelectTrigger className="w-full min-w-0 bg-background/50">
                        <SelectValue placeholder="상태" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">전체</SelectItem>
                        <SelectItem value="public">공개</SelectItem>
                        <SelectItem value="hidden">숨김</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="min-w-0">
                    <Input
                      value={postQ}
                      onChange={(e) => setPostQ(e.target.value)}
                      placeholder="제목/작성자/내용 검색"
                      className="w-full min-w-0 bg-background/50"
                    />
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-2 xl:grid-cols-[minmax(140px,1fr)_minmax(140px,1fr)_minmax(260px,2fr)]">
                  <div className="min-w-0">
                    <Select
                      value={reportType}
                      onValueChange={(v) => (setReportPage(1), setReportType(v))}
                    >
                      <SelectTrigger className="w-full min-w-0 bg-background/50">
                        <SelectValue placeholder="게시판" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">전체</SelectItem>
                        {Object.keys(boardLabel).map((k) => (
                          <SelectItem key={k} value={k}>
                            {boardLabel[k]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="min-w-0">
                    <Select
                      value={reportStatus}
                      onValueChange={(v) => (setReportPage(1), setReportStatus(v))}
                    >
                      <SelectTrigger className="w-full min-w-0 bg-background/50">
                        <SelectValue placeholder="상태" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">대기</SelectItem>
                        <SelectItem value="resolved">완료</SelectItem>
                        <SelectItem value="rejected">반려</SelectItem>
                        <SelectItem value="all">전체</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="min-w-0">
                    <Input
                      value={reportQ}
                      onChange={(e) => setReportQ(e.target.value)}
                      placeholder="사유/신고자 검색"
                      className="w-full min-w-0 bg-background/50"
                    />
                  </div>
                </div>
              )}
            </AdminFilterBar>
          </div>

          <CardContent>
            {tab === "posts" && (
              <div className="space-y-4">
                <div
                  className={cn(
                    adminSurface.cardMuted,
                    "flex flex-wrap items-center justify-between gap-3 px-4 py-3",
                  )}
                >
                  <div className="min-w-[150px] space-y-1">
                    <p className={adminTypography.bodyStrong}>선택 {selectedPostIds.length}개</p>
                    <p className={adminTypography.caption}>선택 삭제는 복구할 수 없습니다.</p>
                  </div>
                  <Button
                    type="button"
                    variant={selectedPostIds.length > 0 ? "destructive" : "outline"}
                    size="sm"
                    disabled={selectedPostIds.length === 0}
                    onClick={deleteSelectedPosts}
                    className="min-h-[40px] gap-1 whitespace-nowrap"
                  >
                    <Trash2 className="h-4 w-4" /> 선택 삭제
                  </Button>
                </div>

                {postsLoading && (
                  <div className="space-y-3">
                    <Skeleton className="h-32 w-full" />
                    <Skeleton className="h-32 w-full" />
                    <Skeleton className="h-32 w-full" />
                  </div>
                )}

                {hasPostsDataError && (
                  <div
                    className={cn(
                      "rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-destructive dark:bg-destructive/15",
                      adminTypography.body,
                    )}
                  >
                    게시글 목록 로드 실패: {(postsErr as any)?.message ?? "error"}
                  </div>
                )}

                {!postsLoading && !hasPostsDataError && (
                  <>
                    {posts.length > 0 && (
                      <div className="flex items-center gap-2 px-2">
                        <Checkbox
                          checked={isCurrentPageAllSelected}
                          onCheckedChange={(checked) =>
                            toggleSelectAllCurrentPage(Boolean(checked))
                          }
                          aria-label="현재 페이지 게시글 전체 선택"
                        />
                        <span className={adminTypography.metaMuted}>현재 페이지 전체 선택</span>
                      </div>
                    )}
                    <div className="space-y-3">
                      {(posts ?? []).map((p) => (
                        <Card key={p.id} className={cn("group", adminSurface.tableCard)}>
                          <CardContent className="p-5">
                            {/**
                             * 게시글 카드 링크 생성 규칙
                             * 1) 공개 라우트 생성 시 외부 게시판 URL 사용
                             * 2) 실패 시 관리자 내부 상세(/admin/boards/[id])로 fallback
                             * 3) fallback도 없으면 링크 비활성화 + 사유 툴팁
                             */}
                            {(() => {
                              const publicLink = buildBoardPublicUrl({
                                type: p.type,
                                id: p.id,
                                postNo: p.postNo,
                                status: p.status,
                              });
                              const fallbackLink = buildAdminBoardDetailUrl({
                                id: p.id,
                              });
                              const href = publicLink.ok ? publicLink.url : fallbackLink;
                              const linkBlockedReason = publicLink.ok ? null : publicLink.reason;
                              const tooltipMessage = linkBlockedReason
                                ? getBoardLinkBlockedReason(
                                    linkBlockedReason,
                                    Boolean(fallbackLink),
                                  )
                                : null;

                              return (
                                <div className="flex items-start justify-between gap-4">
                                  <Checkbox
                                    checked={selectedPostIds.includes(p.id)}
                                    onCheckedChange={() => togglePostSelect(p.id)}
                                    className="mt-1"
                                    aria-label={`${p.title} 게시글 선택`}
                                  />
                                  <div className="flex-1 space-y-2">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <span className={adminDataTable.categoryText}>
                                        {resolveBoardLabel(p.type)}
                                      </span>
                                      <span className={adminTypography.caption}>
                                        #{p.postNo ?? "-"}
                                      </span>
                                      {p.status === "public" ? (
                                        <Badge variant={adminPostVisibilityBadgeVariant("public")}>
                                          공개
                                        </Badge>
                                      ) : (
                                        <Badge variant={adminPostVisibilityBadgeVariant("hidden")}>
                                          숨김
                                        </Badge>
                                      )}
                                    </div>

                                    {href ? (
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <Link
                                            href={href}
                                            className="block group/link"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                          >
                                            <h3
                                              className={cn(
                                                "inline-flex items-center gap-2 transition-colors group-hover/link:text-primary",
                                                adminTypography.bodyStrong,
                                              )}
                                            >
                                              {p.title}
                                              <ExternalLink className="h-4 w-4 opacity-0 group-hover/link:opacity-100 transition-opacity" />
                                            </h3>
                                          </Link>
                                        </TooltipTrigger>
                                        {tooltipMessage && (
                                          <TooltipContent>{tooltipMessage}</TooltipContent>
                                        )}
                                      </Tooltip>
                                    ) : (
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <span
                                            className={cn(
                                              "inline-flex cursor-not-allowed items-center gap-2 text-muted-foreground/80",
                                              adminTypography.bodyStrong,
                                            )}
                                            aria-disabled="true"
                                          >
                                            {p.title}
                                            <ExternalLink className="h-4 w-4 opacity-60" />
                                          </span>
                                        </TooltipTrigger>
                                        <TooltipContent>
                                          {getBoardLinkBlockedReason(linkBlockedReason, false)}
                                        </TooltipContent>
                                      </Tooltip>
                                    )}

                                    <div
                                      className={cn(
                                        "flex items-center gap-4",
                                        adminTypography.metaMuted,
                                      )}
                                    >
                                      <span className="font-medium">{p.nickname || "-"}</span>
                                      <span>{fmt(p.createdAt)}</span>
                                    </div>

                                    <div
                                      className={cn(
                                        "flex items-center gap-4",
                                        adminTypography.meta,
                                      )}
                                    >
                                      <div className="flex items-center gap-1.5">
                                        <BarChart3 className="h-4 w-4 text-primary" />
                                        <span className="font-medium">{p.views}</span>
                                      </div>
                                      <div className="flex items-center gap-1.5">
                                        <ThumbsUp className="h-4 w-4 text-primary" />
                                        <span className="font-medium">{p.likes}</span>
                                      </div>
                                      <div className="flex items-center gap-1.5">
                                        <MessageSquare className="h-4 w-4 text-foreground" />
                                        <span className="font-medium">{p.commentsCount}</span>
                                      </div>
                                    </div>
                                  </div>

                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => togglePostVisibility(p)}
                                    className="gap-2 shrink-0 whitespace-nowrap min-h-[40px]"
                                  >
                                    {p.status === "public" ? (
                                      <>
                                        <EyeOff className="h-4 w-4" />
                                        숨김
                                      </>
                                    ) : (
                                      <>
                                        <Eye className="h-4 w-4" />
                                        공개
                                      </>
                                    )}
                                  </Button>
                                </div>
                              );
                            })()}
                          </CardContent>
                        </Card>
                      ))}

                      {shouldShowPostsEmptyState && (
                        <Card className="border-dashed border-border/40">
                          <CardContent className="flex flex-col items-center justify-center py-16">
                            <FileText className="h-12 w-12 text-muted-foreground/50 mb-3" />
                            <p className={adminTypography.metaMuted}>
                              {isPostsActualEmptyState
                                ? "등록된 게시글이 없습니다."
                                : isPostsSearchEmptyState && hasPostFilterApplied
                                  ? "검색/필터 조건에 맞는 게시글이 없습니다."
                                  : "표시할 게시글이 없습니다."}
                            </p>
                          </CardContent>
                        </Card>
                      )}
                    </div>

                    {!!posts &&
                      posts.length > 0 &&
                      postsTotal !== null &&
                      postsTotalPages !== null && (
                        <div className="flex items-center justify-between gap-3 border-t border-border/40 pt-5 flex-row">
                          <div className={adminTypography.metaMuted}>
                            총 <span className="font-semibold text-foreground">{postsTotal}</span>건
                            · 페이지{" "}
                            <span className="font-semibold text-foreground">{postPage}</span> /{" "}
                            {postsTotalPages}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setPostPage((p) => Math.max(1, p - 1))}
                              disabled={postPage <= 1}
                              className="border-border/40 hover:border-border/60"
                            >
                              이전
                            </Button>
                            <div
                              className={cn(
                                "flex h-9 items-center rounded-md border border-border/40 bg-background/50 px-3",
                                adminTypography.bodyStrong,
                              )}
                            >
                              {postPage}
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setPostPage((p) => Math.min(postsTotalPages, p + 1))}
                              disabled={postPage >= postsTotalPages}
                              className="border-border/40 hover:border-border/60"
                            >
                              다음
                            </Button>
                          </div>
                        </div>
                      )}
                  </>
                )}
              </div>
            )}

            {tab === "reports" && (
              <div className="space-y-4">
                {reportsLoading && (
                  <div className="space-y-3">
                    <Skeleton className="h-40 w-full" />
                    <Skeleton className="h-40 w-full" />
                    <Skeleton className="h-40 w-full" />
                  </div>
                )}

                {hasReportsDataError && (
                  <div
                    className={cn(
                      "rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-destructive dark:bg-destructive/15",
                      adminTypography.body,
                    )}
                  >
                    신고 목록 로드 실패: {(reportsErr as any)?.message ?? "error"}
                  </div>
                )}

                {!reportsLoading && !hasReportsDataError && (
                  <>
                    <div className="space-y-3">
                      {(reports ?? []).map((r) => {
                        const isPending = r.status === "pending";
                        // 신고 대상 링크는 공개 URL 우선, 실패 시 관리자 상세 fallback 규칙을 동일 적용한다.
                        const publicLink = buildBoardPublicUrl({
                          type: r.boardType,
                          id: r.post?.id,
                          postNo: r.post?.postNo,
                          status: r.post?.status,
                        });
                        const fallbackLink = buildAdminBoardDetailUrl({
                          id: r.post?.id,
                        });
                        const postHref = publicLink.ok ? publicLink.url : fallbackLink;
                        const postLinkReason = publicLink.ok ? null : publicLink.reason;

                        return (
                          <Card
                            key={r.id}
                            className={cn(
                              "group",
                              adminSurface.tableCard,
                              isPending ? "border-warning/50 bg-warning/10 dark:bg-warning/15" : "",
                            )}
                          >
                            <CardContent className="p-5">
                              <div className="space-y-4">
                                <div className="flex items-start justify-between gap-4">
                                  <div className="flex-1 space-y-2">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <span className={adminDataTable.categoryText}>
                                        {r.targetType === "post" ? "게시글" : "댓글"} ·{" "}
                                        {resolveBoardLabel(r.boardType)}
                                      </span>
                                      {r.status === "pending" && (
                                        <Badge variant={adminReportStatusBadgeVariant("pending")}>
                                          대기
                                        </Badge>
                                      )}
                                      {r.status === "resolved" && (
                                        <Badge variant={adminReportStatusBadgeVariant("resolved")}>
                                          완료
                                        </Badge>
                                      )}
                                      {r.status === "rejected" && (
                                        <Badge variant={adminReportStatusBadgeVariant("rejected")}>
                                          반려
                                        </Badge>
                                      )}
                                    </div>

                                    <div>
                                      <p className={cn("mb-1", adminTypography.caption)}>
                                        신고 사유
                                      </p>
                                      <p className={adminTypography.bodyStrong}>{r.reason}</p>
                                    </div>

                                    <div>
                                      <p className={cn("mb-1", adminTypography.caption)}>
                                        신고 대상
                                      </p>
                                      {postHref ? (
                                        <Tooltip>
                                          <TooltipTrigger asChild>
                                            <Link
                                              href={postHref}
                                              target="_blank"
                                              rel="noopener noreferrer"
                                              className={cn(
                                                "inline-flex items-center gap-2 transition-colors hover:text-primary group/link",
                                                adminTypography.body,
                                              )}
                                            >
                                              {r.post?.title ?? "(제목 없음)"}
                                              <ExternalLink className="h-4 w-4 opacity-0 group-hover/link:opacity-100 transition-opacity" />
                                            </Link>
                                          </TooltipTrigger>
                                          {postLinkReason && (
                                            <TooltipContent>
                                              {getBoardLinkBlockedReason(
                                                postLinkReason,
                                                Boolean(fallbackLink),
                                              )}
                                            </TooltipContent>
                                          )}
                                        </Tooltip>
                                      ) : (
                                        <Tooltip>
                                          <TooltipTrigger asChild>
                                            <span
                                              className={cn(
                                                "inline-flex cursor-not-allowed items-center gap-2 text-muted-foreground",
                                                adminTypography.body,
                                              )}
                                              aria-disabled="true"
                                            >
                                              {r.post?.title ?? "(대상 글 정보 없음)"}
                                              <ExternalLink className="h-4 w-4 opacity-60" />
                                            </span>
                                          </TooltipTrigger>
                                          <TooltipContent>
                                            {getBoardLinkBlockedReason(postLinkReason, false)}
                                          </TooltipContent>
                                        </Tooltip>
                                      )}
                                    </div>

                                    <div
                                      className={cn(
                                        "flex items-center gap-4 pt-2",
                                        adminTypography.metaMuted,
                                      )}
                                    >
                                      <span>
                                        신고자:{" "}
                                        <span className="font-medium">
                                          {r.reporterDisplay || r.reporterNickname || "-"}
                                        </span>
                                      </span>
                                      <span>{fmt(r.createdAt)}</span>
                                    </div>
                                  </div>
                                </div>

                                <div
                                  className={cn(
                                    adminSurface.cardMuted,
                                    "flex gap-3 border-t border-border/60 p-3 flex-row items-center justify-between",
                                  )}
                                >
                                  <div className="space-y-1">
                                    <p className={adminTypography.bodyStrong}>신고 처리 액션</p>
                                    <p className={adminTypography.caption}>
                                      완료/반려는 신고 상태만 정리하고, 대상 숨김은 게시글 노출에
                                      영향을 줍니다.
                                    </p>
                                  </div>
                                  <div className="flex flex-wrap gap-2 justify-end">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      disabled={!isPending}
                                      onClick={() => processReport(r, "resolve")}
                                      className="gap-2"
                                    >
                                      <CheckCircle2 className="h-4 w-4" />
                                      완료
                                    </Button>

                                    <Button
                                      size="sm"
                                      variant="outline"
                                      disabled={!isPending}
                                      onClick={() => processReport(r, "reject")}
                                      className="gap-2"
                                    >
                                      <XCircle className="h-4 w-4" />
                                      반려
                                    </Button>

                                    <Button
                                      size="sm"
                                      variant="destructive"
                                      disabled={!isPending}
                                      onClick={() => processReport(r, "resolve_hide_target")}
                                      className="gap-2"
                                    >
                                      <ShieldAlert className="h-4 w-4" />
                                      대상 숨김 + 완료
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}

                      {shouldShowReportsEmptyState && (
                        <Card
                          className={cn(adminSurface.cardMuted, "border-dashed border-border/60")}
                        >
                          <CardContent className="flex flex-col items-center justify-center py-16">
                            <ShieldAlert className="mb-3 h-12 w-12 text-muted-foreground/50" />
                            <p className={adminTypography.metaMuted}>
                              현재 조건에 맞는 신고가 없습니다.
                            </p>
                          </CardContent>
                        </Card>
                      )}
                    </div>

                    {!!reports &&
                      reports.length > 0 &&
                      reportsTotal !== null &&
                      reportsTotalPages !== null && (
                        <div className="flex items-center justify-between gap-3 border-t border-border/40 pt-5 flex-row">
                          <div className={adminTypography.metaMuted}>
                            총 <span className="font-semibold text-foreground">{reportsTotal}</span>
                            건 · 페이지{" "}
                            <span className="font-semibold text-foreground">{reportPage}</span> /{" "}
                            {reportsTotalPages}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setReportPage((p) => Math.max(1, p - 1))}
                              disabled={reportPage <= 1}
                              className="border-border/40 hover:border-border/60"
                            >
                              이전
                            </Button>
                            <div
                              className={cn(
                                "flex h-9 items-center rounded-md border border-border/40 bg-background/50 px-3",
                                adminTypography.bodyStrong,
                              )}
                            >
                              {reportPage}
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                setReportPage((p) => Math.min(reportsTotalPages, p + 1))
                              }
                              disabled={reportPage >= reportsTotalPages}
                              className="border-border/40 hover:border-border/60"
                            >
                              다음
                            </Button>
                          </div>
                        </div>
                      )}
                  </>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </TooltipProvider>
  );
}
