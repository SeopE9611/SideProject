"use client";

import { AdminSemanticBadge as Badge } from "@/components/admin/AdminSemanticBadge";
import { Button } from "@/components/ui/button";
import AdminDetailSectionNav from "@/components/admin/AdminDetailSectionNav";
import { AdminSectionHeader } from "@/components/admin/AdminPageSection";
import { adminSurface, adminTypography } from "@/components/admin/admin-typography";
import { FormattedNumberInput } from "@/components/ui/formatted-number-input";
import { Input } from "@/components/ui/input";
import { adminFetcher, adminMutator, getAdminErrorMessage } from "@/lib/admin/adminFetcher";
import { authenticatedSWRFetcher } from "@/lib/fetchers/authenticatedSWRFetcher";
import type {
  OfflineCustomerDto,
  OfflineKind,
  OfflineLinkCandidate,
  OfflineLinkedUser,
  OfflinePackageSaleSummary,
  OfflinePaymentMethod,
  OfflinePaymentStatus,
  OfflineRecordPackageUsage,
  OfflineRecordPoints,
  OfflineServicePassSummary,
  OfflineStatus,
} from "@/types/admin/offline";
import {
  AlertCircle,
  ArrowLeft,
  Calendar,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  CreditCard,
  FileText,
  Gift,
  Hash,
  History,
  Info,
  Link2,
  Mail,
  Package,
  Phone,
  Search,
  ShoppingBag,
  Trash2,
  TrendingUp,
  Unlink,
  User,
  Wallet,
  X,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { ReactNode } from "react";
import { useState } from "react";
import useSWR from "swr";

type OfflineRecord = {
  id: string;
  kind: OfflineKind;
  status: OfflineStatus;
  occurredAt?: string | null;
  customerSnapshot?: {
    name?: string;
    phone?: string;
    email?: string | null;
  } | null;
  lines?: Array<{
    racketName?: string;

    // 기존 기록 호환용 대표 스트링명입니다.
    stringName?: string;

    // 신규 구조: 메인/크로스 스트링 분리 표시용입니다.
    mainStringName?: string;
    crossStringName?: string;

    tensionMain?: string;
    tensionCross?: string;

    // 라켓별 금액과 메모입니다.
    amount?: number | string | null;
    note?: string | null;
  }>;
  lineSummary?: string;
  payment?: {
    status?: OfflinePaymentStatus;
    method?: OfflinePaymentMethod;
    amount?: number | null;
  } | null;
  points?: OfflineRecordPoints | null;
  packageUsage?: OfflineRecordPackageUsage | null;
  memo?: string | null;
  createdAt?: string | null;
  updatedAt?: string | null;
};

type OfflineCustomerDetail = OfflineCustomerDto & {
  phoneNormalized?: string | null;
  linkedUser?: OfflineLinkedUser | null;
};

type DetailResponse = {
  item: OfflineCustomerDetail;
  records?: OfflineRecord[];
  passes?: OfflineServicePassSummary[];
  packageSales?: OfflinePackageSaleSummary[];
};

const KIND_LABELS = {
  stringing: "스트링 작업",
  package_sale: "패키지 판매",
  etc: "기타",
} as const;
const RECORD_STATUS_LABELS = {
  received: "접수",
  in_progress: "작업중",
  completed: "완료",
  picked_up: "수령완료",
  canceled: "취소",
} as const;
const PAYMENT_STATUS_LABELS = {
  pending: "미결제",
  paid: "결제완료",
  refunded: "환불",
} as const;
const PAYMENT_METHOD_LABELS = {
  cash: "현금",
  card: "카드",
  bank_transfer: "계좌이체",
  etc: "기타",
} as const;

/* ─────────────────────────────────────────────────────────────────────────────
   Utility Functions
───────────────────────────────────────────────────────────────────────────── */

function formatCurrency(value: number | null | undefined): string {
  return `${Number(value ?? 0).toLocaleString("ko-KR")}원`;
}

function formatPoints(value: number | null | undefined): string {
  return `${Number(value ?? 0).toLocaleString("ko-KR")}P`;
}

function formatDate(value?: string | Date | null): string {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return new Intl.DateTimeFormat("ko-KR", {
    year: "numeric",
    month: "numeric",
    day: "numeric",
  }).format(date);
}

function formatLineSummary(lines?: OfflineRecord["lines"]): string {
  if (!Array.isArray(lines) || lines.length === 0) return "작업 내용 미입력";

  const summary = lines
    .map((line, index) => {
      const main = String(line.tensionMain ?? "").trim();
      const cross = String(line.tensionCross ?? "").trim();
      const tension = main || cross ? `${main || "-"}/${cross || "-"}` : "";

      const mainString = String(line.mainStringName || line.stringName || "").trim();
      const crossString = String(line.crossStringName || "").trim();

      const stringSummary =
        mainString && crossString && mainString !== crossString
          ? `메인 ${mainString} / 크로스 ${crossString}`
          : mainString
            ? `스트링 ${mainString}`
            : "";

      return [
        lines.length > 1 ? `라켓 ${index + 1}` : "",
        String(line.racketName ?? "").trim(),
        stringSummary,
        tension,
      ]
        .filter(Boolean)
        .join(" · ");
    })
    .filter(Boolean)
    .join(", ");

  return summary || "작업 내용 미입력";
}

function hasLineDetail(line: NonNullable<OfflineRecord["lines"]>[number]): boolean {
  return (
    [
      line.racketName,
      line.stringName,
      line.mainStringName,
      line.crossStringName,
      line.tensionMain,
      line.tensionCross,
      line.note,
    ].some((value) => String(value ?? "").trim().length > 0) || Number(line.amount ?? 0) > 0
  );
}

function formatLineStringInfo(line: NonNullable<OfflineRecord["lines"]>[number]): string {
  const mainString = String(line.mainStringName || line.stringName || "").trim();
  const crossString = String(line.crossStringName || "").trim();

  if (mainString && crossString && mainString !== crossString) {
    return `메인 ${mainString} / 크로스 ${crossString}`;
  }

  if (mainString) return `스트링 ${mainString}`;
  if (crossString) return `크로스 ${crossString}`;

  return "-";
}

function formatLineTensionInfo(line: NonNullable<OfflineRecord["lines"]>[number]): string {
  const main = String(line.tensionMain ?? "").trim();
  const cross = String(line.tensionCross ?? "").trim();

  if (!main && !cross) return "-";
  return `${main || "-"} / ${cross || "-"}`;
}

/* ─────────────────────────────────────────────────────────────────────────────
   Reusable UI Components
───────────────────────────────────────────────────────────────────────────── */

function SectionCard({
  children,
  className = "",
  id,
}: {
  children: ReactNode;
  className?: string;
  id?: string;
}) {
  return (
    <div id={id} className={`${adminSurface.card} transition-shadow hover:shadow-md ${className}`}>
      {children}
    </div>
  );
}

function SectionHeader({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: React.ElementType;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-border/40 px-6 py-5">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <h3 className={adminTypography.sectionTitle}>{title}</h3>
          {description && <p className={`mt-0.5 ${adminTypography.metaMuted}`}>{description}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

function InfoItem({
  icon: Icon,
  label,
  value,
  className = "",
}: {
  icon?: React.ElementType;
  label: string;
  value: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`group flex items-start gap-3 rounded-lg border border-border/40 bg-muted/30 p-4 transition-colors hover:bg-muted/50 ${className}`}
    >
      {Icon && (
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-background text-muted-foreground transition-colors group-hover:bg-primary/10 group-hover:text-primary">
          <Icon className="h-4 w-4" />
        </div>
      )}
      <div className="min-w-0 flex-1">
        <p className={`${adminTypography.caption} font-medium uppercase tracking-wider`}>{label}</p>
        <div className={`mt-1 ${adminTypography.bodyStrong}`}>{value || "-"}</div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  icon: Icon,
  variant = "default",
}: {
  label: string;
  value: ReactNode;
  icon?: React.ElementType;
  variant?: "default" | "highlight" | "warning";
}) {
  const variantStyles = {
    default: "border-border/40 bg-muted/30",
    highlight: "border-primary/30 bg-primary/5",
    warning: "border-destructive/30 bg-destructive/5",
  };
  return (
    <div
      className={`rounded-lg border p-4 transition-colors hover:bg-muted/50 ${variantStyles[variant]}`}
    >
      <div className="flex items-center justify-between gap-2">
        <p className={`${adminTypography.caption} font-medium uppercase tracking-wider`}>{label}</p>
        {Icon && <Icon className="h-4 w-4 text-muted-foreground" />}
      </div>
      <p className={`mt-1 whitespace-nowrap tabular-nums ${adminTypography.kpiValueCompact}`}>{value}</p>
    </div>
  );
}

function StatusBadge({ status, labels }: { status: string; labels: Record<string, string> }) {
  const statusStyles: Record<string, string> = {
    received: "bg-info/10 text-info border-info/20",
    in_progress: "bg-warning/10 text-warning border-warning/20",
    completed: "bg-success/10 text-success border-success/20",
    picked_up: "bg-primary/10 text-primary border-primary/20",
    canceled: "bg-muted text-muted-foreground border-border",
    pending: "bg-warning/10 text-warning border-warning/20",
    paid: "bg-success/10 text-success border-success/20",
    refunded: "bg-destructive/10 text-destructive border-destructive/20",
  };
  return (
    <span
      className={`inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full border px-2.5 py-1 text-xs font-medium ${statusStyles[status] || "bg-muted text-muted-foreground border-border"}`}
    >
      {labels[status] || status}
    </span>
  );
}

function Message({ type, children }: { type: "success" | "error" | "info"; children: ReactNode }) {
  const styles = {
    success: "bg-success/10 text-success border-success/20",
    error: "bg-destructive/10 text-destructive border-destructive/20",
    info: "bg-primary/10 text-primary border-primary/20",
  };
  const icons = {
    success: CheckCircle2,
    error: AlertCircle,
    info: Info,
  };
  const Icon = icons[type];
  return (
    <div
      className={`flex items-start gap-2 rounded-lg border p-3 ${adminTypography.body} ${styles[type]}`}
    >
      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
      <span>{children}</span>
    </div>
  );
}

function FormField({
  label,
  htmlFor,
  children,
  hint,
}: {
  label: string;
  htmlFor?: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <div className="space-y-2">
      <label htmlFor={htmlFor} className={adminTypography.bodyStrong}>
        {label}
      </label>
      {children}
      {hint && <p className={adminTypography.caption}>{hint}</p>}
    </div>
  );
}

function Select({
  id,
  value,
  onChange,
  options,
  disabled,
  className = "",
}: {
  id?: string;
  value: string;
  onChange: (value: string) => void;
  options: Array<{ value: string; label: string }>;
  disabled?: boolean;
  className?: string;
}) {
  return (
    <select
      id={id}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      className={`w-full rounded-lg border border-border/60 bg-background px-3 py-2.5 ${adminTypography.body} transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
    >
      {options.map((opt) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
  );
}

function CollapsibleSection({
  title,
  icon: Icon,
  defaultOpen = false,
  children,
  badge,
  id,
}: {
  title: string;
  icon: React.ElementType;
  defaultOpen?: boolean;
  children: ReactNode;
  badge?: ReactNode;
  id?: string;
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  return (
    <div id={id} className="rounded-lg border border-border/40 bg-muted/20">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex w-full items-center justify-between px-4 py-3 text-left transition-colors hover:bg-muted/40"
      >
        <div className="flex items-center gap-2">
          <Icon className="h-4 w-4 text-muted-foreground" />
          <span className={adminTypography.bodyStrong}>{title}</span>
          {badge}
        </div>
        {isOpen ? (
          <ChevronUp className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        )}
      </button>
      {isOpen && <div className="border-t border-border/40 p-4">{children}</div>}
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   Error Message Mappings
───────────────────────────────────────────────────────────────────────────── */

type LinkCandidatesResponse = { items: OfflineLinkCandidate[] };

type PackageConfigOption = {
  id: string;
  name: string;
  sessions: number;
  price: number;
  validityDays: number;
  isActive: boolean;
};

type PackageSettingsResponse = { packageConfigs?: PackageConfigOption[] };

type OfflinePackageSellFormState = {
  packageTypeId: string;
  packageName: string;
  sessions: string;
  validityDays: string;
  price: string;
  paymentMethod: OfflinePaymentMethod;
  memo: string;
};

const INITIAL_PACKAGE_SELL_FORM: OfflinePackageSellFormState = {
  packageTypeId: "",
  packageName: "",
  sessions: "",
  validityDays: "365",
  price: "0",
  paymentMethod: "cash",
  memo: "",
};

const LINK_ERROR_MESSAGES: Record<string, string> = {
  "customer not found": "오프라인 고객을 찾을 수 없습니다.",
  "user not found": "온라인 회원을 찾을 수 없습니다.",
  "customer already linked to another user": "이미 다른 온라인 회원과 연결된 오프라인 고객입니다.",
  "user already linked to another offline customer":
    "이미 다른 오프라인 고객과 연결된 온라인 회원입니다.",
  "invalid userId": "온라인 회원 ID가 올바르지 않습니다.",
  "invalid customer id": "오프라인 고객 ID가 올바르지 않습니다.",
};

function translateLinkError(error: unknown): string {
  const message = getAdminErrorMessage(error);
  return LINK_ERROR_MESSAGES[message] ?? message ?? "온라인 회원 연결에 실패했습니다.";
}

type PointFormState = {
  grantAmount: string;
  grantReason: string;
  grantRevertReason: string;
  useAmount: string;
  useReason: string;
  deductRevertReason: string;
  message?: string | null;
  messageType?: "success" | "error" | null;
};

type PackageFormState = {
  passId: string;
  revertReason?: string;
  message?: string | null;
  messageType?: "success" | "error" | null;
};

type PackageRefundFormState = {
  reason: string;
  message?: string | null;
  messageType?: "success" | "error" | null;
};

const PACKAGE_ERROR_MESSAGES: Record<string, string> = {
  "linked user required": "온라인 회원과 연결된 고객만 패키지를 사용할 수 있습니다.",
  "user not found": "연결된 온라인 회원 정보를 찾을 수 없어 패키지를 사용할 수 없습니다.",
  "pass not found": "선택한 패키지를 찾을 수 없습니다.",
  "pass does not belong to linked user": "선택한 패키지는 이 고객의 패키지가 아닙니다.",
  "pass is not usable": "선택한 패키지는 사용할 수 없습니다.",
  "no remaining pass count": "잔여 횟수가 부족합니다.",
  "package already used for this record": "이미 이 기록에 패키지가 사용 처리되었습니다.",
  "package usage not found": "패키지 사용 이력이 없습니다.",
  "package usage already reverted": "이미 취소된 패키지 사용입니다.",
  "consumption not found": "패키지 사용 이력을 찾을 수 없습니다.",
  "consumption already reverted": "이미 취소된 패키지 사용입니다.",
  "revert reason required": "패키지 사용 취소 사유를 입력해주세요.",
  "package usage revert failed": "패키지 사용 취소에 실패했습니다.",
  "package consumption failed": "패키지 사용 처리에 실패했습니다.",
  "package consumed but offline record update failed":
    "패키지는 차감됐지만 기록 연결에 실패했습니다. 관리자에게 보정이 필요합니다.",
};

function translatePackageError(error: unknown): string {
  const message = getAdminErrorMessage(error);
  return PACKAGE_ERROR_MESSAGES[message] ?? message ?? "패키지 사용 처리에 실패했습니다.";
}

const PACKAGE_SELL_ERROR_MESSAGES: Record<string, string> = {
  "customer not found": "오프라인 고객을 찾을 수 없습니다.",
  "linked user required": "온라인 회원과 연결된 고객만 패키지를 판매/발급할 수 있습니다.",
  "user not found": "연결된 온라인 회원 정보를 찾을 수 없어 패키지를 판매/발급할 수 없습니다.",
  "invalid package name": "패키지명을 입력해주세요.",
  "invalid sessions": "이용 횟수는 1 이상이어야 합니다.",
  "invalid price": "판매 금액은 0원 이상이어야 합니다.",
  "invalid payment method": "결제수단을 확인해주세요.",
  "invalid validity days": "유효기간 일수는 1 이상이어야 합니다.",
  "package option not found": "선택한 패키지 옵션을 찾을 수 없습니다.",
  "invalid package option": "선택한 패키지 옵션을 사용할 수 없습니다.",
  "package order creation failed": "패키지 주문 생성에 실패했습니다.",
  "package order created but pass issuance failed":
    "패키지 주문은 생성됐지만 이용권 발급에 실패했습니다. 관리자 보정이 필요합니다.",
  "package pass issuance failed": "패키지 판매/발급에 실패했습니다.",
};

function translatePackageSellError(error: unknown): string {
  const message = getAdminErrorMessage(error);
  return PACKAGE_SELL_ERROR_MESSAGES[message] ?? message ?? "패키지 판매/발급에 실패했습니다.";
}

const PACKAGE_REFUND_ERROR_MESSAGES: Record<string, string> = {
  "package order not found": "패키지 주문을 찾을 수 없습니다.",
  "offline package order required": "오프라인 판매 패키지만 환불 처리할 수 있습니다.",
  "package order already refunded": "이미 환불 처리된 패키지입니다.",
  "service pass not found": "연결된 이용권을 찾을 수 없습니다.",
  "package already used": "이미 사용 이력이 있어 자동 환불할 수 없습니다.",
  "refund amount must equal paid amount": "이번 단계에서는 전액 환불만 처리할 수 있습니다.",
  "refund failed": "오프라인 패키지 환불 처리에 실패했습니다.",
};

function translatePackageRefundError(error: unknown): string {
  const message = getAdminErrorMessage(error);
  return (
    PACKAGE_REFUND_ERROR_MESSAGES[message] ?? message ?? "오프라인 패키지 환불 처리에 실패했습니다."
  );
}

function getPassLabel(pass?: OfflineServicePassSummary | null) {
  if (!pass) return "선택한 패키지";
  return pass.packageName || pass.name || "교체 서비스 패키지";
}

function isUsablePass(pass: OfflineServicePassSummary) {
  const expiresAt = pass.expiresAt ? new Date(pass.expiresAt) : null;
  const isExpired = expiresAt ? expiresAt.getTime() <= Date.now() : true;
  return pass.status === "active" && Number(pass.remainingCount ?? 0) > 0 && !isExpired;
}

const POINT_ERROR_MESSAGES: Record<string, string> = {
  "linked user required": "온라인 회원과 연결된 고객만 포인트를 처리할 수 있습니다.",
  "invalid amount": "포인트 금액은 1 이상이어야 합니다.",
  "insufficient points": "보유 포인트가 부족합니다.",
  "points already granted for this record": "이미 이 기록에 포인트 적립이 처리되었습니다.",
  "points already deducted for this record": "이미 이 기록에 포인트 사용이 처리되었습니다.",
  "points grant not found": "포인트 적립 이력이 없습니다.",
  "points deduction not found": "포인트 사용 이력이 없습니다.",
  "points grant already reverted": "이미 취소된 포인트 적립입니다.",
  "points deduction already reverted": "이미 취소된 포인트 사용입니다.",
  "revert reason required": "포인트 취소 사유를 입력해주세요.",
  "insufficient points to revert grant": "보유 포인트가 부족해 적립 취소를 할 수 없습니다.",
  "points revert failed": "포인트 취소에 실패했습니다.",
  "points transaction failed": "포인트 처리에 실패했습니다.",
};

function translatePointError(error: unknown): string {
  const message = getAdminErrorMessage(error);
  return POINT_ERROR_MESSAGES[message] ?? message ?? "포인트 처리에 실패했습니다.";
}

/* ─────────────────────────────────────────────────────────────────────────────
   Main Component
───────────────────────────────────────────────────────────────────────────── */

export default function OfflineCustomerDetailClient({ id }: { id: string }) {
  const router = useRouter();
  const {
    data,
    error,
    isLoading,
    mutate: mutateDetail,
  } = useSWR<DetailResponse>(`/api/admin/offline/customers/${id}`, authenticatedSWRFetcher, {
    revalidateOnFocus: false,
  });
  const [candidateQuery, setCandidateQuery] = useState({
    name: "",
    phone: "",
    email: "",
  });
  const [submittedCandidateQuery, setSubmittedCandidateQuery] = useState<{
    name: string;
    phone: string;
    email: string;
  } | null>(null);
  const [candidateMessage, setCandidateMessage] = useState<string | null>(null);
  const [linkMessage, setLinkMessage] = useState<string | null>(null);
  const [linkMessageType, setLinkMessageType] = useState<"success" | "error" | null>(null);
  const [linkingUserId, setLinkingUserId] = useState<string | null>(null);
  const [isUnlinking, setIsUnlinking] = useState(false);
  const [pointForms, setPointForms] = useState<Record<string, PointFormState>>({});
  const [processingPointKey, setProcessingPointKey] = useState<string | null>(null);
  const [packageForms, setPackageForms] = useState<Record<string, PackageFormState>>({});
  const [processingPackageRecordId, setProcessingPackageRecordId] = useState<string | null>(null);
  const [packageSellForm, setPackageSellForm] =
    useState<OfflinePackageSellFormState>(INITIAL_PACKAGE_SELL_FORM);
  const [isSellingPackage, setIsSellingPackage] = useState(false);
  const [packageSellMessage, setPackageSellMessage] = useState<string | null>(null);
  const [packageSellMessageType, setPackageSellMessageType] = useState<"success" | "error" | null>(
    null,
  );
  const [packageRefundForms, setPackageRefundForms] = useState<
    Record<string, PackageRefundFormState>
  >({});
  const [refundingPackageOrderId, setRefundingPackageOrderId] = useState<string | null>(null);

  const [expandedRecords, setExpandedRecords] = useState<Set<string>>(new Set());
  const [isDeletingCustomer, setIsDeletingCustomer] = useState(false);
  const [deleteMessage, setDeleteMessage] = useState<string | null>(null);

  const candidateKey = submittedCandidateQuery
    ? `/api/admin/offline/customers/${id}/link-candidates?name=${encodeURIComponent(submittedCandidateQuery.name)}&phone=${encodeURIComponent(submittedCandidateQuery.phone)}&email=${encodeURIComponent(submittedCandidateQuery.email)}`
    : null;
  const {
    data: candidatesData,
    isLoading: candidatesLoading,
    mutate: mutateCandidates,
  } = useSWR<LinkCandidatesResponse>(candidateKey, adminFetcher, {
    revalidateOnFocus: false,
  });
  const { data: packageSettings } = useSWR<PackageSettingsResponse>(
    "/api/admin/packages/settings",
    adminFetcher,
    {
      revalidateOnFocus: false,
    },
  );

  const item = data?.item;
  const records = data?.records ?? [];
  const pendingCount = records.filter((record) => record.payment?.status === "pending").length;
  const refundedCount = records.filter((record) => record.payment?.status === "refunded").length;
  const candidates = candidatesData?.items ?? [];
  const pointBalance = item?.linkedUser?.pointsBalance ?? null;
  const passes = data?.passes ?? [];
  const packageSales = data?.packageSales ?? [];
  const packageOptions = (packageSettings?.packageConfigs ?? []).filter((pkg) => pkg.isActive);
  const canUseLinkedFeatures = !!item?.linkedUserId && !!item?.linkedUser;
  const usablePasses = passes.filter(isUsablePass);
  const isPackageOptionSelected = !!packageSellForm.packageTypeId;

  function toggleRecordExpand(recordId: string) {
    setExpandedRecords((prev) => {
      const next = new Set(prev);
      if (next.has(recordId)) {
        next.delete(recordId);
      } else {
        next.add(recordId);
      }
      return next;
    });
  }

  function updatePointForm(recordId: string, patch: Partial<PointFormState>) {
    setPointForms((prev) => {
      const current = prev[recordId] ?? {
        grantAmount: "",
        grantReason: "",
        grantRevertReason: "",
        useAmount: "",
        useReason: "",
        deductRevertReason: "",
      };
      return {
        ...prev,
        [recordId]: { ...current, ...patch },
      };
    });
  }

  async function handleRecordPoints(recordId: string, mode: "grant" | "deduct") {
    const form = pointForms[recordId];
    const amountText = mode === "grant" ? form?.grantAmount : form?.useAmount;
    const reasonText = mode === "grant" ? form?.grantReason : form?.useReason;
    const amount = Number(amountText);
    if (!Number.isFinite(amount) || !Number.isInteger(amount) || amount < 1) {
      updatePointForm(recordId, {
        message: "포인트 금액은 1 이상이어야 합니다.",
        messageType: "error",
      });
      return;
    }

    const actionLabel = mode === "grant" ? "적립" : "사용";
    if (
      !window.confirm(`이 기록에 ${formatPoints(amount)} ${actionLabel} 처리를 진행하시겠습니까?`)
    )
      return;

    setProcessingPointKey(`${recordId}:${mode}`);
    updatePointForm(recordId, { message: null, messageType: null });
    try {
      await adminMutator(`/api/admin/offline/records/${recordId}/points/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount,
          reason: reasonText?.trim() || undefined,
        }),
      });
      updatePointForm(recordId, {
        ...(mode === "grant"
          ? { grantAmount: "", grantReason: "" }
          : { useAmount: "", useReason: "" }),
        message: `포인트 ${actionLabel} 처리가 완료되었습니다.`,
        messageType: "success",
      });
      await mutateDetail();
    } catch (err) {
      updatePointForm(recordId, {
        message: translatePointError(err),
        messageType: "error",
      });
    } finally {
      setProcessingPointKey(null);
    }
  }

  async function handleRecordPointRevert(recordId: string, mode: "grant" | "deduct") {
    const form = pointForms[recordId];
    const reason =
      (mode === "grant" ? form?.grantRevertReason : form?.deductRevertReason)?.trim() || "";
    if (!reason) {
      updatePointForm(recordId, {
        message: "포인트 취소 사유를 입력해주세요.",
        messageType: "error",
      });
      return;
    }

    const confirmMessage =
      mode === "grant"
        ? "이 오프라인 작업의 포인트 적립을 취소하고 회원 포인트를 회수하시겠습니까?"
        : "이 오프라인 작업의 포인트 사용을 취소하고 회원 포인트를 복구하시겠습니까?";
    if (!window.confirm(confirmMessage)) return;

    setProcessingPointKey(`${recordId}:${mode}-revert`);
    updatePointForm(recordId, { message: null, messageType: null });
    try {
      await adminMutator(`/api/admin/offline/records/${recordId}/points/${mode}/revert`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason }),
      });
      updatePointForm(recordId, {
        ...(mode === "grant" ? { grantRevertReason: "" } : { deductRevertReason: "" }),
        message:
          mode === "grant"
            ? "포인트 적립 취소가 완료되었습니다."
            : "포인트 사용 취소가 완료되었습니다.",
        messageType: "success",
      });
      await mutateDetail();
    } catch (err) {
      updatePointForm(recordId, {
        message:
          translatePointError(err) ||
          (mode === "grant"
            ? "포인트 적립 취소에 실패했습니다."
            : "포인트 사용 취소에 실패했습니다."),
        messageType: "error",
      });
    } finally {
      setProcessingPointKey(null);
    }
  }

  function updatePackageForm(recordId: string, patch: Partial<PackageFormState>) {
    setPackageForms((prev) => ({
      ...prev,
      [recordId]: {
        ...(prev[recordId] ?? { passId: usablePasses[0]?.id ?? "" }),
        ...patch,
      },
    }));
  }

  async function handleRecordPackageUse(recordId: string) {
    if (!canUseLinkedFeatures) {
      updatePackageForm(recordId, {
        message: "온라인 회원과 연결된 고객만 패키지를 사용할 수 있습니다.",
        messageType: "error",
      });
      return;
    }
    const selectedPassId = packageForms[recordId]?.passId || usablePasses[0]?.id || "";
    const selectedPass = passes.find((pass) => pass.id === selectedPassId);
    if (!selectedPassId || !selectedPass) {
      updatePackageForm(recordId, {
        message: "사용 가능한 패키지가 없습니다.",
        messageType: "error",
      });
      return;
    }
    if (
      !window.confirm(
        `${getPassLabel(selectedPass)} 1회를 이 오프라인 작업에 사용 처리하시겠습니까?`,
      )
    )
      return;

    setProcessingPackageRecordId(recordId);
    updatePackageForm(recordId, {
      passId: selectedPassId,
      message: null,
      messageType: null,
    });
    try {
      await adminMutator(`/api/admin/offline/records/${recordId}/package/use`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ passId: selectedPassId, usedCount: 1 }),
      });
      updatePackageForm(recordId, {
        passId: selectedPassId,
        message: "패키지 1회 사용 처리가 완료되었습니다.",
        messageType: "success",
      });
      await mutateDetail();
    } catch (err) {
      updatePackageForm(recordId, {
        passId: selectedPassId,
        message: translatePackageError(err),
        messageType: "error",
      });
    } finally {
      setProcessingPackageRecordId(null);
    }
  }

  async function handleRecordPackageRevert(recordId: string) {
    const reason = (packageForms[recordId]?.revertReason ?? "").trim();
    if (!reason) {
      updatePackageForm(recordId, {
        message: "패키지 사용 취소 사유를 입력해주세요.",
        messageType: "error",
      });
      return;
    }
    if (
      !window.confirm(
        "이 오프라인 작업에 적용된 패키지 사용 1회를 취소하고 잔여 횟수를 복구하시겠습니까?",
      )
    )
      return;

    setProcessingPackageRecordId(recordId);
    updatePackageForm(recordId, { message: null, messageType: null });
    try {
      await adminMutator(`/api/admin/offline/records/${recordId}/package/revert`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason }),
      });
      updatePackageForm(recordId, {
        revertReason: "",
        message: "패키지 사용 취소가 완료되었습니다.",
        messageType: "success",
      });
      await mutateDetail();
    } catch (err) {
      updatePackageForm(recordId, {
        message: translatePackageError(err) || "패키지 사용 취소에 실패했습니다.",
        messageType: "error",
      });
    } finally {
      setProcessingPackageRecordId(null);
    }
  }

  function updatePackageSellForm(patch: Partial<OfflinePackageSellFormState>) {
    setPackageSellForm((prev) => ({ ...prev, ...patch }));
  }

  function handlePackageOptionChange(packageTypeId: string) {
    const selected = packageOptions.find((pkg) => pkg.id === packageTypeId);
    if (!selected) {
      updatePackageSellForm({ packageTypeId });
      return;
    }
    updatePackageSellForm({
      packageTypeId: selected.id,
      packageName: selected.name,
      sessions: String(selected.sessions),
      validityDays: String(selected.validityDays),
      price: String(selected.price),
    });
  }

  async function handlePackageSell() {
    if (!canUseLinkedFeatures) {
      setPackageSellMessage("온라인 회원과 연결된 고객만 패키지를 판매/발급할 수 있습니다.");
      setPackageSellMessageType("error");
      return;
    }
    const packageName = packageSellForm.packageName.trim();
    const sessions = Number(packageSellForm.sessions);
    const validityDays = packageSellForm.validityDays.trim()
      ? Number(packageSellForm.validityDays)
      : undefined;
    const price = Number(packageSellForm.price);
    if (!packageName) {
      setPackageSellMessage("패키지명을 입력해주세요.");
      setPackageSellMessageType("error");
      return;
    }
    if (!Number.isInteger(sessions) || sessions < 1) {
      setPackageSellMessage("이용 횟수는 1 이상이어야 합니다.");
      setPackageSellMessageType("error");
      return;
    }
    if (!Number.isFinite(price) || price < 0) {
      setPackageSellMessage("판매 금액은 0원 이상이어야 합니다.");
      setPackageSellMessageType("error");
      return;
    }
    if (validityDays !== undefined && (!Number.isInteger(validityDays) || validityDays < 1)) {
      setPackageSellMessage("유효기간 일수는 1 이상이어야 합니다.");
      setPackageSellMessageType("error");
      return;
    }
    if (!window.confirm("이 고객에게 오프라인 결제 완료 패키지를 발급하시겠습니까?")) return;

    setIsSellingPackage(true);
    setPackageSellMessage(null);
    setPackageSellMessageType(null);
    try {
      await adminMutator(`/api/admin/offline/customers/${id}/packages/sell`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          packageTypeId: packageSellForm.packageTypeId || undefined,
          packageName,
          sessions,
          validityDays,
          price,
          paymentMethod: packageSellForm.paymentMethod,
          paymentStatus: "paid",
          memo: packageSellForm.memo.trim() || undefined,
        }),
      });
      setPackageSellMessage("패키지 판매 및 발급이 완료되었습니다.");
      setPackageSellMessageType("success");
      setPackageSellForm(INITIAL_PACKAGE_SELL_FORM);
      await mutateDetail();
    } catch (err) {
      setPackageSellMessage(translatePackageSellError(err));
      setPackageSellMessageType("error");
    } finally {
      setIsSellingPackage(false);
    }
  }

  function updatePackageRefundForm(packageOrderId: string, patch: Partial<PackageRefundFormState>) {
    setPackageRefundForms((prev) => ({
      ...prev,
      [packageOrderId]: {
        ...(prev[packageOrderId] ?? { reason: "" }),
        ...patch,
      },
    }));
  }

  async function handlePackageRefund(sale: OfflinePackageSaleSummary) {
    const reason = (packageRefundForms[sale.id]?.reason ?? "").trim();
    if (!reason) {
      updatePackageRefundForm(sale.id, {
        message: "환불 사유를 입력해주세요.",
        messageType: "error",
      });
      return;
    }
    if (
      !window.confirm(
        "이 오프라인 패키지 판매건을 환불 처리하시겠습니까? 실제 환불은 매장에서 별도로 처리해야 합니다.",
      )
    )
      return;

    setRefundingPackageOrderId(sale.id);
    updatePackageRefundForm(sale.id, { message: null, messageType: null });
    try {
      await adminMutator(`/api/admin/offline/package-orders/${sale.id}/refund`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason }),
      });
      updatePackageRefundForm(sale.id, {
        reason: "",
        message: "오프라인 패키지 환불 처리가 완료되었습니다.",
        messageType: "success",
      });
      await mutateDetail();
    } catch (err) {
      updatePackageRefundForm(sale.id, {
        message: translatePackageRefundError(err),
        messageType: "error",
      });
    } finally {
      setRefundingPackageOrderId(null);
    }
  }

  async function handleLinkUser(userId: string) {
    if (!window.confirm("이 온라인 회원을 현재 오프라인 고객과 연결하시겠습니까?")) return;
    setLinkingUserId(userId);
    setLinkMessage(null);
    setLinkMessageType(null);
    try {
      await adminMutator(`/api/admin/offline/customers/${id}/link`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      setLinkMessage("온라인 회원과 연결했습니다.");
      setLinkMessageType("success");
      await mutateDetail();
      await mutateCandidates();
    } catch (err) {
      setLinkMessage(translateLinkError(err));
      setLinkMessageType("error");
    } finally {
      setLinkingUserId(null);
    }
  }

  async function handleUnlinkUser() {
    if (
      !window.confirm(
        "온라인 회원 연결을 해제하시겠습니까? 기존 오프라인 기록은 삭제되지 않습니다.",
      )
    )
      return;
    setIsUnlinking(true);
    setLinkMessage(null);
    setLinkMessageType(null);
    try {
      await adminMutator(`/api/admin/offline/customers/${id}/link`, {
        method: "DELETE",
      });
      setLinkMessage("온라인 회원 연결을 해제했습니다.");
      setLinkMessageType("success");
      setSubmittedCandidateQuery(null);
      await mutateDetail();
    } catch (err) {
      setLinkMessage(translateLinkError(err));
      setLinkMessageType("error");
    } finally {
      setIsUnlinking(false);
    }
  }

  async function deleteOfflineCustomer() {
    if (isDeletingCustomer) return;

    const recordCount = records.length;

    const ok = window.confirm(
      recordCount > 0
        ? `이 고객의 오프라인 작업/매출 기록 ${recordCount}건이 남아 있습니다.\n\n기록이 남아 있는 고객은 삭제할 수 없습니다. 먼저 작업 기록을 삭제해주세요.`
        : `오프라인 고객 "${item?.name || "이름 없음"}" 정보를 삭제하시겠습니까?\n\n온라인 회원, 포인트, 패키지권, 주문 정보는 삭제되지 않습니다.\n이 작업은 되돌릴 수 없습니다.`,
    );

    if (!ok) return;

    if (recordCount > 0) {
      setDeleteMessage(
        "작업/매출 기록이 남아 있어 고객을 삭제할 수 없습니다. 먼저 기록을 삭제해주세요.",
      );
      return;
    }

    try {
      setIsDeletingCustomer(true);
      setDeleteMessage(null);

      await adminMutator(`/api/admin/offline/customers/${id}`, {
        method: "DELETE",
      });

      router.replace("/admin/offline");
    } catch (error) {
      setDeleteMessage(getAdminErrorMessage(error) || "오프라인 고객 삭제에 실패했습니다.");
    } finally {
      setIsDeletingCustomer(false);
    }
  }

  /* ─────────────────────────────────────────────────────────────────────────────
     Loading & Error States
  ───────────────────────────────────────────────────────────────────────────── */

  if (isLoading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <div className="text-center">
          <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          <p className={`mt-4 ${adminTypography.metaMuted}`}>
            오프라인 고객 상세 정보를 불러오는 중입니다...
          </p>
        </div>
      </div>
    );
  }

  if (error || !item) {
    return (
      <SectionCard>
        <div className="p-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10">
            <AlertCircle className="h-8 w-8 text-destructive" />
          </div>
          <h2 className={adminTypography.sectionTitle}>오프라인 고객 상세를 불러오지 못했습니다</h2>
          <p className={`mt-2 ${adminTypography.metaMuted}`}>
            고객 ID가 잘못되었거나 고객이 삭제되었을 수 있습니다.
          </p>
          <Button asChild variant="outline" className="mt-6">
            <Link href="/admin/offline">
              <ArrowLeft className="mr-2 h-4 w-4" />
              오프라인 관리로 돌아가기
            </Link>
          </Button>
        </div>
      </SectionCard>
    );
  }

  /* ────────────────────────────────────────────────────────────────────────────
     Main Render
  ───────────────────────────────────────────────────────────────────────────── */

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <section className={`${adminSurface.card} p-6`}>
        <AdminSectionHeader
          title="오프라인 고객 상세"
          description="고객 기본 정보와 오프라인 작업/매출 이력을 확인합니다."
          icon={User}
          actions={
            <>
              <Button asChild variant="outline" size="sm">
                <Link href="/admin/offline">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  오프라인 관리
                </Link>
              </Button>

              <Button asChild variant="ghost" size="sm">
                <a href="#offline-records">
                  <History className="mr-2 h-4 w-4" />
                  최근 기록
                </a>
              </Button>

              <Button
                type="button"
                variant="destructive"
                size="sm"
                disabled={isDeletingCustomer}
                onClick={deleteOfflineCustomer}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                {isDeletingCustomer ? "삭제 중..." : "고객 삭제"}
              </Button>
            </>
          }
        />
      </section>

      {deleteMessage && (
        <div
          className={`rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 ${adminTypography.body} text-destructive`}
        >
          {deleteMessage}
        </div>
      )}

      {/* Customer Quick Info Banner */}
      <div className="rounded-xl border border-primary/20 bg-primary/5 p-5">
        <div className="flex gap-4 flex-row items-center justify-between">
          <div className="flex min-w-0 items-center gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-primary/20 text-primary">
              <User className="h-7 w-7" />
            </div>
            <div className="min-w-0">
              <h2
                className={`line-clamp-2 break-keep ${adminTypography.kpiValueCompact}`}
                title={item.name || "이름 없음"}
              >
                {item.name || "이름 없음"}
              </h2>
              <div
                className={`mt-1 flex flex-wrap items-center gap-3 ${adminTypography.metaMuted}`}
              >
                <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap tabular-nums">
                  <Phone className="h-3.5 w-3.5" />
                  {item.phoneMasked || item.phone || "-"}
                </span>
                {item.email && (
                  <span className="flex min-w-0 items-center gap-1.5">
                    <Mail className="h-3.5 w-3.5 shrink-0" />
                    <span className="block max-w-[240px] truncate" title={item.email}>
                      {item.email}
                    </span>
                  </span>
                )}
              </div>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {item.linkedUserId ? (
              <Badge className="shrink-0 whitespace-nowrap bg-success/10 text-success border-success/20">
                <Link2 className="mr-1.5 h-3.5 w-3.5" />
                온라인 연결됨
              </Badge>
            ) : (
              <Badge variant="outline" className="shrink-0 whitespace-nowrap text-muted-foreground">
                <Unlink className="mr-1.5 h-3.5 w-3.5" />
                온라인 미연결
              </Badge>
            )}
            {item.tags?.map((tag) => (
              <Badge key={tag} variant="secondary" className="shrink-0 whitespace-nowrap">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      </div>

      <AdminDetailSectionNav
        items={[
          { href: "#offline-customer-basic", label: "고객정보" },
          { href: "#offline-customer-stats", label: "정산/요약" },
          { href: "#offline-customer-points", label: "포인트" },
          { href: "#offline-customer-packages", label: "패키지권" },
          { href: "#offline-records", label: "이력" },
        ]}
      />

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
        {/* Left Column - Customer Info & Link */}
        <div className="space-y-6 xl:col-span-5">
          {/* Customer Basic Info */}
          <SectionCard id="offline-customer-basic">
            <SectionHeader
              icon={User}
              title="고객 기본 정보"
              description="휴대폰 번호와 연락처 정보"
            />
            <div className="space-y-4 p-6">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <InfoItem
                  icon={User}
                  label="고객명"
                  value={
                    <span
                      className="line-clamp-2 break-keep font-semibold"
                      title={item.name || "-"}
                    >
                      {item.name || "-"}
                    </span>
                  }
                />
                <InfoItem
                  icon={Phone}
                  label="휴대폰 번호"
                  value={
                    <div>
                      <span className="whitespace-nowrap tabular-nums">
                        {item.phoneMasked || "-"}
                      </span>
                      {item.phone && (
                        <p
                          className={`mt-1 whitespace-nowrap tabular-nums ${adminTypography.caption}`}
                        >
                          원번호: {item.phone}
                        </p>
                      )}
                    </div>
                  }
                />
                <InfoItem
                  icon={Mail}
                  label="이메일"
                  value={
                    <span className="block max-w-[220px] truncate" title={item.email || "-"}>
                      {item.email || "-"}
                    </span>
                  }
                />
                <InfoItem
                  icon={Calendar}
                  label="마지막 방문일"
                  value={formatDate(item.stats?.lastVisitedAt)}
                />
                <InfoItem icon={Clock} label="등록일" value={formatDate(item.createdAt)} />
                <InfoItem icon={Clock} label="수정일" value={formatDate(item.updatedAt)} />
              </div>

              {/* Memo */}
              <div className="rounded-lg border border-border/40 bg-muted/20 p-4">
                <div
                  className={`flex items-center gap-2 font-medium uppercase tracking-wider ${adminTypography.caption}`}
                >
                  <FileText className="h-3.5 w-3.5" />
                  메모
                </div>
                <p className={`mt-2 whitespace-pre-wrap break-keep ${adminTypography.body}`}>
                  {item.memo || "등록된 메모가 없습니다."}
                </p>
              </div>

              <p className={adminTypography.caption}>
                고객 정보 수정은 오프라인 관리 화면 또는 후속 단계에서 지원 예정입니다.
              </p>
            </div>
          </SectionCard>

          {/* Online Member Link */}
          <SectionCard>
            <SectionHeader
              icon={Link2}
              title="온라인 회원 연결"
              description="포인트/패키지 연동을 위한 회원 연결"
              action={
                item.linkedUserId ? (
                  <Badge className="shrink-0 whitespace-nowrap bg-success/10 text-success border-success/20">
                    연결됨
                  </Badge>
                ) : (
                  <Badge
                    variant="outline"
                    className="shrink-0 whitespace-nowrap text-muted-foreground"
                  >
                    미연결
                  </Badge>
                )
              }
            />
            <div className="space-y-4 p-6">
              {item.linkedUserId ? (
                <>
                  {/* Linked User Info */}
                  <div className="rounded-lg border border-success/20 bg-success/5 p-4">
                    <div className="flex items-start gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-success/20 text-success">
                        <User className="h-5 w-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={adminTypography.bodyStrong}>
                          {item.linkedUser?.name || "회원 정보 없음"}
                        </p>
                        <p className={adminTypography.metaMuted}>{item.linkedUser?.email || "-"}</p>
                        <p className={adminTypography.metaMuted}>
                          {item.linkedUser?.phoneMasked || item.linkedUser?.phone || "-"}
                        </p>
                        <p className={`mt-2 truncate ${adminTypography.caption}`}>
                          ID: {item.linkedUserId}
                        </p>
                      </div>
                    </div>
                  </div>
                  <p className={adminTypography.caption}>
                    이 연결은 향후 포인트/패키지 연동 기준으로 사용됩니다.
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleUnlinkUser}
                    disabled={isUnlinking}
                    className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Unlink className="mr-2 h-4 w-4" />
                    {isUnlinking ? "연결 해제 중..." : "연결 해제"}
                  </Button>
                </>
              ) : (
                <>
                  <p className={adminTypography.metaMuted}>
                    포인트/패키지 연동은 온라인 회원 연결 후 사용할 수 있습니다.
                  </p>

                  {/* Search Form */}
                  <form
                    className="rounded-lg border border-border/40 bg-muted/20 p-4"
                    onSubmit={(e) => {
                      e.preventDefault();
                      setCandidateMessage(null);
                      setLinkMessage(null);
                      if (
                        !candidateQuery.name.trim() &&
                        !candidateQuery.phone.trim() &&
                        !candidateQuery.email.trim()
                      ) {
                        setCandidateMessage("검색어를 하나 이상 입력해 주세요.");
                        setSubmittedCandidateQuery(null);
                        return;
                      }
                      setSubmittedCandidateQuery({ ...candidateQuery });
                    }}
                  >
                    <div className="space-y-3">
                      <FormField label="이름" htmlFor="link-candidate-name">
                        <Input
                          id="link-candidate-name"
                          value={candidateQuery.name}
                          onChange={(e) =>
                            setCandidateQuery({
                              ...candidateQuery,
                              name: e.target.value,
                            })
                          }
                          placeholder="회원 이름 입력"
                        />
                      </FormField>
                      <FormField label="휴대폰 번호" htmlFor="link-candidate-phone">
                        <Input
                          id="link-candidate-phone"
                          value={candidateQuery.phone}
                          onChange={(e) =>
                            setCandidateQuery({
                              ...candidateQuery,
                              phone: e.target.value,
                            })
                          }
                          placeholder="010-0000-0000"
                        />
                      </FormField>
                      <FormField label="이메일" htmlFor="link-candidate-email">
                        <Input
                          id="link-candidate-email"
                          type="email"
                          value={candidateQuery.email}
                          onChange={(e) =>
                            setCandidateQuery({
                              ...candidateQuery,
                              email: e.target.value,
                            })
                          }
                          placeholder="email@example.com"
                        />
                      </FormField>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <Button type="submit" size="sm">
                        <Search className="mr-2 h-4 w-4" />
                        검색
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setCandidateQuery({ name: "", phone: "", email: "" });
                          setSubmittedCandidateQuery(null);
                          setCandidateMessage(null);
                          setLinkMessage(null);
                        }}
                      >
                        초기화
                      </Button>
                    </div>
                  </form>

                  {/* Search Results */}
                  {candidateMessage && <Message type="error">{candidateMessage}</Message>}
                  {submittedCandidateQuery && candidatesLoading && (
                    <div className={`flex items-center gap-2 ${adminTypography.metaMuted}`}>
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                      회원 검색 중...
                    </div>
                  )}
                  {submittedCandidateQuery && !candidatesLoading && candidates.length === 0 && (
                    <p className={adminTypography.metaMuted}>검색 결과가 없습니다.</p>
                  )}
                  {submittedCandidateQuery && !candidatesLoading && candidates.length > 0 && (
                    <div className="space-y-2">
                      {candidates.map((candidate) => {
                        const isLinkedToCurrent =
                          candidate.alreadyLinkedOfflineCustomerId === item.id;
                        const isLinkedToOther =
                          !!candidate.alreadyLinkedOfflineCustomerId && !isLinkedToCurrent;
                        return (
                          <div
                            key={candidate.id}
                            className={`rounded-lg border p-4 transition-colors ${isLinkedToOther ? "border-destructive/30 bg-destructive/5" : isLinkedToCurrent ? "border-success/30 bg-success/5" : "border-border/40 hover:bg-muted/30"}`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="min-w-0 flex-1">
                                <p className={adminTypography.bodyStrong}>
                                  {candidate.name || "이름 없음"}
                                </p>
                                <p className={`truncate ${adminTypography.metaMuted}`}>
                                  {candidate.email || "이메일 없음"}
                                </p>
                                <p className={adminTypography.metaMuted}>
                                  {candidate.phoneMasked || "휴대폰 없음"}
                                </p>
                                <div className="mt-2 flex flex-wrap gap-1.5">
                                  {candidate.match.name && (
                                    <Badge variant="secondary" className={adminTypography.caption}>
                                      이름 일치
                                    </Badge>
                                  )}
                                  {candidate.match.phone && (
                                    <Badge variant="secondary" className={adminTypography.caption}>
                                      휴대폰 일치
                                    </Badge>
                                  )}
                                  {candidate.match.email && (
                                    <Badge variant="secondary" className={adminTypography.caption}>
                                      이메일 일치
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <Button
                                type="button"
                                size="sm"
                                onClick={() => handleLinkUser(candidate.id)}
                                disabled={
                                  isLinkedToOther ||
                                  isLinkedToCurrent ||
                                  linkingUserId === candidate.id
                                }
                              >
                                {isLinkedToCurrent ? (
                                  <>
                                    <Check className="mr-1.5 h-3.5 w-3.5" />
                                    연결됨
                                  </>
                                ) : linkingUserId === candidate.id ? (
                                  "연결 중..."
                                ) : (
                                  <>
                                    <Link2 className="mr-1.5 h-3.5 w-3.5" />
                                    연결
                                  </>
                                )}
                              </Button>
                            </div>
                            {isLinkedToOther && (
                              <p className={`mt-2 ${adminTypography.caption} text-destructive`}>
                                이미 다른 오프라인 고객과 연결된 회원입니다.
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </>
              )}
              {linkMessage && <Message type={linkMessageType || "info"}>{linkMessage}</Message>}
            </div>
          </SectionCard>
        </div>

        {/* Right Column - Points, Packages, Stats */}
        <div className="space-y-6 xl:col-span-7">
          {/* Statistics */}
          <SectionCard id="offline-customer-stats">
            <SectionHeader
              icon={TrendingUp}
              title="누적 통계"
              description="오프라인 고객 기준 누적 데이터"
            />
            <div className="p-6">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <StatCard
                  label="방문 횟수"
                  value={`${item.stats?.visitCount ?? 0}회`}
                  icon={Calendar}
                />
                <StatCard
                  label="총 작업 수"
                  value={`${item.stats?.totalServiceCount ?? 0}건`}
                  icon={Hash}
                />
                <StatCard
                  label="총 결제액"
                  value={formatCurrency(item.stats?.totalPaid)}
                  icon={CreditCard}
                  variant="highlight"
                />
                <StatCard
                  label="마지막 방문"
                  value={formatDate(item.stats?.lastVisitedAt)}
                  icon={Clock}
                />
                <StatCard
                  label="미결제 기록"
                  value={`${pendingCount}건`}
                  icon={AlertCircle}
                  variant={pendingCount > 0 ? "warning" : "default"}
                />
                <StatCard label="환불 기록" value={`${refundedCount}건`} icon={X} />
              </div>
            </div>
          </SectionCard>

          {/* Points */}
          <SectionCard id="offline-customer-points">
            <SectionHeader
              icon={Wallet}
              title="포인트"
              description="온라인 회원 연동 포인트 현황"
              action={
                canUseLinkedFeatures && pointBalance !== null ? (
                  <div className="rounded-lg bg-primary/10 px-4 py-2 text-right">
                    <p className={adminTypography.caption}>현재 잔액</p>
                    <p className={`${adminTypography.kpiValueCompact} text-primary`}>
                      {formatPoints(pointBalance)}
                    </p>
                  </div>
                ) : null
              }
            />
            <div className="p-6">
              {canUseLinkedFeatures ? (
                <div className="space-y-3">
                  <p className={adminTypography.metaMuted}>
                    오프라인 작업 기록에서 포인트 적립/사용을 처리할 수 있습니다.
                  </p>
                  <p className={adminTypography.caption}>
                    포인트 사용 시 실제 결제금액은 별도로 수정하세요. 취소된 포인트 처리는 같은
                    기록에서 다시 처리할 수 없습니다.
                  </p>
                </div>
              ) : (
                <div className="rounded-lg border border-border/40 bg-muted/20 p-4">
                  <p className={adminTypography.metaMuted}>
                    온라인 회원과 연결된 고객만 포인트 조회/사용/적립이 가능합니다.
                  </p>
                  {item.linkedUserId && !item.linkedUser && (
                    <p className={`mt-2 ${adminTypography.caption} text-destructive`}>
                      연결된 온라인 회원 정보를 찾을 수 없어 포인트를 처리할 수 없습니다.
                    </p>
                  )}
                </div>
              )}
            </div>
          </SectionCard>

          {/* Packages */}
          <SectionCard id="offline-customer-packages">
            <SectionHeader
              icon={Package}
              title="패키지/서비스권"
              description="보유 패키지 현황"
              action={
                canUseLinkedFeatures && usablePasses.length > 0 ? (
                  <Badge className="shrink-0 whitespace-nowrap bg-success/10 text-success border-success/20">
                    {usablePasses.length}개 사용 가능
                  </Badge>
                ) : null
              }
            />
            <div className="p-6">
              {!canUseLinkedFeatures ? (
                <div className="rounded-lg border border-border/40 bg-muted/20 p-4">
                  <p className={adminTypography.metaMuted}>
                    온라인 회원과 연결된 고객만 보유 패키지 조회 및 사용 처리가 가능합니다.
                  </p>
                </div>
              ) : passes.length === 0 ? (
                <p className={adminTypography.metaMuted}>보유 패키지/서비스권이 없습니다.</p>
              ) : (
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  {passes.map((pass) => {
                    const usable = isUsablePass(pass);
                    return (
                      <div
                        key={pass.id}
                        className={`rounded-lg border p-4 transition-colors ${usable ? "border-primary/30 bg-primary/5 hover:bg-primary/10" : "border-border/40 bg-muted/20 text-muted-foreground"}`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className={adminTypography.bodyStrong}>{getPassLabel(pass)}</p>
                          <Badge
                            variant={usable ? "secondary" : "outline"}
                            className={usable ? "bg-success/10 text-success" : ""}
                          >
                            {usable ? "사용 가능" : pass.status || "비활성"}
                          </Badge>
                        </div>
                        <div className={`mt-3 space-y-1 ${adminTypography.body}`}>
                          <p>
                            잔여{" "}
                            <span className="font-semibold text-foreground">
                              {Number(pass.remainingCount ?? 0).toLocaleString("ko-KR")}
                            </span>{" "}
                            / {Number(pass.totalCount ?? 0).toLocaleString("ko-KR")}회
                          </p>
                          <p>사용 {Number(pass.usedCount ?? 0).toLocaleString("ko-KR")}회</p>
                          <p>만료일 {formatDate(pass.expiresAt)}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </SectionCard>

          {/* Package Sell */}
          <SectionCard>
            <SectionHeader
              icon={ShoppingBag}
              title="오프라인 패키지 판매"
              description="매장에서 결제 완료된 패키지권을 온라인 회원 계정에 발급"
            />
            <div className="p-6">
              {!canUseLinkedFeatures ? (
                <div className="rounded-lg border border-border/40 bg-muted/20 p-4">
                  <p className={adminTypography.metaMuted}>
                    온라인 회원과 연결된 고객만 패키지 판매/발급이 가능합니다.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {packageOptions.length > 0 && (
                    <FormField
                      label="패키지 옵션"
                      htmlFor="offline-package-option"
                      hint="옵션 선택 시 패키지명, 횟수, 유효기간, 판매 금액을 자동 입력합니다."
                    >
                      <Select
                        id="offline-package-option"
                        value={packageSellForm.packageTypeId}
                        onChange={handlePackageOptionChange}
                        disabled={isSellingPackage}
                        options={[
                          { value: "", label: "수동 입력" },
                          ...packageOptions.map((pkg) => ({
                            value: pkg.id,
                            label: `${pkg.name} · ${Number(pkg.sessions).toLocaleString("ko-KR")}회 · ${formatCurrency(pkg.price)} · ${Number(pkg.validityDays).toLocaleString("ko-KR")}일`,
                          })),
                        ]}
                      />
                    </FormField>
                  )}

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                    <FormField label="패키지명" htmlFor="offline-package-name">
                      <Input
                        id="offline-package-name"
                        value={packageSellForm.packageName}
                        onChange={(e) => updatePackageSellForm({ packageName: e.target.value })}
                        disabled={isSellingPackage || isPackageOptionSelected}
                        placeholder="예: 10회권"
                      />
                    </FormField>
                    <FormField label="이용 횟수" htmlFor="offline-package-sessions">
                      <Input
                        id="offline-package-sessions"
                        type="number"
                        min={1}
                        step={1}
                        value={packageSellForm.sessions}
                        onChange={(e) => updatePackageSellForm({ sessions: e.target.value })}
                        disabled={isSellingPackage || isPackageOptionSelected}
                        placeholder="예: 10"
                      />
                    </FormField>
                    <FormField label="유효기간 일수" htmlFor="offline-package-validity">
                      <Input
                        id="offline-package-validity"
                        type="number"
                        min={1}
                        step={1}
                        value={packageSellForm.validityDays}
                        onChange={(e) =>
                          updatePackageSellForm({
                            validityDays: e.target.value,
                          })
                        }
                        disabled={isSellingPackage || isPackageOptionSelected}
                        placeholder="예: 365"
                      />
                    </FormField>
                    <FormField label="판매 금액" htmlFor="offline-package-price">
                      <FormattedNumberInput
                        id="offline-package-price"
                        min={0}
                        step={1000}
                        value={packageSellForm.price ? Number(packageSellForm.price) : null}
                        onValueChange={(price) =>
                          updatePackageSellForm({
                            price: String(price),
                          })
                        }
                        disabled={isSellingPackage || isPackageOptionSelected}
                        placeholder="예: 100,000"
                      />
                    </FormField>
                    <FormField label="결제수단" htmlFor="offline-package-payment-method">
                      <Select
                        id="offline-package-payment-method"
                        value={packageSellForm.paymentMethod}
                        onChange={(v) =>
                          updatePackageSellForm({
                            paymentMethod: v as OfflinePaymentMethod,
                          })
                        }
                        disabled={isSellingPackage}
                        options={[
                          { value: "cash", label: "현금" },
                          { value: "card", label: "카드" },
                          { value: "bank_transfer", label: "계좌이체" },
                          { value: "etc", label: "기타" },
                        ]}
                      />
                    </FormField>
                  </div>

                  <FormField label="메모" htmlFor="offline-package-memo">
                    <textarea
                      id="offline-package-memo"
                      className={`min-h-20 w-full rounded-lg border border-border/60 bg-background px-3 py-2.5 ${adminTypography.body} transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:cursor-not-allowed disabled:opacity-50`}
                      value={packageSellForm.memo}
                      onChange={(e) => updatePackageSellForm({ memo: e.target.value })}
                      disabled={isSellingPackage}
                      placeholder="오프라인 판매 메모(선택)"
                    />
                  </FormField>

                  <div className="flex min-w-0 flex-wrap items-center gap-3">
                    <Button type="button" onClick={handlePackageSell} disabled={isSellingPackage}>
                      <Gift className="mr-2 h-4 w-4" />
                      {isSellingPackage ? "패키지 판매/발급 중..." : "패키지 판매/발급"}
                    </Button>
                    <p className={adminTypography.caption}>
                      판매는 service_pass 발급만 처리하며, 특정 오프라인 기록에 자동 사용 처리하지
                      않습니다.
                    </p>
                  </div>
                </div>
              )}
              {packageSellMessage && (
                <Message type={packageSellMessageType || "info"}>{packageSellMessage}</Message>
              )}

              {/* Package Sales History */}
              <CollapsibleSection
                title="패키지 판매/주문 내역"
                icon={ShoppingBag}
                badge={
                  packageSales.length > 0 ? (
                    <Badge variant="secondary" className={adminTypography.caption}>
                      {packageSales.length}건
                    </Badge>
                  ) : null
                }
              >
                {packageSales.length === 0 ? (
                  <p className={adminTypography.metaMuted}>
                    표시할 패키지 판매/주문 내역이 없습니다.
                  </p>
                ) : (
                  <div className="overflow-x-auto rounded-lg border border-border/40">
                    <table className={`min-w-[980px] text-left ${adminTypography.body}`}>
                      <thead className={`bg-muted/50 ${adminTypography.caption}`}>
                        <tr>
                          <th className="whitespace-nowrap px-4 py-3 font-medium">패키지</th>
                          <th className="whitespace-nowrap px-4 py-3 text-right font-medium">
                            횟수
                          </th>
                          <th className="whitespace-nowrap px-4 py-3 text-right font-medium">
                            금액
                          </th>
                          <th className="whitespace-nowrap px-4 py-3 text-center font-medium">
                            결제수단
                          </th>
                          <th className="whitespace-nowrap px-4 py-3 text-center font-medium">
                            결제상태
                          </th>
                          <th className="whitespace-nowrap px-4 py-3 text-right font-medium">
                            결제일
                          </th>
                          <th className="whitespace-nowrap px-4 py-3 text-center font-medium">
                            출처
                          </th>
                          <th className="whitespace-nowrap px-4 py-3 text-right font-medium">
                            환불 처리
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {packageSales.map((sale) => {
                          const isOfflineSale =
                            sale.source === "offline_admin" ||
                            sale.source === "offline" ||
                            sale.sourceLabel === "오프라인 판매";
                          const refundForm = packageRefundForms[sale.id] ?? {
                            reason: "",
                          };
                          const isRefunding = refundingPackageOrderId === sale.id;
                          return (
                            <tr
                              key={sale.id}
                              className="border-t border-border/40 align-top transition-colors hover:bg-muted/30"
                            >
                              <td className="px-4 py-3 font-medium text-foreground">
                                <span
                                  className="line-clamp-2 max-w-[220px] break-keep"
                                  title={sale.packageName || "교체 서비스 패키지"}
                                >
                                  {sale.packageName || "교체 서비스 패키지"}
                                </span>
                              </td>
                              <td className="whitespace-nowrap px-4 py-3 text-right tabular-nums">
                                {Number(sale.sessions ?? 0).toLocaleString("ko-KR")}회
                              </td>
                              <td className="whitespace-nowrap px-4 py-3 text-right tabular-nums">
                                <div>{formatCurrency(sale.price)}</div>
                                {sale.isRefunded && (
                                  <div
                                    className={`mt-1 ${adminTypography.caption} text-destructive`}
                                  >
                                    환불 {formatCurrency(sale.refundAmount ?? sale.price)}
                                  </div>
                                )}
                              </td>
                              <td className="whitespace-nowrap px-4 py-3 text-center">
                                {PAYMENT_METHOD_LABELS[
                                  sale.paymentMethod as OfflinePaymentMethod
                                ] ??
                                  sale.paymentMethod ??
                                  "-"}
                              </td>
                              <td className="whitespace-nowrap px-4 py-3 text-center">
                                <div>{sale.paymentStatus || "-"}</div>
                                {sale.isRefunded && (
                                  <Badge
                                    variant="destructive"
                                    className="mt-1 shrink-0 whitespace-nowrap"
                                  >
                                    환불 완료
                                  </Badge>
                                )}
                              </td>
                              <td className="whitespace-nowrap px-4 py-3 text-right tabular-nums">
                                <div>{formatDate(sale.paidAt || sale.createdAt)}</div>
                                {sale.refundedAt && (
                                  <div className={`mt-1 ${adminTypography.caption}`}>
                                    환불일 {formatDate(sale.refundedAt)}
                                  </div>
                                )}
                              </td>
                              <td className="px-4 py-3 text-center">
                                <Badge
                                  variant={isOfflineSale ? "secondary" : "outline"}
                                  className="shrink-0 whitespace-nowrap"
                                >
                                  {sale.sourceLabel ||
                                    (isOfflineSale ? "오프라인 판매" : "온라인/기존 주문")}
                                </Badge>
                              </td>
                              <td className="px-4 py-3 text-right">
                                {!isOfflineSale ? (
                                  <span className={adminTypography.caption}>-</span>
                                ) : sale.isRefunded ? (
                                  <div className={`space-y-1 ${adminTypography.caption}`}>
                                    <div className="font-medium text-destructive">환불 완료</div>
                                    {sale.refundReason && <div>사유: {sale.refundReason}</div>}
                                  </div>
                                ) : (
                                  <div className="ml-auto min-w-[240px] space-y-2 text-left">
                                    <Input
                                      value={refundForm.reason}
                                      onChange={(event) =>
                                        updatePackageRefundForm(sale.id, {
                                          reason: event.target.value,
                                        })
                                      }
                                      placeholder="환불 사유 입력"
                                      disabled={!sale.canRefund || isRefunding}
                                    />
                                    <Button
                                      size="sm"
                                      variant="destructive"
                                      disabled={!sale.canRefund || isRefunding}
                                      onClick={() => handlePackageRefund(sale)}
                                    >
                                      {isRefunding ? "환불 처리 중..." : "수동 환불 처리"}
                                    </Button>
                                    <p className={adminTypography.caption}>
                                      이 처리는 사이트 내부 기록용입니다. 실제 현금/카드/계좌이체
                                      환불은 매장에서 별도로 완료해야 합니다.
                                    </p>
                                    {sale.refundBlockedReason && (
                                      <p className={`${adminTypography.caption} text-destructive`}>
                                        {sale.refundBlockedReason}
                                      </p>
                                    )}
                                    {refundForm.message && (
                                      <Message type={refundForm.messageType || "info"}>
                                        {refundForm.message}
                                      </Message>
                                    )}
                                  </div>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </CollapsibleSection>
            </div>
          </SectionCard>
        </div>
      </div>

      {/* Records Section */}
      <SectionCard id="offline-records">
        <SectionHeader
          icon={History}
          title="작업/매출 이력"
          description="해당 고객의 오프라인 작업/매출 이력"
          action={records.length > 0 ? <Badge variant="secondary">{records.length}건</Badge> : null}
        />
        <div className="p-6">
          {records.length === 0 ? (
            <div className="rounded-lg border border-dashed border-border/60 bg-muted/20 p-8 text-center">
              <History className="mx-auto h-10 w-10 text-muted-foreground/50" />
              <p className={`mt-3 ${adminTypography.metaMuted}`}>
                아직 등록된 오프라인 작업/매출 이력이 없습니다.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {records.map((record) => {
                const form = pointForms[record.id] ?? {
                  grantAmount: "",
                  grantReason: "",
                  grantRevertReason: "",
                  useAmount: "",
                  useReason: "",
                  deductRevertReason: "",
                };
                const hasGrant = !!record.points?.grantTxId;
                const hasDeduct = !!record.points?.deductTxId;
                const isGrantReverted = Boolean(
                  record.points?.grantRevertedAt || record.points?.grantRevertTxId,
                );
                const isDeductReverted = Boolean(
                  record.points?.deductRevertedAt || record.points?.deductRevertTxId,
                );
                const canProcessPoints = canUseLinkedFeatures;
                const pointUnavailableMessage =
                  item.linkedUserId && !item.linkedUser
                    ? "연결된 온라인 회원 정보를 찾을 수 없어 포인트를 처리할 수 없습니다."
                    : "온라인 회원과 연결된 고객만 포인트를 처리할 수 있습니다.";
                const packageUsage = record.packageUsage;
                const hasPackageUsage = !!packageUsage?.passId || !!packageUsage?.consumptionId;
                const isPackageUsageReverted = Boolean(
                  packageUsage?.isReverted || packageUsage?.revertedAt || packageUsage?.reverted,
                );
                const hasActivePackageUsage = hasPackageUsage && !isPackageUsageReverted;
                const usedPass = passes.find((pass) => pass.id === packageUsage?.passId);
                const packageForm = packageForms[record.id] ?? {
                  passId: usablePasses[0]?.id ?? "",
                  revertReason: "",
                };
                const canUsePackageForRecord =
                  canUseLinkedFeatures && !hasPackageUsage && usablePasses.length > 0;
                const isExpanded = expandedRecords.has(record.id);

                return (
                  <div
                    key={record.id}
                    className="rounded-lg border border-border/40 bg-card transition-shadow hover:shadow-sm"
                  >
                    {/* Record Header */}
                    <button
                      type="button"
                      onClick={() => toggleRecordExpand(record.id)}
                      className="flex w-full items-start justify-between gap-3 p-4 text-left"
                    >
                      <div className="flex min-w-0 flex-wrap items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                          <Calendar className="h-5 w-5" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="whitespace-nowrap font-medium tabular-nums text-foreground">
                              {formatDate(record.occurredAt)}
                            </span>
                            <Badge variant="outline" className="shrink-0 whitespace-nowrap">
                              {KIND_LABELS[record.kind] ?? record.kind}
                            </Badge>
                            <StatusBadge status={record.status} labels={RECORD_STATUS_LABELS} />
                          </div>
                          <p
                            className={`mt-1 line-clamp-2 break-keep ${adminTypography.metaMuted}`}
                          >
                            {record.lineSummary || formatLineSummary(record.lines)}
                          </p>
                        </div>
                      </div>
                      <div className="flex shrink-0 items-center gap-4">
                        <div className="text-right">
                          <p className="whitespace-nowrap font-semibold tabular-nums text-foreground">
                            {formatCurrency(record.payment?.amount)}
                          </p>
                          <StatusBadge
                            status={record.payment?.status || ""}
                            labels={PAYMENT_STATUS_LABELS}
                          />
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="h-5 w-5 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="h-5 w-5 text-muted-foreground" />
                        )}
                      </div>
                    </button>

                    {/* Expanded Content */}
                    {isExpanded && (
                      <div className="border-t border-border/40 p-4">
                        <div className="grid gap-4 grid-cols-3">
                          {/* Basic Info */}
                          <div className="space-y-3">
                            <h4 className={adminTypography.panelTitle}>기본 정보</h4>
                            <div className={`space-y-2 ${adminTypography.body}`}>
                              <div className="flex justify-between">
                                <span className="shrink-0 whitespace-nowrap text-muted-foreground">
                                  결제 수단
                                </span>
                                <span className="text-foreground">
                                  {record.payment?.method
                                    ? PAYMENT_METHOD_LABELS[record.payment.method]
                                    : "-"}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span className="shrink-0 whitespace-nowrap text-muted-foreground">
                                  메모
                                </span>
                                <span
                                  className="line-clamp-2 max-w-[200px] break-keep text-right text-foreground"
                                  title={record.memo || "-"}
                                >
                                  {record.memo || "-"}
                                </span>
                              </div>
                            </div>
                            {Array.isArray(record.lines) && record.lines.some(hasLineDetail) ? (
                              <div className="rounded-lg border border-border/40 bg-muted/20 p-3">
                                <p className={`mb-2 font-semibold ${adminTypography.caption}`}>
                                  라켓별 작업
                                </p>

                                <div className="space-y-2">
                                  {record.lines.filter(hasLineDetail).map((line, index) => (
                                    <div
                                      key={`${record.id}-line-${index}`}
                                      className="rounded-lg border border-border/40 bg-background/70 p-3"
                                    >
                                      <div className="mb-2 flex items-center justify-between gap-2">
                                        <p className={adminTypography.bodyStrong}>
                                          라켓 {index + 1}
                                        </p>

                                        {Number(line.amount ?? 0) > 0 ? (
                                          <Badge
                                            variant="secondary"
                                            className="shrink-0 whitespace-nowrap"
                                          >
                                            {formatCurrency(Number(line.amount ?? 0))}
                                          </Badge>
                                        ) : null}
                                      </div>

                                      <div className={`space-y-1.5 ${adminTypography.caption}`}>
                                        <div className="flex justify-between gap-3">
                                          <span className="shrink-0">라켓명</span>
                                          <span className="line-clamp-2 break-keep text-right text-foreground">
                                            {String(line.racketName ?? "").trim() || "-"}
                                          </span>
                                        </div>

                                        <div className="flex justify-between gap-3">
                                          <span className="shrink-0">스트링</span>
                                          <span className="line-clamp-2 break-keep text-right text-foreground">
                                            {formatLineStringInfo(line)}
                                          </span>
                                        </div>

                                        <div className="flex justify-between gap-3">
                                          <span className="shrink-0">텐션</span>
                                          <span className="text-right text-foreground">
                                            {formatLineTensionInfo(line)}
                                          </span>
                                        </div>

                                        {String(line.note ?? "").trim() ? (
                                          <div className="flex justify-between gap-3">
                                            <span className="shrink-0">메모</span>
                                            <span className="line-clamp-2 break-keep text-right text-foreground">
                                              {String(line.note ?? "").trim()}
                                            </span>
                                          </div>
                                        ) : null}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ) : null}
                            <Button asChild size="sm" variant="outline" className="w-full">
                              <Link href="/admin/offline">오프라인 관리에서 수정</Link>
                            </Button>
                          </div>

                          {/* Points Section */}
                          <div className="space-y-3">
                            <h4 className={adminTypography.panelTitle}>포인트</h4>
                            <div className="flex shrink-0 flex-wrap gap-2">
                              <Badge
                                variant={hasGrant ? "secondary" : "outline"}
                                className={hasGrant ? "bg-success/10 text-success" : ""}
                              >
                                적립 {formatPoints(record.points?.earn)}
                              </Badge>
                              <Badge
                                variant={hasDeduct ? "secondary" : "outline"}
                                className={hasDeduct ? "bg-warning/10 text-warning" : ""}
                              >
                                사용 {formatPoints(record.points?.use)}
                              </Badge>
                            </div>
                            {!canProcessPoints ? (
                              <p className={adminTypography.caption}>{pointUnavailableMessage}</p>
                            ) : (
                              <div className="grid gap-2 grid-cols-2">
                                <div className="space-y-2 rounded-lg border border-border/40 bg-muted/20 p-3">
                                  <p className={`font-medium ${adminTypography.caption}`}>
                                    적립 포인트
                                  </p>
                                  {hasGrant ? (
                                    <div className={`space-y-2 ${adminTypography.caption}`}>
                                      <Badge
                                        className={
                                          isGrantReverted
                                            ? "border-warning/30 bg-warning/10 text-warning"
                                            : "border-success/20 bg-success/10 text-success"
                                        }
                                      >
                                        {isGrantReverted ? "적립 취소 완료" : "포인트 적립 완료"}
                                      </Badge>
                                      <p>적립 포인트: {formatPoints(record.points?.earn)}</p>
                                      <p className="break-all">
                                        grantTxId: {record.points?.grantTxId}
                                      </p>
                                      {isGrantReverted ? (
                                        <>
                                          <p>
                                            취소일: {formatDate(record.points?.grantRevertedAt)}
                                          </p>
                                          {record.points?.grantRevertReason && (
                                            <p>사유: {record.points.grantRevertReason}</p>
                                          )}
                                          <p className="break-keep text-muted-foreground">
                                            취소된 포인트 처리는 같은 기록에서 다시 처리할 수
                                            없습니다. 재처리가 필요한 경우 새 작업 기록 또는 관리자
                                            포인트 조정 기능을 사용하세요.
                                          </p>
                                        </>
                                      ) : (
                                        <>
                                          <Input
                                            value={form.grantRevertReason}
                                            onChange={(e) =>
                                              updatePointForm(record.id, {
                                                grantRevertReason: e.target.value,
                                              })
                                            }
                                            placeholder="적립 취소 사유 입력"
                                            className={`h-8 ${adminTypography.body}`}
                                          />
                                          <Button
                                            type="button"
                                            size="sm"
                                            variant="destructive"
                                            className="w-full"
                                            onClick={() =>
                                              handleRecordPointRevert(record.id, "grant")
                                            }
                                            disabled={
                                              processingPointKey === `${record.id}:grant-revert`
                                            }
                                          >
                                            {processingPointKey === `${record.id}:grant-revert`
                                              ? "취소 중..."
                                              : "적립 취소"}
                                          </Button>
                                        </>
                                      )}
                                    </div>
                                  ) : (
                                    <>
                                      <Input
                                        inputMode="numeric"
                                        value={form.grantAmount}
                                        onChange={(e) =>
                                          updatePointForm(record.id, {
                                            grantAmount: e.target.value,
                                          })
                                        }
                                        placeholder="예: 1000"
                                        disabled={!canProcessPoints}
                                        className={`h-8 ${adminTypography.body}`}
                                      />
                                      <Input
                                        value={form.grantReason}
                                        onChange={(e) =>
                                          updatePointForm(record.id, {
                                            grantReason: e.target.value,
                                          })
                                        }
                                        placeholder="사유(선택)"
                                        disabled={!canProcessPoints}
                                        className={`h-8 ${adminTypography.body}`}
                                      />
                                      <Button
                                        type="button"
                                        size="sm"
                                        className="w-full"
                                        onClick={() => handleRecordPoints(record.id, "grant")}
                                        disabled={
                                          !canProcessPoints ||
                                          processingPointKey === `${record.id}:grant`
                                        }
                                      >
                                        {processingPointKey === `${record.id}:grant`
                                          ? "처리 중..."
                                          : "적립"}
                                      </Button>
                                    </>
                                  )}
                                </div>
                                <div className="space-y-2 rounded-lg border border-border/40 bg-muted/20 p-3">
                                  <p className={`font-medium ${adminTypography.caption}`}>
                                    사용 포인트
                                  </p>
                                  {hasDeduct ? (
                                    <div className={`space-y-2 ${adminTypography.caption}`}>
                                      <Badge
                                        className={
                                          isDeductReverted
                                            ? "border-warning/30 bg-warning/10 text-warning"
                                            : "border-primary/20 bg-primary/10 text-primary"
                                        }
                                      >
                                        {isDeductReverted ? "사용 취소 완료" : "포인트 사용 완료"}
                                      </Badge>
                                      <p>사용 포인트: {formatPoints(record.points?.use)}</p>
                                      <p className="break-all">
                                        deductTxId: {record.points?.deductTxId}
                                      </p>
                                      {isDeductReverted ? (
                                        <>
                                          <p>
                                            취소일: {formatDate(record.points?.deductRevertedAt)}
                                          </p>
                                          {record.points?.deductRevertReason && (
                                            <p>사유: {record.points.deductRevertReason}</p>
                                          )}
                                          <p className="break-keep text-muted-foreground">
                                            취소된 포인트 처리는 같은 기록에서 다시 처리할 수
                                            없습니다. 재처리가 필요한 경우 새 작업 기록 또는 관리자
                                            포인트 조정 기능을 사용하세요.
                                          </p>
                                        </>
                                      ) : (
                                        <>
                                          <Input
                                            value={form.deductRevertReason}
                                            onChange={(e) =>
                                              updatePointForm(record.id, {
                                                deductRevertReason: e.target.value,
                                              })
                                            }
                                            placeholder="사용 취소 사유 입력"
                                            className={`h-8 ${adminTypography.body}`}
                                          />
                                          <Button
                                            type="button"
                                            size="sm"
                                            variant="outline"
                                            className="w-full"
                                            onClick={() =>
                                              handleRecordPointRevert(record.id, "deduct")
                                            }
                                            disabled={
                                              processingPointKey === `${record.id}:deduct-revert`
                                            }
                                          >
                                            {processingPointKey === `${record.id}:deduct-revert`
                                              ? "취소 중..."
                                              : "사용 취소"}
                                          </Button>
                                        </>
                                      )}
                                    </div>
                                  ) : (
                                    <>
                                      <Input
                                        inputMode="numeric"
                                        value={form.useAmount}
                                        onChange={(e) =>
                                          updatePointForm(record.id, {
                                            useAmount: e.target.value,
                                          })
                                        }
                                        placeholder="예: 1000"
                                        disabled={!canProcessPoints}
                                        className={`h-8 ${adminTypography.body}`}
                                      />
                                      <Input
                                        value={form.useReason}
                                        onChange={(e) =>
                                          updatePointForm(record.id, {
                                            useReason: e.target.value,
                                          })
                                        }
                                        placeholder="사유(선택)"
                                        disabled={!canProcessPoints}
                                        className={`h-8 ${adminTypography.body}`}
                                      />
                                      <Button
                                        type="button"
                                        size="sm"
                                        variant="outline"
                                        className="w-full"
                                        onClick={() => handleRecordPoints(record.id, "deduct")}
                                        disabled={
                                          !canProcessPoints ||
                                          processingPointKey === `${record.id}:deduct`
                                        }
                                      >
                                        {processingPointKey === `${record.id}:deduct`
                                          ? "처리 중..."
                                          : "사용"}
                                      </Button>
                                    </>
                                  )}
                                </div>
                              </div>
                            )}
                            {form.message && (
                              <Message type={form.messageType || "info"}>{form.message}</Message>
                            )}
                          </div>

                          {/* Package Section */}
                          <div className="space-y-3">
                            <h4 className={adminTypography.panelTitle}>패키지</h4>
                            {isPackageUsageReverted ? (
                              <div className="rounded-lg border border-warning/30 bg-warning/5 p-3 text-foreground">
                                <Badge className="border-warning/30 bg-warning/10 text-warning">
                                  <History className="mr-1.5 h-3.5 w-3.5" />
                                  패키지 사용 취소됨
                                </Badge>
                                <p className={`mt-2 ${adminTypography.caption}`}>
                                  {getPassLabel(usedPass)} {Number(packageUsage?.usedCount ?? 1)}회
                                  사용 취소
                                </p>
                                <p className={`mt-1 ${adminTypography.caption}`}>
                                  취소일: {formatDate(packageUsage?.revertedAt)}
                                </p>
                                {packageUsage?.revertReason && (
                                  <p className={`mt-1 ${adminTypography.caption}`}>
                                    사유: {packageUsage.revertReason}
                                  </p>
                                )}
                                <p className={`mt-2 ${adminTypography.caption}`}>
                                  이 record는 취소 이력 보존을 위해 다시 패키지를 사용할 수
                                  없습니다. 새 record를 등록해 주세요.
                                </p>
                              </div>
                            ) : hasActivePackageUsage ? (
                              <div className="space-y-3 rounded-lg border border-success/30 bg-success/5 p-3">
                                <div>
                                  <Badge className="shrink-0 whitespace-nowrap bg-success/10 text-success border-success/20">
                                    <Check className="mr-1.5 h-3.5 w-3.5" />
                                    패키지 1회 사용 완료
                                  </Badge>
                                  <p className={`mt-2 ${adminTypography.caption}`}>
                                    {getPassLabel(usedPass)} {Number(packageUsage?.usedCount ?? 1)}
                                    회 사용
                                  </p>
                                  {packageUsage?.consumptionId && (
                                    <p className={`mt-1 ${adminTypography.caption}`}>
                                      consumptionId: {packageUsage.consumptionId}
                                    </p>
                                  )}
                                  {!packageUsage?.consumptionId && (
                                    <p
                                      className={`mt-1 ${adminTypography.caption} text-destructive`}
                                    >
                                      패키지 사용 상태를 복구해야 합니다.
                                    </p>
                                  )}
                                </div>
                                {packageUsage?.consumptionId && (
                                  <div className="space-y-2 rounded-lg border border-border/40 bg-background/70 p-3">
                                    <p className={adminTypography.caption}>
                                      잘못 차감한 경우에만 사용 취소하세요. 패키지 잔여 횟수가
                                      복구됩니다.
                                    </p>
                                    <Input
                                      value={packageForm.revertReason ?? ""}
                                      onChange={(e) =>
                                        updatePackageForm(record.id, {
                                          revertReason: e.target.value,
                                        })
                                      }
                                      placeholder="사용 취소 사유를 입력해주세요."
                                      disabled={processingPackageRecordId === record.id}
                                      className={`h-8 ${adminTypography.body}`}
                                    />
                                    <Button
                                      type="button"
                                      size="sm"
                                      variant="destructive"
                                      className="w-full"
                                      onClick={() => handleRecordPackageRevert(record.id)}
                                      disabled={processingPackageRecordId === record.id}
                                    >
                                      {processingPackageRecordId === record.id
                                        ? "처리 중..."
                                        : "사용 취소"}
                                    </Button>
                                  </div>
                                )}
                              </div>
                            ) : (
                              <Badge
                                variant="outline"
                                className="shrink-0 whitespace-nowrap text-muted-foreground"
                              >
                                패키지 미사용
                              </Badge>
                            )}
                            {!canUseLinkedFeatures && !hasPackageUsage && (
                              <p className={adminTypography.caption}>
                                온라인 회원과 연결된 고객만 패키지를 사용할 수 있습니다.
                              </p>
                            )}
                            {canUseLinkedFeatures &&
                              usablePasses.length === 0 &&
                              !hasPackageUsage && (
                                <p className={adminTypography.caption}>
                                  사용 가능한 패키지가 없습니다.
                                </p>
                              )}
                            {!hasPackageUsage &&
                              canUseLinkedFeatures &&
                              usablePasses.length > 0 && (
                                <div className="space-y-2 rounded-lg border border-border/40 bg-muted/20 p-3">
                                  <p className={`font-medium ${adminTypography.caption}`}>
                                    사용할 패키지
                                  </p>
                                  <Select
                                    value={packageForm.passId}
                                    onChange={(v) =>
                                      updatePackageForm(record.id, {
                                        passId: v,
                                      })
                                    }
                                    disabled={
                                      !canUsePackageForRecord ||
                                      processingPackageRecordId === record.id
                                    }
                                    options={usablePasses.map((pass) => ({
                                      value: pass.id,
                                      label: `${getPassLabel(pass)} · 잔여 ${Number(pass.remainingCount ?? 0)}회`,
                                    }))}
                                  />
                                  <p className={adminTypography.caption}>
                                    이 기록에 패키지 1회를 사용 처리합니다.
                                  </p>
                                  <Button
                                    type="button"
                                    size="sm"
                                    variant="outline"
                                    className="w-full"
                                    onClick={() => handleRecordPackageUse(record.id)}
                                    disabled={
                                      !canUsePackageForRecord ||
                                      processingPackageRecordId === record.id
                                    }
                                  >
                                    <Package className="mr-2 h-4 w-4" />
                                    {processingPackageRecordId === record.id
                                      ? "처리 중..."
                                      : "패키지 사용"}
                                  </Button>
                                </div>
                              )}
                            {packageForm.message && (
                              <Message type={packageForm.messageType || "info"}>
                                {packageForm.message}
                              </Message>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </SectionCard>
    </div>
  );
}
