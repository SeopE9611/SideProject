import { revalidateTag } from "next/cache";
import { NextResponse } from "next/server";
import clientPromise from "@/lib/mongodb";
import { ObjectId } from "mongodb";
import {
  RACKET_BRANDS,
  normalizeAndValidateGripSize,
  normalizeAndValidateStringPattern,
} from "@/lib/constants";
import { normalizeItemShippingFee } from "@/lib/shipping-fee";
import { requireAdmin } from "@/lib/admin.guard";
import { verifyAdminCsrf } from "@/lib/admin/verifyAdminCsrf";
import { appendAdminAudit } from "@/lib/admin/appendAdminAudit";
import { HOME_RACKETS_CACHE_TAG } from "@/lib/home/home-preview";

function toRacketAuditSnapshot(doc: any) {
  return {
    brand: typeof doc?.brand === "string" ? doc.brand : "",
    model: typeof doc?.model === "string" ? doc.model : "",
    status: typeof doc?.status === "string" ? doc.status : "",
    condition: typeof doc?.condition === "string" ? doc.condition : "",
    price: typeof doc?.price === "number" ? doc.price : null,
    rentalAvailable: typeof doc?.rental?.enabled === "boolean" ? doc.rental.enabled : false,
    quantity: typeof doc?.quantity === "number" ? doc.quantity : null,
  };
}

// GET - 단일 조회
export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireAdmin(req);
  if (!guard.ok) return guard.res;

  const db = (await clientPromise).db();
  const { id } = await ctx.params;
  if (!ObjectId.isValid(id)) {
    return NextResponse.json({ message: "Bad Request" }, { status: 400 });
  }
  const doc = await db.collection("used_rackets").findOne({ _id: new ObjectId(id) });
  if (!doc) return NextResponse.json({ message: "Not Found" }, { status: 404 });
  return NextResponse.json({
    ...doc,
    marketing: normalizeRacketMarketing((doc as Record<string, unknown>).marketing),
    shippingFee: normalizeItemShippingFee((doc as Record<string, unknown>).shippingFee),
    id: doc._id.toString(),
    _id: undefined,
  });
}

// PATCH - 수정
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireAdmin(req);
  if (!guard.ok) return guard.res;
  const csrf = verifyAdminCsrf(req);
  if (!csrf.ok) return csrf.res;

  const db = (await clientPromise).db();
  let body: any = null;
  try {
    body = await req.json();
  } catch (e) {
    console.error("[admin/rackets] invalid json", e);
    return NextResponse.json({ message: "INVALID_JSON" }, { status: 400 });
  }

  if (!body || typeof body !== "object") {
    return NextResponse.json({ message: "INVALID_BODY" }, { status: 400 });
  }
  const { id } = await ctx.params;
  if (!ObjectId.isValid(id)) {
    return NextResponse.json({ message: "Bad Request" }, { status: 400 });
  }
  const enabled = !!body?.rental?.enabled;
  const disabledReason = String(body?.rental?.disabledReason ?? "").trim();
  if (enabled === false && !disabledReason) {
    return NextResponse.json({ message: "대여 불가 사유가 필요합니다." }, { status: 400 });
  }

  const numOrNull = (v: any) => (v == null || v === "" ? null : Number(v));

  const set: any = {
    brand: String(body.brand ?? "")
      .trim()
      .toLowerCase(),
    model: String(body.model ?? "").trim(),
    year: Number(body.year ?? 0) || null,
    spec: {
      weight: numOrNull(body.spec?.weight),
      balance: numOrNull(body.spec?.balance),
      headSize: numOrNull(body.spec?.headSize),
      lengthIn: numOrNull(body.spec?.lengthIn),
      swingWeight: numOrNull(body.spec?.swingWeight),
      stiffnessRa: numOrNull(body.spec?.stiffnessRa),
      // 서버에서도 value 검증/정규화 수행(클라이언트 우회 요청 방어)
      pattern: normalizeAndValidateStringPattern(body.spec?.pattern ?? ""),
      gripSize: normalizeAndValidateGripSize(body.spec?.gripSize ?? ""),
    },
    condition: body.condition ?? "B",
    price: Number(body.price ?? 0),
    shippingFee: normalizeItemShippingFee(body.shippingFee),
    images: Array.isArray(body.images) ? body.images : [],
    status: body.status ?? "available",
    isVisible: body.isVisible === false ? false : true,
    searchKeywords: Array.isArray(body.searchKeywords)
      ? body.searchKeywords.map((k: any) => String(k).trim()).filter((k: string) => k.length > 0)
      : [],
    rental: {
      enabled,
      deposit: Number(body?.rental?.deposit ?? 0),
      fee: {
        d7: Number(body?.rental?.fee?.d7 ?? 0),
        d15: Number(body?.rental?.fee?.d15 ?? 0),
        d30: Number(body?.rental?.fee?.d30 ?? 0),
      },
      disabledReason: enabled ? "" : disabledReason,
    },
    quantity: Math.max(1, Number(body.quantity ?? 1)),
    marketing: normalizeRacketMarketing(body.marketing),
    updatedAt: new Date(),
  };

  if (
    set.marketing.isSale &&
    (set.marketing.salePrice < 1 || set.marketing.salePrice >= set.price)
  ) {
    return NextResponse.json(
      { message: "할인가는 1원 이상이며 정가보다 낮아야 합니다." },
      { status: 400 },
    );
  }

  if (!set.brand || !set.model) {
    return NextResponse.json({ message: "브랜드/모델은 필수입니다." }, { status: 400 });
  }

  if (!set.spec.pattern) {
    return NextResponse.json({ message: "스트링 패턴 값이 유효하지 않습니다." }, { status: 400 });
  }
  if (!set.spec.gripSize) {
    return NextResponse.json({ message: "그립 사이즈 값이 유효하지 않습니다." }, { status: 400 });
  }

  const brandOk = RACKET_BRANDS.some((b) => b.value === set.brand);
  if (!brandOk) {
    return NextResponse.json({ message: "브랜드 값이 유효하지 않습니다." }, { status: 400 });
  }

  for (const k of [
    "weight",
    "balance",
    "headSize",
    "lengthIn",
    "swingWeight",
    "stiffnessRa",
  ] as const) {
    const v = set.spec?.[k];
    if (v !== null && v !== undefined && !Number.isFinite(v)) {
      return NextResponse.json({ message: `spec.${k} 값이 유효하지 않습니다.` }, { status: 400 });
    }
  }

  const beforeDoc = await db.collection("used_rackets").findOne({ _id: new ObjectId(id) });
  if (!beforeDoc) return NextResponse.json({ message: "Not Found" }, { status: 404 });

  const res = await db
    .collection("used_rackets")
    .updateOne({ _id: new ObjectId(id) }, { $set: set });
  if (!res.matchedCount) return NextResponse.json({ message: "Not Found" }, { status: 404 });
  const before = toRacketAuditSnapshot(beforeDoc);
  const after = toRacketAuditSnapshot(set);
  await appendAdminAudit(
    db,
    {
      type: "racket.update",
      actorId: guard.admin._id,
      targetId: id,
      message: "관리자 라켓 수정",
      diff: {
        targetType: "racket",
        before,
        after,
        metadata: {
          changedKeys: Object.keys(set),
          actor: {
            id: String(guard.admin._id),
            email: guard.admin.email ?? null,
            name: guard.admin.name ?? null,
            role: guard.admin.role ?? "admin",
          },
        },
      },
    },
    req,
  );
  revalidateTag(HOME_RACKETS_CACHE_TAG);
  return NextResponse.json({ ok: true });
}

// DELETE 삭제
export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const guard = await requireAdmin(req);
  if (!guard.ok) return guard.res;
  const csrf = verifyAdminCsrf(req);
  if (!csrf.ok) return csrf.res;

  const db = (await clientPromise).db();
  const { id } = await ctx.params;
  if (!ObjectId.isValid(id)) {
    return NextResponse.json({ message: "Bad Request" }, { status: 400 });
  }
  const beforeDoc = await db.collection("used_rackets").findOne({ _id: new ObjectId(id) });
  if (!beforeDoc) return NextResponse.json({ message: "Not Found" }, { status: 404 });
  const res = await db.collection("used_rackets").deleteOne({ _id: new ObjectId(id) });
  if (!res.deletedCount) return NextResponse.json({ message: "Not Found" }, { status: 404 });
  await appendAdminAudit(
    db,
    {
      type: "racket.delete",
      actorId: guard.admin._id,
      targetId: id,
      message: "관리자 라켓 삭제",
      diff: {
        targetType: "racket",
        before: toRacketAuditSnapshot(beforeDoc),
        after: { deleted: true },
        metadata: {
          actor: {
            id: String(guard.admin._id),
            email: guard.admin.email ?? null,
            name: guard.admin.name ?? null,
            role: guard.admin.role ?? "admin",
          },
        },
      },
    },
    req,
  );
  revalidateTag(HOME_RACKETS_CACHE_TAG);
  return NextResponse.json({ ok: true });
}
function normalizeRacketMarketing(value: any) {
  return {
    isFeatured: value?.isFeatured === true,
    isNew: value?.isNew === true,
    isSale: value?.isSale === true,
    salePrice: Math.max(0, Number(value?.salePrice ?? 0) || 0),
  };
}
