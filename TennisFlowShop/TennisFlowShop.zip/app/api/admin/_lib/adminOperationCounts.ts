import type { Db, Document, Filter } from "mongodb";

import {
  ORDER_CANCELED_TERMINAL_VALUES,
  ORDER_CONFIRMED_TERMINAL_VALUES,
  ORDER_DELIVERED_MONITORING_VALUES,
  ORDER_REFUNDED_TERMINAL_VALUES,
} from "@/lib/status/flow-status";

import { createPackagePaymentCheckFilter } from "@/app/api/admin/_lib/packagePaymentCheckFilter";
import { OFFLINE_PACKAGE_ORDER_FILTER } from "@/app/api/admin/offline/_lib/packageOrderOffline";
import type { SidebarBadgeKey } from "@/components/admin/sidebar-navigation";
import type {
  OperationGroupCounts,
  OperationSignalCounts,
  OperationTaskCounts,
} from "@/types/admin/operations";

type NavigationCounts = Partial<Record<SidebarBadgeKey, number>>;
type Measure = <T>(name: string, work: Promise<T> | (() => Promise<T> | T)) => Promise<T>;
type OperationCountsOptions = {
  measure?: Measure;
};

const TERMINAL_STATUS_VALUES = [
  ...ORDER_CANCELED_TERMINAL_VALUES,
  ...ORDER_REFUNDED_TERMINAL_VALUES,
  ...ORDER_CONFIRMED_TERMINAL_VALUES,
  "completed",
  "returned",
  "반납완료",
  "교체완료",
];

const PAYMENT_PENDING_VALUES = [
  "pending",
  "unpaid",
  "ready",
  "bank_pending",
  "결제대기",
  "대기중",
  "입금확인",
  "활성화대기",
];
const PAYMENT_DONE_VALUES = ["paid", "confirmed", "payment_completed", "결제완료"];
const PAYMENT_CANCELLED_VALUES = [
  "결제취소",
  "취소",
  "환불",
  "환불완료",
  "refunded",
  "cancelled",
  "canceled",
];

const VISIT_PICKUP_VALUES = [
  "visit",
  "pickup",
  "store_pickup",
  "visit_pickup",
  "방문수령",
  "방문 수령",
  "매장수령",
  "매장 수령",
  "매장방문",
  "매장 방문",
];

const orderNeedsActionFilter: Filter<Document> = {
  $and: [
    {
      $or: [
        { "cancel.status": "requested" },
        { "cancelRequest.status": { $in: ["requested", "요청"] } },
        { cancelStatus: "requested" },
        { status: "취소처리중" },
        { "cancelRequest.status": "approved_pending_pg_cancel" },
        { "cancelRequest.pgCancelBlocked.reason": "unsettled_amount_shortage" },
        { "paymentInfo.niceSync.manualActionReason": "unsettled_amount_shortage" },
        { paymentStatus: { $in: PAYMENT_PENDING_VALUES } },
        {
          status: {
            $in: [
              "pending",
              "paid",
              "payment_completed",
              "preparing",
              "shipping_pending",
              "대기중",
              "결제완료",
              "배송준비중",
              ...ORDER_DELIVERED_MONITORING_VALUES,
            ],
          },
        },
      ],
    },
    { status: { $nin: TERMINAL_STATUS_VALUES } },
  ],
};

const rentalDepositRefundRequiredFilter: Filter<Document> = {
  $and: [
    { status: { $in: ["returned", "반납완료"] } },
    {
      $or: [
        { depositRefundedAt: { $exists: false } },
        { depositRefundedAt: null },
        { depositRefundedAt: "" },
      ],
    },
  ],
};

const rentalNeedsActionFilter: Filter<Document> = {
  $or: [
    rentalDepositRefundRequiredFilter,
    {
      $and: [
        {
          $or: [
            { "cancel.status": "requested" },
            { "cancelRequest.status": { $in: ["requested", "요청"] } },
            { cancelStatus: "requested" },
            {
              status: {
                $in: [
                  "created",
                  "pending",
                  "paid",
                  "ready",
                  "out",
                  "rented",
                  "overdue",
                  "return_requested",
                  "대기중",
                  "대여중",
                  "연체",
                ],
              },
            },
            { paymentStatus: { $in: PAYMENT_PENDING_VALUES } },
          ],
        },
        { status: { $nin: TERMINAL_STATUS_VALUES } },
      ],
    },
  ],
};

const stringingNeedsActionFilter: Filter<Document> = {
  status: {
    $in: [
      "submitted",
      "received",
      "reviewing",
      "accepted",
      "confirmed",
      "in_progress",
      "work_pending",
      "검토 중",
      "접수완료",
      "작업 중",
    ],
    $nin: ["completed", "교체완료", "canceled", "cancelled", "취소"],
  },
};

const offlineUnpaidFilter: Filter<Document> = {
  $or: [
    { "payment.status": { $in: ["pending", "unpaid", "결제대기"] } },
    { paymentStatus: { $in: ["pending", "unpaid", "결제대기"] } },
    { isPaid: false },
  ],
};

const offlinePackageIssueReconcileFilter: Filter<Document> = {
  $and: [
    OFFLINE_PACKAGE_ORDER_FILTER,
    {
      $or: [
        { "meta.requiresOfflineIssueReconcile": true },
        { "meta.offlineIssueStatus": "issue_failed" },
        { "meta.offlineIssueError": { $exists: true, $nin: [null, ""] } },
      ],
    },
    {
      $or: [
        { "meta.reconcileStatus": { $exists: false } },
        { "meta.reconcileStatus": null },
        { "meta.reconcileStatus": "open" },
      ],
    },
  ],
};

const offlinePackageUsageReconcileFilter: Filter<Document> = {
  $and: [
    { "packageUsage.passId": { $exists: true, $nin: [null, ""] } },
    {
      $or: [
        { "packageUsage.consumptionId": { $exists: false } },
        { "packageUsage.consumptionId": null },
        { "packageUsage.consumptionId": "" },
      ],
    },
    {
      $or: [{ "packageUsage.revertedAt": { $exists: false } }, { "packageUsage.revertedAt": null }],
    },
    { "packageUsage.reverted": { $ne: true } },
    {
      $or: [
        { "packageUsage.reconcileStatus": { $exists: false } },
        { "packageUsage.reconcileStatus": null },
        { "packageUsage.reconcileStatus": "open" },
      ],
    },
  ],
};

const academyNeedsActionFilter: Filter<Document> = {
  status: { $in: ["submitted", "reviewing", "contacted"] },
};

const reviewNeedsActionFilter: Filter<Document> = {
  $or: [
    { status: { $in: ["pending", "reported"] } },
    { hidden: true, resolvedAt: { $exists: false } },
  ],
};

const boardNeedsActionFilter: Filter<Document> = {
  $or: [
    { status: { $in: ["reported", "pending"] } },
    { reportCount: { $gt: 0 }, moderationStatus: { $ne: "resolved" } },
  ],
};

const cancelRequestFilter: Filter<Document> = {
  $or: [
    { "cancel.status": "requested" },
    { "cancelRequest.status": { $in: ["requested", "요청"] } },
    { cancelStatus: "requested" },
    { cancelRequested: true },
    { cancelRequestStatus: "requested" },
    { status: "취소처리중" },
    { "cancelRequest.status": "approved_pending_pg_cancel" },
    { "cancelRequest.pgCancelBlocked.reason": "unsettled_amount_shortage" },
    { "paymentInfo.niceSync.manualActionReason": "unsettled_amount_shortage" },
  ],
};

const paymentCheckFilter: Filter<Document> = {
  $and: [
    {
      $or: [
        { paymentStatus: { $in: PAYMENT_PENDING_VALUES } },
        { "paymentInfo.status": { $in: PAYMENT_PENDING_VALUES } },
        { status: { $in: ["pending", "대기중"] } },
      ],
    },
    { status: { $nin: TERMINAL_STATUS_VALUES } },
  ],
};

const orderPaymentCheckFilter: Filter<Document> = {
  $and: [
    paymentCheckFilter,
    {
      $or: [{ totalPrice: { $exists: false } }, { totalPrice: null }, { totalPrice: { $gt: 0 } }],
    },
  ],
};

const packagePaymentCheckFilter = createPackagePaymentCheckFilter();

const missingTrackingFilter: Filter<Document> = {
  $and: [
    {
      $or: [
        { "shippingInfo.invoice.trackingNumber": { $exists: false } },
        { "shippingInfo.invoice.trackingNumber": { $in: [null, ""] } },
      ],
    },
    {
      $or: [
        { "shippingInfo.trackingNo": { $exists: false } },
        { "shippingInfo.trackingNo": { $in: [null, ""] } },
      ],
    },
    {
      $or: [{ trackingNo: { $exists: false } }, { trackingNo: { $in: [null, ""] } }],
    },
  ],
};

const orderShippingMissingFilter: Filter<Document> = {
  $and: [
    {
      $or: [
        { paymentStatus: { $in: PAYMENT_DONE_VALUES } },
        { "paymentInfo.status": { $in: PAYMENT_DONE_VALUES } },
        {
          status: {
            $in: [
              "paid",
              "payment_completed",
              "preparing",
              "shipping_pending",
              "결제완료",
              "배송준비중",
            ],
          },
        },
      ],
    },
    { status: { $nin: TERMINAL_STATUS_VALUES } },
    {
      $or: [
        { "shippingInfo.shippingMethod": { $exists: false } },
        { "shippingInfo.shippingMethod": { $nin: VISIT_PICKUP_VALUES } },
      ],
    },
    {
      $or: [
        { "shippingInfo.deliveryMethod": { $exists: false } },
        { "shippingInfo.deliveryMethod": { $nin: VISIT_PICKUP_VALUES } },
      ],
    },
    missingTrackingFilter,
  ],
};

const stringingShippingMissingFilter: Filter<Document> = {
  $and: [
    { status: { $in: ["completed", "교체완료", "work_done", "done"] } },
    {
      paymentStatus: {
        $nin: ["cancelled", "canceled", "refunded", "환불완료"],
      },
    },
    {
      $or: [
        { collectionMethod: { $exists: false } },
        { collectionMethod: { $nin: VISIT_PICKUP_VALUES } },
      ],
    },
    {
      $or: [
        { "shippingInfo.collectionMethod": { $exists: false } },
        { "shippingInfo.collectionMethod": { $nin: VISIT_PICKUP_VALUES } },
      ],
    },
    {
      $or: [
        { "shippingInfo.shippingMethod": { $exists: false } },
        { "shippingInfo.shippingMethod": { $nin: VISIT_PICKUP_VALUES } },
      ],
    },
    {
      $and: [
        {
          $or: [
            { "shippingInfo.invoice.trackingNumber": { $exists: false } },
            { "shippingInfo.invoice.trackingNumber": { $in: [null, ""] } },
          ],
        },
        {
          $or: [
            { "shippingInfo.returnInvoice.trackingNumber": { $exists: false } },
            {
              "shippingInfo.returnInvoice.trackingNumber": { $in: [null, ""] },
            },
          ],
        },
      ],
    },
  ],
};

const rentalShippingMissingFilter: Filter<Document> = {
  $and: [
    {
      $or: [
        { paymentStatus: { $in: PAYMENT_DONE_VALUES } },
        { "paymentInfo.status": { $in: PAYMENT_DONE_VALUES } },
        { status: { $in: ["paid", "ready", "결제완료"] } },
      ],
    },
    { status: { $nin: TERMINAL_STATUS_VALUES } },
    {
      $and: [
        {
          $or: [
            { "shipping.outbound.trackingNumber": { $exists: false } },
            { "shipping.outbound.trackingNumber": { $in: [null, ""] } },
          ],
        },
        {
          $or: [
            { outboundTrackingNo: { $exists: false } },
            { outboundTrackingNo: { $in: [null, ""] } },
          ],
        },
      ],
    },
  ],
};

const rentalDueFilter = (nowPlus48Hours: Date): Filter<Document> => ({
  $or: [
    rentalDepositRefundRequiredFilter,
    {
      $and: [
        {
          $or: [
            { status: { $in: ["overdue", "return_requested", "연체"] } },
            {
              $and: [
                { status: { $in: ["rented", "out", "대여중"] } },
                {
                  $or: [
                    { returnDueAt: { $lte: nowPlus48Hours } },
                    { endDate: { $lte: nowPlus48Hours } },
                    { dueAt: { $lte: nowPlus48Hours } },
                    {
                      $and: [
                        { returnDueAt: { $in: [null, ""] } },
                        { endDate: { $in: [null, ""] } },
                        { dueAt: { $in: [null, ""] } },
                      ],
                    },
                  ],
                },
              ],
            },
          ],
        },
        { status: { $nin: TERMINAL_STATUS_VALUES } },
      ],
    },
  ],
});

const linkedReviewFilter: Filter<Document> = {
  // 업무 큐 안내용 근사치: 기존 operations의 review/info 신호처럼 연결 신청서의 결제 문맥 누락을 전체 기준으로 집계한다.
  $or: [
    {
      $and: [
        {
          $or: [
            { orderId: { $exists: true, $nin: [null, ""] } },
            { rentalId: { $exists: true, $nin: [null, ""] } },
          ],
        },
        {
          $or: [
            { paymentStatus: { $exists: false } },
            { paymentStatus: null },
            { paymentStatus: "" },
          ],
        },
        {
          $or: [
            { paymentSource: { $exists: false } },
            { paymentSource: null },
            { paymentSource: "" },
          ],
        },
        { packageApplied: { $ne: true } },
        { servicePaid: { $ne: true } },
      ],
    },
    { paymentStatus: { $in: ["failed", "결제실패"] } },
    { paymentSource: { $in: ["order:", "rental:"] } },
  ],
};

async function safeCount(db: Db, collectionName: string, filter: Filter<Document>, label?: string) {
  try {
    return await db.collection(collectionName).countDocuments(filter, { maxTimeMS: 2500 });
  } catch (error) {
    console.error(`[admin/operation-counts] failed to count ${label ?? collectionName}`, error);
    return 0;
  }
}

const standaloneStringingNeedsActionFilter: Filter<Document> = {
  $and: [
    stringingNeedsActionFilter,
    {
      $or: [{ orderId: { $exists: false } }, { orderId: null }, { orderId: "" }],
    },
    {
      $or: [{ rentalId: { $exists: false } }, { rentalId: null }, { rentalId: "" }],
    },
  ],
};

export function toOperationSignalCounts(taskCounts: OperationTaskCounts): OperationSignalCounts {
  // navigation-summary의 operationSignalCounts는 전역 raw task count 기반 참고치입니다.
  // /admin/operations 목록 화면의 그룹 기준 신호 수는 목록 API 응답을 우선 사용합니다.
  return { ...taskCounts };
}

/** 패키지 처리 대상을 운영 목록 대표 행 수에 한 번만 합칩니다. */
export function withPackageOperationGroupCounts(
  groupCounts: OperationGroupCounts,
  packageRepresentativeRows: number,
): OperationGroupCounts {
  const previousPackageRows = groupCounts.packageRepresentativeRows ?? 0;
  const totalWithoutPackages = Math.max(
    0,
    groupCounts.totalRepresentativeTasks - previousPackageRows,
  );
  const todayWithoutPackages =
    typeof groupCounts.todayRepresentativeTasks === "number"
      ? Math.max(0, groupCounts.todayRepresentativeTasks - previousPackageRows)
      : totalWithoutPackages;

  return {
    ...groupCounts,
    packageRepresentativeRows,
    totalRepresentativeTasks: totalWithoutPackages + packageRepresentativeRows,
    todayRepresentativeTasks: todayWithoutPackages + packageRepresentativeRows,
  };
}

/** 좌측 메뉴 배지는 운영 목록과 각 관리 화면이 공유하는 대표 행 집계만 사용합니다. */
export function toAdminNavigationAttentionCounts(input: {
  operationGroupCounts: OperationGroupCounts;
  operationTaskCounts: OperationTaskCounts;
  reviews: number;
  boards: number;
}): NavigationCounts {
  const { operationGroupCounts, operationTaskCounts, reviews, boards } = input;

  return {
    operations: operationGroupCounts.totalRepresentativeTasks,
    orders: operationGroupCounts.orderManagementRepresentativeRows ?? 0,
    rentals: operationGroupCounts.rentalRepresentativeRows ?? 0,
    offline: operationTaskCounts.offline,
    academyApplications: operationTaskCounts.academyApplications,
    packages:
      operationGroupCounts.packageRepresentativeRows ?? operationTaskCounts.packagePaymentCheck,
    reviews,
    boards,
  };
}

export async function countAdminOperationGroupCounts(
  db: Db,
  options: OperationCountsOptions = {},
): Promise<OperationGroupCounts> {
  const measure: Measure =
    options.measure ?? ((_, work) => Promise.resolve(typeof work === "function" ? work() : work));
  const [orders, rentals, standaloneStringing] = await Promise.all([
    measure("operationCounts.group.orders", () =>
      safeCount(db, "orders", orderNeedsActionFilter, "representative order tasks"),
    ),
    measure("operationCounts.group.rentals", () =>
      safeCount(db, "rental_orders", rentalNeedsActionFilter, "representative rental tasks"),
    ),
    measure("operationCounts.group.stringingApplications", () =>
      safeCount(
        db,
        "stringing_applications",
        standaloneStringingNeedsActionFilter,
        "representative standalone stringing tasks",
      ),
    ),
  ]);

  return {
    orderManagementRepresentativeRows: orders + standaloneStringing,
    rentalRepresentativeRows: rentals,
    standaloneStringingRepresentativeRows: standaloneStringing,
    totalRepresentativeTasks: orders + rentals + standaloneStringing,
    // 실제 오늘 생성/변경 기준이 아니라 현재 남은 대표 업무 기준입니다.
    todayRepresentativeTasks: orders + rentals + standaloneStringing,
  };
}

export async function countAdminOfflineNeedsAction(db: Db): Promise<number> {
  const [offlineUnpaidRecords, offlinePackageIssueReconcile, offlinePackageUsageReconcile] =
    await Promise.all([
      safeCount(db, "offline_service_records", offlineUnpaidFilter, "offline unpaid records"),
      safeCount(
        db,
        "packageOrders",
        offlinePackageIssueReconcileFilter,
        "offline package issue reconciliation",
      ),
      safeCount(
        db,
        "offline_service_records",
        offlinePackageUsageReconcileFilter,
        "offline package usage reconciliation",
      ),
    ]);

  return offlineUnpaidRecords + offlinePackageIssueReconcile + offlinePackageUsageReconcile;
}

export async function countAdminOperationTaskCounts(
  db: Db,
  options: OperationCountsOptions = {},
): Promise<OperationTaskCounts> {
  const measure: Measure =
    options.measure ?? ((_, work) => Promise.resolve(typeof work === "function" ? work() : work));
  const nowPlus48Hours = new Date(Date.now() + 48 * 60 * 60 * 1000);

  const [
    orderCancelRequests,
    stringingCancelRequests,
    rentalCancelRequests,
    orderPaymentCheck,
    stringingPaymentCheck,
    rentalPaymentCheck,
    packagePaymentCheck,
    orderShippingMissing,
    stringingShippingMissing,
    rentalShippingMissing,
    stringingWork,
    rentalDue,
    linkedReview,
    offline,
    academyApplications,
  ] = await Promise.all([
    measure("operationCounts.orders.cancelRequests", () =>
      safeCount(db, "orders", cancelRequestFilter, "order cancel requests"),
    ),
    measure("operationCounts.stringingApplications.cancelRequests", () =>
      safeCount(db, "stringing_applications", cancelRequestFilter, "stringing cancel requests"),
    ),
    measure("operationCounts.rentals.cancelRequests", () =>
      safeCount(db, "rental_orders", cancelRequestFilter, "rental cancel requests"),
    ),
    measure("operationCounts.orders.paymentCheck", () =>
      safeCount(db, "orders", orderPaymentCheckFilter, "order payment check"),
    ),
    measure("operationCounts.stringingApplications.paymentCheck", () =>
      safeCount(db, "stringing_applications", paymentCheckFilter, "stringing payment check"),
    ),
    measure("operationCounts.rentals.paymentCheck", () =>
      safeCount(db, "rental_orders", paymentCheckFilter, "rental payment check"),
    ),
    measure("operationCounts.packages.paymentCheck", () =>
      safeCount(db, "packageOrders", packagePaymentCheckFilter, "package payment check"),
    ),
    measure("operationCounts.orders.shippingMissing", () =>
      safeCount(db, "orders", orderShippingMissingFilter, "order shipping missing"),
    ),
    measure("operationCounts.stringingApplications.shippingMissing", () =>
      safeCount(
        db,
        "stringing_applications",
        stringingShippingMissingFilter,
        "stringing shipping missing",
      ),
    ),
    measure("operationCounts.rentals.shippingMissing", () =>
      safeCount(db, "rental_orders", rentalShippingMissingFilter, "rental shipping missing"),
    ),
    measure("operationCounts.stringingApplications.work", () =>
      safeCount(db, "stringing_applications", stringingNeedsActionFilter, "stringing work"),
    ),
    measure("operationCounts.rentals.due", () =>
      safeCount(db, "rental_orders", rentalDueFilter(nowPlus48Hours), "rental due"),
    ),
    measure("operationCounts.stringingApplications.linkedReview", () =>
      safeCount(db, "stringing_applications", linkedReviewFilter, "linked review"),
    ),
    measure("operationCounts.offline", () => countAdminOfflineNeedsAction(db)),
    measure("operationCounts.academyApplications", () =>
      safeCount(
        db,
        "academy_lesson_applications",
        academyNeedsActionFilter,
        "academy applications",
      ),
    ),
  ]);

  return {
    cancelRequests: orderCancelRequests + stringingCancelRequests + rentalCancelRequests,
    paymentCheck: orderPaymentCheck + stringingPaymentCheck + rentalPaymentCheck,
    packagePaymentCheck,
    shippingMissing: orderShippingMissing + stringingShippingMissing + rentalShippingMissing,
    stringingWork,
    rentalDue,
    linkedReview,
    offline,
    academyApplications,
  };
}

export async function countAdminNavigationSummary(db: Db): Promise<{
  counts: NavigationCounts;
  operationTaskCounts: OperationTaskCounts;
  operationGroupCounts: OperationGroupCounts;
  operationSignalCounts: OperationSignalCounts;
}> {
  const [reviews, boards, operationTaskCounts, baseOperationGroupCounts] = await Promise.all([
    safeCount(db, "reviews", reviewNeedsActionFilter, "reviews"),
    safeCount(db, "community_posts", boardNeedsActionFilter, "boards"),
    countAdminOperationTaskCounts(db),
    countAdminOperationGroupCounts(db),
  ]);

  const operationGroupCounts = withPackageOperationGroupCounts(
    baseOperationGroupCounts,
    operationTaskCounts.packagePaymentCheck,
  );
  const counts = toAdminNavigationAttentionCounts({
    operationGroupCounts,
    operationTaskCounts,
    reviews,
    boards,
  });

  return {
    counts,
    operationTaskCounts,
    operationGroupCounts,
    operationSignalCounts: toOperationSignalCounts(operationTaskCounts),
  };
}
