import { compactId, maskPhone, truthyField } from "@/lib/admin-alerts/formatters";
import { sendAdminOperationalAlert } from "@/lib/admin-alerts/sendAdminOperationalAlert";
import {
  AUTH_RATE_LIMIT_POLICIES,
  enforcePublicAuthRateLimit,
  getClientIp,
  normalizeRateLimitIdentifier,
} from "@/lib/auth/publicAuthRateLimit";
import { autoLinkStringingByEmail } from "@/lib/claims";
import {
  ACCESS_TOKEN_EXPIRES_IN,
  ACCESS_TOKEN_SECRET,
  REFRESH_TOKEN_EXPIRES_IN,
  REFRESH_TOKEN_SECRET,
} from "@/lib/constants";
import { baseCookie } from "@/lib/cookieOptions";
import { getDb } from "@/lib/mongodb";
import { isSignupBonusActive, SIGNUP_BONUS_POINTS, signupBonusRefKey } from "@/lib/points.policy";
import { grantPoints } from "@/lib/points.service";
import { getReservedDisplayNameErrorMessage } from "@/lib/reserved-display-name";
import { getReservedEmailLocalPartErrorMessage } from "@/lib/reserved-email-localpart";
import { getRegistrationPolicy } from "@/lib/registration-policy";
import jwt from "jsonwebtoken";
import { Collection } from "mongodb";
import { NextRequest, NextResponse } from "next/server";

type PendingDoc = {
  _id: string; // token
  provider: "kakao" | "naver";
  oauthId: string | null;
  email: string;
  name: string;
  from: string | null;
  createdAt: Date;
  expiresAt: Date;
};

type Body = {
  token: string;
  name?: string;
  phone?: string;
  postalCode?: string;
  address?: string;
  addressDetail?: string;
};

export async function POST(req: NextRequest) {
  const db = await getDb();

  const ipRateLimited = await enforcePublicAuthRateLimit({
    db,
    routeId: "oauth_complete",
    scope: "ip",
    value: getClientIp(req),
    policy: AUTH_RATE_LIMIT_POLICIES.oauth_complete.ip,
  });
  if (ipRateLimited) return ipRateLimited;

  const body = (await req.json().catch(() => null)) as Body | null;
  if (!body?.token) {
    return NextResponse.json({ error: "token is required" }, { status: 400 });
  }
  const oauthCompleteIdentifierPolicy = AUTH_RATE_LIMIT_POLICIES.oauth_complete.identifier;
  if (!oauthCompleteIdentifierPolicy) {
    return NextResponse.json({ error: "server error" }, { status: 500 });
  }

  const tokenRateLimited = await enforcePublicAuthRateLimit({
    db,
    routeId: "oauth_complete",
    scope: "token",
    value: normalizeRateLimitIdentifier("token", body.token),
    policy: oauthCompleteIdentifierPolicy,
  });
  if (tokenRateLimited) return tokenRateLimited;

  const pendings = db.collection("oauth_pending_signups") as Collection<PendingDoc>;
  const pending = await pendings.findOne({ _id: body.token });

  if (!pending) {
    return NextResponse.json(
      { error: "pending signup not found (expired or invalid)" },
      { status: 404 },
    );
  }

  //  TTL 삭제 타이밍(지연)을 믿지 말고, 서버에서 만료도 직접 차단
  const now = new Date();
  if (pending.expiresAt && pending.expiresAt <= now) {
    await pendings.deleteOne({ _id: pending._id }).catch(() => {});
    return NextResponse.json(
      { error: "pending signup not found (expired or invalid)" },
      { status: 404 },
    );
  }

  //  이메일 정규화 (기존 register/login 정책과 정합)
  const pendingEmailRaw = String(pending.email ?? "").trim();
  const pendingEmail = pendingEmailRaw.toLowerCase();
  if (!pendingEmail) {
    await pendings.deleteOne({ _id: pending._id }).catch(() => {});
    return NextResponse.json({ error: "pending signup invalid (missing email)" }, { status: 400 });
  }

  const reservedEmailError = getReservedEmailLocalPartErrorMessage(pendingEmail);
  if (reservedEmailError) {
    await pendings.deleteOne({ _id: pending._id }).catch(() => {});
    return NextResponse.json(
      { error: reservedEmailError, code: "RESERVED_EMAIL_LOCALPART" },
      { status: 400 },
    );
  }

  //  사용자가 입력한 이름을 우선(없으면 pending.name fallback)
  const incomingName = typeof body.name === "string" ? body.name.trim() : "";
  const fallbackName = String(pending.name ?? "").trim() || pendingEmail.split("@")[0];
  const finalSignupName = incomingName || fallbackName;

  const users = db.collection("users");
  const providerLabel = pending.provider === "naver" ? "네이버" : "카카오";

  // 1) 같은 이메일 유저가 이미 있으면 "연동 + 로그인"으로 처리
  // 케이스 차이로 인한 매칭 실패 방지: raw/lower 둘 다 조회
  let isNewUser = false;
  let user = await users.findOne({
    $or: [{ email: pendingEmail }, { email: pendingEmailRaw }],
  });

  if (user) {
    const providerKey = pending.provider; // 'kakao' | 'naver'
    const existingOauthId = (user as any)?.oauth?.[providerKey]?.id ?? null;

    if (existingOauthId && pending.oauthId && String(existingOauthId) !== String(pending.oauthId)) {
      return NextResponse.json(
        { error: `이미 다른 ${providerLabel} 계정에 연결된 이메일입니다.` },
        { status: 409 },
      );
    }

    const shouldUpdateName = !!incomingName && (!user?.name || String(user.name).trim() === "");
    if (shouldUpdateName) {
      const reservedNameError = getReservedDisplayNameErrorMessage(incomingName);
      if (reservedNameError) {
        return NextResponse.json(
          { error: reservedNameError, code: "RESERVED_DISPLAY_NAME" },
          { status: 400 },
        );
      }
    }

    await users.updateOne(
      { _id: user._id },
      {
        $set: {
          // 기존에 대문자/혼합 케이스로 저장된 이메일을 정규화(가능한 범위에서 정합 유지)
          email: pendingEmail,
          ...(shouldUpdateName ? { name: incomingName } : {}),
          updatedAt: now,
          lastLoginAt: now,
          [`oauth.${providerKey}.id`]: pending.oauthId,
          [`oauth.${providerKey}.connectedAt`]: now,
        },
      },
    );
    user = await users.findOne({ _id: user._id });
  } else {
    // 2) 신규 생성
    const registrationPolicy = await getRegistrationPolicy(db);
    if (!registrationPolicy.allowRegistration) {
      return NextResponse.json(
        {
          code: "REGISTRATION_DISABLED",
          message: "현재 신규 회원가입이 일시 중단되었습니다.",
        },
        { status: 403 },
      );
    }

    isNewUser = true;
    const reservedNameError = getReservedDisplayNameErrorMessage(finalSignupName);
    if (reservedNameError) {
      return NextResponse.json(
        { error: reservedNameError, code: "RESERVED_DISPLAY_NAME" },
        { status: 400 },
      );
    }

    const insertRes = await users.insertOne({
      email: pendingEmail,
      name: finalSignupName,
      role: "user",
      isDeleted: false,
      isSuspended: false,
      pointsBalance: 0,
      pointsDebt: 0,
      phone: body.phone || "",
      postalCode: body.postalCode || "",
      address: body.address || "",
      addressDetail: body.addressDetail || "",
      createdAt: now,
      updatedAt: now,
      lastLoginAt: now,
      oauth: {
        [pending.provider]: {
          id: pending.oauthId,
          connectedAt: now,
        },
      },
    });

    user = await users.findOne({ _id: insertRes.insertedId });
  }
  if (!user) {
    return NextResponse.json({ error: "user create/link failed" }, { status: 500 });
  }

  if (user.isDeleted) return NextResponse.json({ error: "deleted user" }, { status: 403 });
  if (user.isSuspended) return NextResponse.json({ error: "suspended user" }, { status: 403 });

  // (이벤트) 회원가입 보너스 지급: "신규 생성"일 때만
  // - 중복 호출/리트라이가 있어도 refKey(unique)로 멱등 보장
  // - 지급 실패가 회원가입/로그인을 막지 않도록 try/catch로 격리
  let signupBonusAlertText = "기존 회원";

  if (isNewUser) {
    const signupBonusActive = isSignupBonusActive();
    signupBonusAlertText = signupBonusActive
      ? `지급 예정 ${SIGNUP_BONUS_POINTS.toLocaleString("ko-KR")}P`
      : "비활성";

    try {
      if (signupBonusActive) {
        await grantPoints(db, {
          userId: user._id,
          amount: SIGNUP_BONUS_POINTS,
          type: "signup_bonus",
          refKey: signupBonusRefKey(user._id),
          reason: `회원가입 보너스 ${SIGNUP_BONUS_POINTS}P`,
        });

        signupBonusAlertText = `지급됨 ${SIGNUP_BONUS_POINTS.toLocaleString("ko-KR")}P`;
      }
    } catch (e) {
      signupBonusAlertText = `지급 실패 ${SIGNUP_BONUS_POINTS.toLocaleString("ko-KR")}P`;
      console.warn("[oauth complete] signup bonus grant failed:", e);
    }
  }

  if (isNewUser) {
    await sendAdminOperationalAlert({
      kind: "user_registered",
      title: "👤 신규 회원가입",
      summary: "신규 소셜 회원이 가입했습니다. 관리자 회원 상세에서 확인해 주세요.",
      href: `/admin/users/${String(user._id)}`,
      dedupeKey: `user_registered:${pending.provider}:${String(user._id)}`,
      fields: [
        { name: "회원번호", value: compactId(user._id) },
        { name: "가입 경로", value: `${providerLabel} 소셜 회원가입` },
        { name: "이름", value: String(user.name ?? finalSignupName) },
        { name: "이메일", value: String(user.email ?? pendingEmail) },
        truthyField("연락처", maskPhone(user.phone || body.phone)),
        truthyField("우편번호", user.postalCode || body.postalCode),
        { name: "가입 보너스", value: signupBonusAlertText },
      ].filter(Boolean) as Array<{ name: string; value: string }>,
    });
  }

  // 3) 로그인 쿠키 발급
  const accessToken = jwt.sign(
    { sub: user._id.toString(), email: user.email, role: user.role },
    ACCESS_TOKEN_SECRET,
    { expiresIn: ACCESS_TOKEN_EXPIRES_IN },
  );
  const refreshToken = jwt.sign({ sub: user._id.toString() }, REFRESH_TOKEN_SECRET, {
    expiresIn: REFRESH_TOKEN_EXPIRES_IN,
  });

  // 4) 부가 처리(세션로그/자동연결)
  try {
    const ip =
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      req.headers.get("x-real-ip") ||
      "";
    const ua = req.headers.get("user-agent") || "";

    await db.collection("user_sessions").insertOne({
      userId: user._id,
      at: now,
      ip,
      ua,
    });

    await Promise.all([
      autoLinkStringingByEmail(db, user._id, String(user.email ?? pendingEmail).toLowerCase()),
      users.updateOne({ _id: user._id }, { $set: { lastLoginAt: now } }),
    ]);
  } catch (e) {
    console.warn("[oauth complete] post-login side effects fail:", e);
  }

  // 5) pending 제거
  await pendings.deleteOne({ _id: pending._id });

  const redirectTo = pending.from === "cart" ? "/cart" : "/";
  const res = NextResponse.json({ ok: true, redirectTo });

  res.cookies.set("accessToken", accessToken, {
    ...baseCookie,
    maxAge: ACCESS_TOKEN_EXPIRES_IN,
  });
  res.cookies.set("refreshToken", refreshToken, {
    ...baseCookie,
    maxAge: REFRESH_TOKEN_EXPIRES_IN,
  });
  res.cookies.delete("force_pwd_change");

  return res;
}
