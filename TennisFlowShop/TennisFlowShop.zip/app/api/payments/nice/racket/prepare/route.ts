import { racketVisibilityFilterFor } from "@/lib/public-visibility";
import { getVisibilityViewerFromCookies } from "@/lib/public-visibility-viewer";
import { verifyAccessToken } from "@/lib/auth.utils";
import clientPromise from "@/lib/mongodb";
import { buildNiceOrderName, createNiceOrderId } from "@/lib/payments/nice/server";
import { isNicePaymentsEnabled } from "@/lib/payments/provider-flags";
import { ensureTossPaymentSessionIndexes, tossPaymentSessions } from "@/lib/payments/toss/session";
import { normalizeItemShippingFee } from "@/lib/shipping-fee";
import { getBaseUrl } from "@/lib/getBaseUrl";
import { ObjectId } from "mongodb";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import {
  ENABLE_RACKET_STANDALONE_ORDER,
  RACKET_STANDALONE_ORDER_DISABLED_RESPONSE,
} from "@/lib/orders/racket-standalone-policy";

const POSTAL_RE = /^\d{5}$/;
const onlyDigits = (v: unknown) => String(v ?? "").replace(/\D/g, "");

function resolveClientId() {
  return String(process.env.NICEPAY_CLIENT_KEY ?? process.env.NICEPAY_CLIENT_ID ?? "").trim();
}

function resolveAppUrl() {
  return String(getBaseUrl()).trim().replace(/\/+$/, "");
}

export const runtime = "nodejs";
export const preferredRegion = ["icn1", "hnd1"];

export async function POST(req: Request) {
  if (!ENABLE_RACKET_STANDALONE_ORDER) {
    return NextResponse.json(RACKET_STANDALONE_ORDER_DISABLED_RESPONSE, {
      status: 410,
    });
  }
  try {
    if (!isNicePaymentsEnabled()) {
      return NextResponse.json(
        {
          success: false,
          code: "PAYMENT_PROVIDER_DISABLED",
          message: "현재 해당 결제수단은 사용할 수 없습니다.",
        },
        { status: 503 },
      );
    }

    const clientId = resolveClientId();
    if (!clientId) {
      return NextResponse.json(
        {
          success: false,
          code: "NICE_CONFIG_MISSING",
          error: "카드/간편결제 설정이 누락되었습니다.",
        },
        { status: 500 },
      );
    }

    const body = await req.json().catch(() => ({}));
    const racketId = String(body?.racketId ?? "").trim();

    const shippingInfo = body?.shippingInfo ?? {};
    const shippingMethod = shippingInfo?.shippingMethod === "visit" ? "visit" : "courier";
    const name = String(shippingInfo?.name ?? "").trim();
    const phone = onlyDigits(shippingInfo?.phone ?? "");
    const address = String(shippingInfo?.address ?? "").trim();
    const addressDetail = String(shippingInfo?.addressDetail ?? "").trim();
    const postalCode = onlyDigits(shippingInfo?.postalCode ?? "").trim();
    const deliveryRequest = String(shippingInfo?.deliveryRequest ?? "").trim();

    if (!ObjectId.isValid(racketId) || name.length < 2 || !/^010\d{8}$/.test(phone)) {
      return NextResponse.json(
        { success: false, error: "요청 데이터가 올바르지 않습니다." },
        { status: 400 },
      );
    }

    if (!["visit", "courier"].includes(shippingMethod)) {
      return NextResponse.json(
        { success: false, error: "배송 방식이 올바르지 않습니다." },
        { status: 400 },
      );
    }

    if (shippingMethod === "courier" && (!POSTAL_RE.test(postalCode) || !address)) {
      return NextResponse.json(
        { success: false, error: "배송지 정보를 확인해주세요." },
        { status: 400 },
      );
    }

    const cookieStore = await cookies();
    const token = cookieStore.get("accessToken")?.value;
    let payload: { sub?: string } | null = null;
    if (token) {
      try {
        payload = verifyAccessToken(token);
      } catch {
        payload = null;
      }
    }
    const userId = payload?.sub ?? null;

    const client = await clientPromise;
    const db = client.db();
    const viewer = await getVisibilityViewerFromCookies();
    const racket = await db.collection("used_rackets").findOne({
      _id: new ObjectId(racketId),
      ...racketVisibilityFilterFor(viewer),
    });

    if (!racket || racket.status !== "available") {
      return NextResponse.json(
        { success: false, error: "구매 가능한 라켓이 아닙니다." },
        { status: 400 },
      );
    }

    const racketPrice = Number(racket.price ?? 0);
    if (!Number.isFinite(racketPrice) || racketPrice <= 0) {
      return NextResponse.json(
        { success: false, error: "라켓 가격 정보가 올바르지 않습니다." },
        { status: 400 },
      );
    }

    const shippingFee =
      shippingMethod === "visit"
        ? 0
        : normalizeItemShippingFee((racket as { shippingFee?: unknown }).shippingFee);
    const totalPrice = racketPrice + shippingFee;
    if (!Number.isFinite(totalPrice) || totalPrice <= 0) {
      return NextResponse.json(
        { success: false, error: "최종 결제금액이 올바르지 않습니다." },
        { status: 400 },
      );
    }

    const niceOrderId = createNiceOrderId();
    const goodsName = buildNiceOrderName([
      {
        name: `${String(racket.brand ?? "")}${racket.model ? ` ${String(racket.model)}` : ""}`.trim(),
        quantity: 1,
      },
    ]);
    const returnUrl = `${resolveAppUrl()}/api/payments/nice/racket/return`;
    const now = new Date();

    await ensureTossPaymentSessionIndexes(db);
    await tossPaymentSessions(db).insertOne({
      provider: "nicepay",
      niceOrderId,
      amount: totalPrice,
      status: "ready",
      flowType: "racket_order",
      racketPayload: {
        racketId,
        items: [{ productId: racketId, quantity: 1, kind: "racket" }],
        shippingInfo: {
          name,
          phone,
          address,
          addressDetail,
          postalCode,
          depositor: name,
          deliveryRequest,
          shippingMethod,
        },
        servicePickupMethod: shippingMethod,
        shippingFee,
        totalPrice,
        paymentInfo: {},
        guestInfo: body?.guestInfo ?? null,
      },
      userId,
      guestInfo: body?.guestInfo ?? null,
      nicePrepared: {
        clientId,
        orderId: niceOrderId,
        returnUrl,
        goodsName,
        buyerName: name,
        buyerTel: phone,
        buyerEmail: String(body?.guestInfo?.email ?? "").trim(),
      },
      createdAt: now,
      updatedAt: now,
      expiresAt: new Date(now.getTime() + 1000 * 60 * 30),
    });

    return NextResponse.json({
      success: true,
      nice: {
        clientId,
        orderId: niceOrderId,
        amount: totalPrice,
        goodsName,
        returnUrl,
        buyerName: name,
        buyerTel: phone,
        buyerEmail: String(body?.guestInfo?.email ?? "").trim(),
      },
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error?.message || "라켓 카드/간편결제 준비 중 오류가 발생했습니다.",
      },
      { status: 500 },
    );
  }
}
