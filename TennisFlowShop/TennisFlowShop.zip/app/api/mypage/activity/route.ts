import { normalizeCollection } from "@/app/features/stringing-applications/lib/collection";
import { verifyAccessToken } from "@/lib/auth.utils";
import clientPromise from "@/lib/mongodb";
import {
  hasRentalReturnShipping,
  isRentalReturnShippingRegistrationRequired,
  resolveApplicationTodoReason,
  resolveOrderTodoReason,
  resolveRentalTodoReason,
  type MypageTodoReasonCode,
} from "@/lib/mypage/activity-todo";
import { toKstYmd } from "@/lib/date/kst";
import { isOrderConfirmedStatus } from "@/lib/status/flow-status";
import { isApplicationEligibleForLinkedStage } from "@/lib/admin/linked-flow-stage";
import { getCustomerTransactionPaymentStatusLabel } from "@/app/mypage/_lib/flow-display";
import {
  resolveApplicationReviewTargetBundlesBatch,
  resolveOrderReviewTargetBundlesBatch,
  resolveRentalReviewTargetBundlesBatch,
} from "@/lib/reviews/review-target.server";
import jwt from "jsonwebtoken";
import { ObjectId } from "mongodb";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

// 숫자 쿼리 파라미터 안전 파싱 (NaN/Infinity/음수 방지 + 범위 보정)
function parseIntParam(v: string | null, opts: { defaultValue: number; min: number; max: number }) {
  const n = Number(v);
  const base = Number.isFinite(n) ? n : opts.defaultValue;
  return Math.min(opts.max, Math.max(opts.min, Math.trunc(base)));
}

type ActivityKind = "order" | "rental" | "application";
type ActivityScope = "all" | "todo" | "order" | "application" | "rental";

function parseScopeParam(v: string | null): ActivityScope {
  if (v === "todo" || v === "order" || v === "application" || v === "rental") return v;
  return "all";
}

function nullableTrim(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function toNullableFiniteNumber(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function resolveRawPaymentStatus(doc: any): string | null {
  return nullableTrim(doc?.paymentStatus) ?? nullableTrim(doc?.paymentInfo?.status);
}

function resolvePaymentMethod(doc: any): string | null {
  return nullableTrim(doc?.paymentInfo?.method) ?? nullableTrim(doc?.paymentMethod);
}

function resolvePaymentProvider(doc: any): string | null {
  return nullableTrim(doc?.paymentInfo?.provider) ?? nullableTrim(doc?.paymentProvider);
}

function resolveStringingPaymentContext(
  appDoc: any,
  linkedPayment?: {
    paymentStatus?: string | null;
    paymentProvider?: string | null;
  } | null,
) {
  const packageApplied = Boolean(appDoc?.packageApplied || appDoc?.packageInfo?.applied);
  if (packageApplied) {
    return {
      packageApplied,
      paymentStatus: "패키지 적용 완료",
      paymentProvider: null as string | null,
    };
  }

  return {
    packageApplied,
    paymentStatus:
      linkedPayment?.paymentStatus ??
      (appDoc?.paymentStatus || appDoc?.paymentInfo?.status
        ? resolveRawPaymentStatus(appDoc)
        : null),
    paymentProvider: linkedPayment?.paymentProvider ?? resolvePaymentProvider(appDoc),
  };
}

type ActivityOrderSummary = {
  id: string;
  createdAt: string;
  updatedAt: string;
  status: string;
  userConfirmedAt: string | null;
  paymentStatus: string | null;
  paymentStatusLabel: string;
  paymentProvider?: string | null;
  paymentMethod?: string | null;
  shippingMethod: string;
  totalPrice: number | null;
  firstItemName: string;
  firstItemImageUrl?: string | null;
  itemsCount: number;
  withStringService: boolean;
  stringingApplicationIds: string[];
  applicationSummaries: ActivityApplicationSummary[];
  applicationHistorySummaries: ActivityApplicationSummary[];
  stringingApplicationId: string | null;
  cancelStatus?: string | null;
  cancelReasonSummary?: string | null;
  hasRacketItem: boolean;
  hasStringItem: boolean;
  hasProductItem: boolean;
  linkedApplicationCount: number;
  hasActiveStringingApplication: boolean;
  reviewPendingCount: number;
  hasPendingReview: boolean;
  reviewAllDone: boolean;
  reviewNextTargetProductId: string | null;
  reviewNextApplicationId: string | null;
  reviewContext: string | null;
  reviewTargetBundle?: unknown;
  nextReviewTarget?: unknown;
};

type ActivityRentalSummary = {
  id: string;
  createdAt: string;
  updatedAt: string;
  status: string;
  userConfirmedAt?: string | null;
  shippingMethod?: string;
  brand?: string;
  model?: string;
  racketId?: string | null;
  imageUrl?: string | null;
  days?: number;
  totalAmount?: number;
  paymentStatus?: string | null;
  paymentStatusLabel?: string;
  paymentProvider?: string | null;
  paymentMethod?: string | null;
  deposit?: number;
  fee?: number;
  withStringService: boolean;
  hasOutboundShipping: boolean;
  outboundTrackingNumber: string | null;
  dueAt: string | null;
  returnedAt: string | null;
  hasReturnShipping: boolean;
  returnShippingWindowOpen: boolean;
  stringingApplicationIds: string[];
  applicationSummaries: ActivityApplicationSummary[];
  applicationHistorySummaries: ActivityApplicationSummary[];
  stringingApplicationId: string | null;
  cancelStatus?: string | null;
  linkedApplicationCount: number;
  reviewContext?: string | null;
  reviewPendingCount?: number;
  reviewAllDone?: boolean;
  reviewNextTargetProductId?: string | null;
  reviewNextApplicationId?: string | null;
  reviewNextRacketId?: string | null;
  reviewTargetBundle?: unknown;
  nextReviewTarget?: unknown;
};

type FlowType =
  | "order_only"
  | "order_plus_stringing"
  | "rental_only"
  | "rental_plus_stringing"
  | "application_only";

type DetailTarget = {
  type: "order" | "application" | "rental";
  id: string;
};

type ActivityApplicationSummary = {
  id: string;
  createdAt: string; // appliedAt/createdAt 기준
  updatedAt: string;
  status: string;
  racketType: string;
  orderId: string | null;
  rentalId: string | null;
  hasTracking: boolean;
  userConfirmedAt: string | null;
  cancelStatus?: string | null;
  cancelReasonSummary?: string | null;
  inboundRequired: boolean; // 고객→매장 입고가 필요한가?
  needsInboundTracking: boolean; // 입고가 필요하고 + 자가발송(self_ship)이라 운송장 입력이 필요한가?
  collectionMethod: string;
  packageApplied?: boolean;
  paymentStatus?: string | null;
  paymentProvider?: string | null;
  serviceReviewPending?: boolean;
  selectedStringName?: string | null;
  selectedGauge?: string | null;
  selectedColorLabel?: string | null;
  reviewContext?: string | null;
  reviewPendingCount?: number;
  reviewAllDone?: boolean;
  reviewNextTargetProductId?: string | null;
  reviewNextApplicationId?: string | null;
  reviewTargetBundle?: unknown;
  nextReviewTarget?: unknown;
};

export type ActivityGroup = {
  key: string; // 예: "order:<id>", "rental:<id>", "application:<id>"
  kind: ActivityKind;
  sortAt: string; // 정렬 기준 시각(ISO)
  order?: ActivityOrderSummary;
  rental?: ActivityRentalSummary;
  application?: ActivityApplicationSummary;
  flowType: FlowType;
  flowLabel: string;
  detailTarget: DetailTarget;
  todoReasonCode: MypageTodoReasonCode | null;
};

function getOrderFlowLabel(opts: {
  hasRacketItem: boolean;
  hasStringItem: boolean;
  hasProductItem: boolean;
  linkedApplicationCount: number;
}): string {
  const { hasRacketItem, hasStringItem, hasProductItem, linkedApplicationCount } = opts;
  const hasLinked = linkedApplicationCount > 0;

  if (!hasLinked) {
    if (hasRacketItem && hasStringItem) return "라켓 + 스트링 주문";
    if (hasRacketItem) return hasProductItem ? "라켓 포함 주문" : "라켓 주문";
    if (hasStringItem) return "스트링 단품 주문";
    return "일반 상품 주문";
  }

  if (hasRacketItem && hasStringItem) return "라켓 구매 + 스트링 + 교체서비스";
  if (hasStringItem) return "스트링 구매 + 교체서비스";
  if (hasRacketItem) return "라켓 구매 + 교체서비스";
  return "상품 구매 + 교체서비스";
}

function firstText(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
    if (typeof value === "number" && Number.isFinite(value)) return String(value);
  }
  return null;
}

function firstImageUrl(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return null;
}

function pickOrderItemImage(item: any): string | null {
  if (!item) return null;

  const firstImageFromArray =
    Array.isArray(item.images) && typeof item.images[0] === "string" ? item.images[0] : null;

  return firstImageUrl(
    item.selectedColorImage,
    item.imageUrl,
    item.image,
    item.thumbnail,
    item.thumbnailUrl,
    firstImageFromArray,
  );
}

function pickUsedRacketImage(doc: any): string | null {
  if (!doc) return null;

  const firstImageFromArray =
    Array.isArray(doc.images) && typeof doc.images[0] === "string" ? doc.images[0] : null;

  return firstImageUrl(doc.image, doc.thumbnail, doc.thumbnailUrl, firstImageFromArray);
}

function getApplicationLines(stringDetails: any): any[] {
  if (Array.isArray(stringDetails?.lines)) return stringDetails.lines;
  if (Array.isArray(stringDetails?.racketLines)) return stringDetails.racketLines;
  return [];
}

function summarizeStringSelection(appDoc: any) {
  const details = appDoc?.stringDetails ?? {};
  const meta = appDoc?.meta ?? {};
  const lines = getApplicationLines(details);
  const firstLine = lines[0] ?? {};
  const stringName = firstText(
    firstLine?.stringName,
    details?.stringName,
    details?.selectedStringName,
    appDoc?.selectedStringName,
    meta?.selectedStringName,
    Array.isArray(appDoc?.stringNames) ? appDoc.stringNames[0] : appDoc?.stringNames,
    Array.isArray(appDoc?.applicationSummary?.stringNames)
      ? appDoc.applicationSummary.stringNames[0]
      : appDoc?.applicationSummary?.stringNames,
  );

  return {
    selectedStringName: stringName,
    selectedGauge: firstText(
      firstLine?.selectedGauge,
      firstLine?.gauge,
      details?.selectedGauge,
      appDoc?.selectedGauge,
      meta?.selectedGauge,
    ),
    selectedColorLabel: firstText(
      firstLine?.selectedColorLabel,
      firstLine?.colorLabel,
      details?.selectedColorLabel,
      details?.selectedColor,
      appDoc?.selectedColorLabel,
      meta?.selectedColorLabel,
      meta?.selectedColor,
    ),
  };
}

function toISO(v: any): string {
  // Date/string/number 모두 안전하게 ISO로 변환
  const d = v instanceof Date ? v : new Date(v);
  if (Number.isNaN(d.getTime())) return new Date(0).toISOString();
  return d.toISOString();
}

function isoMax(...values: Array<string | null | undefined>): string {
  const base = new Date(0).toISOString();
  return values
    .filter((v): v is string => Boolean(v))
    .reduce((acc, cur) => (cur > acc ? cur : acc), base);
}

function compareByUpdatedThenCreatedDesc(
  a: Pick<ActivityApplicationSummary, "updatedAt" | "createdAt">,
  b: Pick<ActivityApplicationSummary, "updatedAt" | "createdAt">,
) {
  return b.updatedAt.localeCompare(a.updatedAt) || b.createdAt.localeCompare(a.createdAt);
}

function isActionableInboundTracking(
  app?: Pick<ActivityApplicationSummary, "needsInboundTracking" | "hasTracking"> | null,
) {
  return Boolean(app?.needsInboundTracking && !app?.hasTracking);
}

function pickPrimaryLinkedApplication(apps: ActivityApplicationSummary[]) {
  // 정책:
  // 1) 사용자 액션(운송장 등록)이 필요한 신청서를 우선 대표로 노출
  // 2) 없으면 최신 업데이트 신청서를 대표로 사용
  return apps.find((app) => isActionableInboundTracking(app)) ?? apps[0];
}

function calcOrderTotal(o: any): number | null {
  // 기존 /api/users/me/orders 로직의 축약판(총액이 있으면 우선, 없으면 items 합산)
  for (const value of [o.totalPrice, o.total, o.finalAmount, o.totalAmount]) {
    const explicit = toNullableFiniteNumber(value);
    if (explicit !== null) return explicit;
  }

  const items: any[] = Array.isArray(o.items) ? o.items : [];
  if (items.length === 0) return null;
  let total = 0;
  for (const item of items) {
    const lineTotal = toNullableFiniteNumber(item?.total);
    if (lineTotal !== null) {
      total += lineTotal;
      continue;
    }

    const unitPrice = toNullableFiniteNumber(item?.price ?? item?.unitPrice);
    const quantity = toNullableFiniteNumber(item?.quantity ?? item?.qty ?? item?.count ?? 1);
    if (unitPrice === null || quantity === null) return null;
    total += unitPrice * quantity;
  }
  return total;
}

function resolveOrderShippingMethod(shippingInfo: any): string {
  if (!shippingInfo || typeof shippingInfo !== "object") return "";

  // 서버 저장 기준은 deliveryMethod(택배수령/방문수령)가 우선이다.
  // 레거시/혼합 저장 형태를 위해 shippingMethod/method/type 도 순차 fallback 한다.
  const candidates = [
    shippingInfo.deliveryMethod,
    shippingInfo.shippingMethod,
    shippingInfo.method,
    shippingInfo.type,
  ];

  for (const value of candidates) {
    const normalized = String(value ?? "").trim();
    if (normalized) return normalized;
  }

  return "";
}

function isOrderHasRacketItem(order: any): boolean {
  const items = Array.isArray(order?.items) ? order.items : [];
  return items.some((it: any) => it?.kind === "racket" || it?.kind === "used_racket");
}

function summarizeRacketType(details: any): string {
  // 신청서 목록(route.ts)처럼 “완벽”하게 만들기보다, 통합 피드용 최소 요약만
  if (details?.racketType && typeof details.racketType === "string" && details.racketType.trim()) {
    return details.racketType.trim();
  }
  const lines = Array.isArray(details?.racketLines) ? details.racketLines : [];
  if (lines.length > 0) return `라켓 ${lines.length}자루`;
  return "-";
}

// 신청서 배송정보
function getTrackingNoFromShippingInfo(shippingInfo: any): string | null {
  const v =
    shippingInfo?.selfShip?.trackingNo ??
    shippingInfo?.invoice?.trackingNumber ??
    shippingInfo?.trackingNumber ??
    shippingInfo?.trackingNo ??
    null;

  if (v == null) return null;
  const s = String(v).trim();
  return s.length > 0 ? s : null;
}

/**
 * 통합 활동 API
 * - orders + rental_orders + (standalone) stringing_applications 를 한 리스트로 합친다.
 * - 단, orderId/rentalId가 있는 신청서는 “별도 항목”으로 만들지 않고,
 *   해당 주문/대여 그룹에 붙여서 1건의 활동으로 보여준다.
 */
export async function GET(req: Request) {
  // 1) 인증
  // - accessToken이 유효하면 그대로 통과
  // - accessToken 만료/누락 시에도 refreshToken으로 "1회 회복 기회"를 준다.
  //   (즉시 401을 반환하면 로그인 상태 사용자도 타이밍 이슈로 간헐 Unauthorized를 겪을 수 있음)
  const jar = await cookies();
  const at = jar.get("accessToken")?.value;
  const rt = jar.get("refreshToken")?.value;

  let payload: jwt.JwtPayload | null = at ? (verifyAccessToken(at) as jwt.JwtPayload | null) : null;
  let recoveredByRefresh = false;

  if (!payload?.sub && rt) {
    try {
      payload = jwt.verify(rt, process.env.REFRESH_TOKEN_SECRET!) as jwt.JwtPayload;
      recoveredByRefresh = Boolean(payload?.sub);
    } catch {
      payload = null;
    }
  }

  if (!payload?.sub) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const subStr = String(payload.sub);
  if (!ObjectId.isValid(subStr)) {
    return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
  }
  const userId = new ObjectId(subStr);

  // 2) 페이지네이션 파라미터
  const url = new URL(req.url);
  const page = parseIntParam(url.searchParams.get("page"), {
    defaultValue: 1,
    min: 1,
    max: 10_000,
  });
  const pageSize = parseIntParam(url.searchParams.get("pageSize"), {
    defaultValue: 10,
    min: 1,
    max: 50,
  });
  const scope = parseScopeParam(url.searchParams.get("scope"));
  const skip = (page - 1) * pageSize;

  // 병합형 페이지네이션의 현실적인 구현:
  // - 각 컬렉션에서 (page*pageSize + buffer) 만큼만 먼저 가져온 뒤,
  // - 합쳐서 정렬하고 slice 하는 방식(유저 데이터가 무한정 크지 않다는 전제에서 v1로 충분)
  const take = page * pageSize + pageSize; // buffer = pageSize

  const db = (await clientPromise).db();
  if (recoveredByRefresh) {
    // refresh 기반 회복으로 진입했을 때만 사용자 상태를 1회 검증한다.
    // 이렇게 해야 "만료 직후 즉시 401" 문제를 줄이면서도 탈퇴/정지 계정을 우회하지 않는다.
    const authUser = await db
      .collection("users")
      .findOne({ _id: userId }, { projection: { _id: 1, isDeleted: 1, isSuspended: 1 } });
    if (!authUser || authUser.isDeleted) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    }
    if (authUser.isSuspended) {
      return NextResponse.json({ message: "Forbidden" }, { status: 403 });
    }
  }

  const standaloneAppsFilter = {
    userId,
    status: { $ne: "draft" },
    $and: [
      { $or: [{ orderId: { $exists: false } }, { orderId: null }] },
      { $or: [{ rentalId: { $exists: false } }, { rentalId: null }] },
    ],
  };

  // 4) 후보 데이터 로드
  const [orders, rentals, standaloneApps] = await Promise.all([
    db
      .collection("orders")
      .find(
        { userId },
        {
          projection: {
            _id: 1,
            createdAt: 1,
            updatedAt: 1,
            status: 1,
            userConfirmedAt: 1,
            paymentStatus: 1,
            paymentInfo: 1,
            totalPrice: 1,
            total: 1,
            items: 1,
            shippingInfo: 1,
            stringingApplicationId: 1,
            cancelRequest: 1,
          },
        },
      )
      .sort({ updatedAt: -1, createdAt: -1 })
      .limit(take)
      .toArray(),

    db
      .collection("rental_orders")
      .find(
        { userId },
        {
          projection: {
            _id: 1,
            createdAt: 1,
            updatedAt: 1,
            status: 1,
            userConfirmedAt: 1,
            dueAt: 1,
            returnedAt: 1,
            racketId: 1,
            brand: 1,
            model: 1,
            days: 1,
            amount: 1,
            stringingApplicationId: 1,
            stringing: 1,
            shipping: 1,
            paymentStatus: 1,
            paymentInfo: 1,
            paymentProvider: 1,
            paymentMethod: 1,
            cancelRequest: 1,
          },
        },
      )
      .sort({ updatedAt: -1, createdAt: -1 })
      .limit(take)
      .toArray(),

    db
      .collection("stringing_applications")
      .find(standaloneAppsFilter, {
        projection: {
          _id: 1,
          createdAt: 1,
          updatedAt: 1,
          appliedAt: 1,
          status: 1,
          stringDetails: 1,
          shippingInfo: 1,
          orderId: 1,
          rentalId: 1,
          userConfirmedAt: 1,
          cancelRequest: 1,
          packageApplied: 1,
          packageInfo: 1,
          paymentStatus: 1,
          paymentInfo: 1,
          paymentProvider: 1,
          paymentMethod: 1,
          meta: 1,
          stringNames: 1,
          applicationSummary: 1,
          selectedStringName: 1,
          selectedGauge: 1,
          selectedColorLabel: 1,
        },
      })
      .sort({ updatedAt: -1, createdAt: -1 })
      .limit(take)
      .toArray(),
  ]);

  /**
   * order 기반 신청서의 "라켓 포함 여부"를 미리 계산
   * - order.items[].kind === 'racket' | 'used_racket' 이면: 매장 라켓(구매/중고) 기반 → 고객 입고/운송장 불필요
   * - (Activity API는 take만큼만 로드하므로, 여기서는 로드된 orders 범위에서만 판단하면 충분)
   */
  const orderHasRacketById = new Map<string, boolean>();
  for (const order of orders as any[]) {
    orderHasRacketById.set(String(order._id), isOrderHasRacketItem(order));
  }

  const orderIdsAny = orders.flatMap((o: any) => [o._id, String(o._id)]);
  const rentalIdsAny = rentals.flatMap((r: any) => [r._id, String(r._id)]);

  const linkedApps = await db
    .collection("stringing_applications")
    .find(
      {
        userId,
        status: { $ne: "draft" },
        $or: [{ orderId: { $in: orderIdsAny } }, { rentalId: { $in: rentalIdsAny } }],
      },
      {
        projection: {
          _id: 1,
          createdAt: 1,
          updatedAt: 1,
          appliedAt: 1,
          status: 1,
          stringDetails: 1,
          shippingInfo: 1,
          orderId: 1,
          rentalId: 1,
          userConfirmedAt: 1,
          cancelRequest: 1,
          packageApplied: 1,
          packageInfo: 1,
          paymentStatus: 1,
          paymentInfo: 1,
          paymentProvider: 1,
          paymentMethod: 1,
          meta: 1,
          stringNames: 1,
          applicationSummary: 1,
          selectedStringName: 1,
          selectedGauge: 1,
          selectedColorLabel: 1,
        },
      },
    )
    .toArray();

  // orderId/rentalId → applicationSummary 매핑
  const appByOrderId = new Map<string, ActivityApplicationSummary[]>();
  const appByRentalId = new Map<string, ActivityApplicationSummary[]>();
  const orderPaymentContextById = new Map(
    (orders as any[]).map((order) => [
      String(order._id),
      {
        paymentStatus: resolveRawPaymentStatus(order),
        paymentProvider: resolvePaymentProvider(order),
      },
    ]),
  );
  const rentalPaymentContextById = new Map(
    (rentals as any[]).map((rental) => [
      String(rental._id),
      {
        paymentStatus: resolveRawPaymentStatus(rental),
        paymentProvider: resolvePaymentProvider(rental),
      },
    ]),
  );

  for (const doc of linkedApps as any[]) {
    const details = doc.stringDetails ?? {};
    const shipping = doc.shippingInfo ?? {};
    const hasTracking = Boolean(getTrackingNoFromShippingInfo(shipping));

    // 수거 방식(visit/self_ship) 정규화
    const collectionMethod = normalizeCollection(
      (shipping as any)?.collectionMethod ?? (doc as any)?.collectionMethod ?? "self_ship",
    );

    // 입고 필요 여부 판단
    // - rentalId 연결: 매장 라켓 기반 → 고객 입고 불필요
    // - orderId 연결 + 해당 주문에 racket 포함: 매장 라켓(구매) 기반 → 고객 입고 불필요
    // - 그 외(주문에 라켓 없음 / 스트링만 구매+서비스 등): 고객 라켓 기반 → 입고 필요
    const orderIdStr = doc.orderId ? String(doc.orderId) : null;
    const inboundRequired = doc.rentalId
      ? false
      : orderIdStr && orderHasRacketById.get(orderIdStr)
        ? false
        : true;
    const needsInboundTracking = inboundRequired && collectionMethod === "self_ship";

    const rawCancelStatus = doc?.cancelRequest?.status ?? null;
    let cancelReasonSummary: string | null = null;
    const reasonCode = doc?.cancelRequest?.reasonCode;
    const reasonText = doc?.cancelRequest?.reasonText;
    if (reasonCode) cancelReasonSummary = reasonCode + (reasonText ? ` (${reasonText})` : "");
    else if (reasonText) cancelReasonSummary = reasonText;

    const createdAt = toISO(doc.appliedAt ?? doc.createdAt);
    const updatedAt = toISO(doc.updatedAt ?? doc.appliedAt ?? doc.createdAt);
    const linkedPaymentContext = orderIdStr
      ? orderPaymentContextById.get(orderIdStr)
      : doc.rentalId
        ? rentalPaymentContextById.get(String(doc.rentalId))
        : undefined;
    const paymentContext = resolveStringingPaymentContext(doc, linkedPaymentContext);

    const stringSelection = summarizeStringSelection(doc);

    const app: ActivityApplicationSummary = {
      id: String(doc._id),
      createdAt,
      updatedAt,
      status: doc.status ?? "접수",
      racketType: summarizeRacketType(details),
      orderId: doc.orderId ? String(doc.orderId) : null,
      rentalId: doc.rentalId ? String(doc.rentalId) : null,
      hasTracking,
      userConfirmedAt:
        doc.userConfirmedAt instanceof Date
          ? doc.userConfirmedAt.toISOString()
          : typeof doc.userConfirmedAt === "string"
            ? doc.userConfirmedAt
            : null,
      cancelStatus: rawCancelStatus,
      cancelReasonSummary,
      inboundRequired,
      needsInboundTracking,
      collectionMethod,
      packageApplied: paymentContext.packageApplied,
      paymentStatus: paymentContext.paymentStatus,
      paymentProvider: paymentContext.paymentProvider,
      ...stringSelection,
    };

    if (doc.orderId) {
      const key = String(doc.orderId);
      const bucket = appByOrderId.get(key) ?? [];
      bucket.push(app);
      appByOrderId.set(key, bucket);
    }
    if (doc.rentalId) {
      const key = String(doc.rentalId);
      const bucket = appByRentalId.get(key) ?? [];
      bucket.push(app);
      appByRentalId.set(key, bucket);
    }
  }

  for (const [, apps] of appByOrderId) {
    apps.sort(compareByUpdatedThenCreatedDesc);
  }
  for (const [, apps] of appByRentalId) {
    apps.sort(compareByUpdatedThenCreatedDesc);
  }

  const activeApplications = (apps: ActivityApplicationSummary[]) =>
    apps.filter((app) =>
      isApplicationEligibleForLinkedStage({
        status: app.status,
        cancelRequestStatus: app.cancelStatus,
      }),
    );

  const rentalRacketObjectIds = Array.from(
    new Set(
      (rentals as any[]).map((r) => String(r?.racketId ?? "")).filter((id) => ObjectId.isValid(id)),
    ),
  ).map((id) => new ObjectId(id));

  const rentalImageByRacketId = new Map<string, string | null>();

  if (rentalRacketObjectIds.length > 0) {
    const usedRackets = await db
      .collection("used_rackets")
      .find(
        { _id: { $in: rentalRacketObjectIds } },
        { projection: { images: 1, image: 1, thumbnail: 1, thumbnailUrl: 1 } },
      )
      .toArray();

    for (const racket of usedRackets as any[]) {
      rentalImageByRacketId.set(String(racket._id), pickUsedRacketImage(racket));
    }
  }

  const todayYmd = toKstYmd();

  const [reviewBundlesByOrderId, reviewBundlesByRentalId, reviewBundlesByApplicationId] =
    await Promise.all([
      resolveOrderReviewTargetBundlesBatch(db, userId, orders as any[]),
      resolveRentalReviewTargetBundlesBatch(db, userId, rentals as any[]),
      resolveApplicationReviewTargetBundlesBatch(db, userId, standaloneApps as any[]),
    ]);

  // 6) 그룹 생성(주문/대여 + 단독신청)
  const groups: ActivityGroup[] = [];

  for (const o of orders as any[]) {
    const orderId = String(o._id);
    const items = Array.isArray(o.items) ? o.items : [];
    const first = items[0] ?? null;
    const isConfirmed = Boolean(o?.userConfirmedAt) || isOrderConfirmedStatus(o?.status);
    const applicationHistory = appByOrderId.get(orderId) ?? [];
    const linkedApps = activeApplications(applicationHistory);
    const targetBundle = reviewBundlesByOrderId.get(orderId);
    const nextTarget = targetBundle?.nextTarget ?? null;
    const reviewPendingCount = isConfirmed ? (targetBundle?.counts.remaining ?? 0) : 0;
    const reviewAllDone = Boolean(targetBundle?.allReviewed);
    const reviewNextTargetProductId: string | null = nextTarget?.primaryProductId ?? null;
    const reviewNextApplicationId: string | null = nextTarget?.primaryApplicationId ?? null;
    const reviewContext: string | null =
      nextTarget?.reviewContext ?? targetBundle?.targets[0]?.reviewContext ?? "product";
    const hasPendingReview = reviewPendingCount > 0;

    const linked = pickPrimaryLinkedApplication(linkedApps);
    const hasRacketItem = items.some(
      (item: any) => item?.kind === "racket" || item?.kind === "used_racket",
    );
    const hasStringItem = items.some((item: any) => item?.kind === "string");
    const hasProductItem = items.some(
      (item: any) => !["racket", "used_racket", "string"].includes(String(item?.kind ?? "")),
    );

    const rawCancelStatus = o?.cancelRequest?.status ?? null;
    let cancelReasonSummary: string | null = null;
    const reasonCode = o?.cancelRequest?.reasonCode;
    const reasonText = o?.cancelRequest?.reasonText;
    if (reasonCode) cancelReasonSummary = reasonCode + (reasonText ? ` (${reasonText})` : "");
    else if (reasonText) cancelReasonSummary = reasonText;

    const withStringService = Boolean(o?.shippingInfo?.withStringService);
    const paymentStatus = resolveRawPaymentStatus(o);
    const paymentMethod = resolvePaymentMethod(o);
    const paymentProvider = resolvePaymentProvider(o);
    const totalPrice = calcOrderTotal(o);
    const createdAt = toISO(o.createdAt ?? new ObjectId(o._id).getTimestamp());
    const updatedAt = toISO(o.updatedAt ?? o.createdAt ?? new ObjectId(o._id).getTimestamp());
    const sortAt = isoMax(updatedAt, createdAt, linked?.updatedAt, linked?.createdAt);

    groups.push({
      key: `order:${orderId}`,
      kind: "order",
      sortAt,
      flowType: linkedApps.length > 0 ? "order_plus_stringing" : "order_only",
      flowLabel: getOrderFlowLabel({
        hasRacketItem,
        hasStringItem,
        hasProductItem,
        linkedApplicationCount: linkedApps.length,
      }),
      detailTarget: {
        type: "order",
        id: orderId,
      },
      todoReasonCode: null,
      order: {
        id: orderId,
        createdAt,
        updatedAt,
        status: o.status ?? "",
        userConfirmedAt:
          o.userConfirmedAt instanceof Date
            ? o.userConfirmedAt.toISOString()
            : typeof o.userConfirmedAt === "string"
              ? o.userConfirmedAt
              : null,
        paymentStatus,
        paymentStatusLabel: getCustomerTransactionPaymentStatusLabel({
          paymentStatus,
          paymentMethod,
          paymentProvider,
          totalPrice,
        }),
        paymentProvider,
        paymentMethod,
        shippingMethod: resolveOrderShippingMethod(o?.shippingInfo),
        totalPrice,
        firstItemName: first?.name ?? "(상품명 없음)",
        firstItemImageUrl: pickOrderItemImage(first),
        itemsCount: items.length,
        withStringService,
        stringingApplicationIds: linkedApps.map((app) => app.id),
        applicationSummaries: linkedApps,
        applicationHistorySummaries: applicationHistory,
        stringingApplicationId: linked?.id ?? null,
        cancelStatus: rawCancelStatus,
        cancelReasonSummary,
        hasRacketItem,
        hasStringItem,
        hasProductItem,
        linkedApplicationCount: linkedApps.length,
        hasActiveStringingApplication: linkedApps.length > 0,
        reviewPendingCount,
        hasPendingReview,
        reviewAllDone,
        reviewNextTargetProductId,
        reviewNextApplicationId,
        reviewContext,
        reviewTargetBundle: targetBundle ?? null,
        nextReviewTarget: nextTarget ?? null,
      },
      application: linked, // 연결 신청서가 있으면 같이 내려줌(카드에서 CTA 가능)
    });
  }

  for (const r of rentals as any[]) {
    const rentalId = String(r._id);
    const applicationHistory = appByRentalId.get(rentalId) ?? [];
    const linkedApps = activeApplications(applicationHistory);
    const linked = pickPrimaryLinkedApplication(linkedApps);

    const createdAt = toISO(r.createdAt ?? new ObjectId(r._id).getTimestamp());
    const updatedAt = toISO(r.updatedAt ?? r.createdAt ?? new ObjectId(r._id).getTimestamp());
    const sortAt = isoMax(updatedAt, createdAt, linked?.updatedAt, linked?.createdAt);

    const withStringService =
      Boolean(r?.stringing?.requested) || Boolean(r?.stringingApplicationId);
    const paymentStatus = resolveRawPaymentStatus(r);
    const paymentMethod = resolvePaymentMethod(r);
    const paymentProvider = resolvePaymentProvider(r);
    const totalAmount = toNullableFiniteNumber(r?.amount?.total);
    const outboundTracking =
      typeof r?.shipping?.outbound?.trackingNumber === "string"
        ? r.shipping.outbound.trackingNumber.trim()
        : "";
    const hasReturnTracking = hasRentalReturnShipping(r?.shipping);
    const returnShippingWindowOpen = isRentalReturnShippingRegistrationRequired({
      status: r.status ?? "",
      dueAt: r?.dueAt ?? null,
      returnedAt: r?.returnedAt ?? null,
      hasReturnShipping: false,
      todayYmd,
    });

    groups.push({
      key: `rental:${rentalId}`,
      kind: "rental",
      sortAt,
      flowType: linkedApps.length > 0 ? "rental_plus_stringing" : "rental_only",
      flowLabel: linkedApps.length > 0 ? "라켓 대여 + 교체서비스" : "라켓 대여",
      detailTarget: {
        type: "rental",
        id: rentalId,
      },
      todoReasonCode: null,
      rental: {
        id: rentalId,
        createdAt,
        updatedAt,
        status: r.status ?? "",
        userConfirmedAt:
          r.userConfirmedAt instanceof Date
            ? r.userConfirmedAt.toISOString()
            : typeof r.userConfirmedAt === "string"
              ? r.userConfirmedAt
              : null,
        shippingMethod: String(r?.shipping?.shippingMethod ?? ""),
        racketId: r.racketId ? String(r.racketId) : null,
        brand: r.brand,
        model: r.model,
        imageUrl: r.racketId ? (rentalImageByRacketId.get(String(r.racketId)) ?? null) : null,
        days: r.days,
        totalAmount: r?.amount?.total,
        paymentStatus,
        paymentStatusLabel: getCustomerTransactionPaymentStatusLabel({
          paymentStatus,
          paymentMethod,
          paymentProvider,
          totalPrice: totalAmount,
        }),
        paymentProvider,
        paymentMethod,
        deposit: r?.amount?.deposit,
        fee: r?.amount?.fee,
        withStringService,
        hasOutboundShipping: Boolean(outboundTracking),
        outboundTrackingNumber: outboundTracking || null,
        dueAt: r?.dueAt ? toISO(r.dueAt) : null,
        returnedAt: r?.returnedAt ? toISO(r.returnedAt) : null,
        hasReturnShipping: hasReturnTracking,
        returnShippingWindowOpen,
        stringingApplicationIds: linkedApps.map((app) => app.id),
        applicationSummaries: linkedApps,
        applicationHistorySummaries: applicationHistory,
        stringingApplicationId: linked?.id ?? null,
        cancelStatus: r?.cancelRequest?.status ?? null,
        linkedApplicationCount: linkedApps.length,
        reviewContext:
          reviewBundlesByRentalId.get(rentalId)?.nextTarget?.reviewContext ??
          reviewBundlesByRentalId.get(rentalId)?.targets[0]?.reviewContext ??
          null,
        reviewPendingCount: reviewBundlesByRentalId.get(rentalId)?.counts.remaining ?? 0,
        reviewAllDone: Boolean(reviewBundlesByRentalId.get(rentalId)?.allReviewed),
        reviewNextTargetProductId:
          reviewBundlesByRentalId.get(rentalId)?.nextTarget?.primaryProductId ?? null,
        reviewNextApplicationId:
          reviewBundlesByRentalId.get(rentalId)?.nextTarget?.primaryApplicationId ?? null,
        reviewNextRacketId:
          reviewBundlesByRentalId.get(rentalId)?.nextTarget?.primaryRacketId ?? null,
        reviewTargetBundle: reviewBundlesByRentalId.get(rentalId) ?? null,
        nextReviewTarget: reviewBundlesByRentalId.get(rentalId)?.nextTarget ?? null,
      },
      application: linked,
    });
  }

  // 단독 신청서는 “그 자체가 하나의 그룹”
  for (const doc of standaloneApps as any[]) {
    const details = doc.stringDetails ?? {};
    const shipping = doc.shippingInfo ?? {};
    const hasTracking = Boolean(getTrackingNoFromShippingInfo(shipping));

    // 단독 신청서는 기본적으로 "고객 라켓 입고"가 필요
    const collectionMethod = normalizeCollection(
      (shipping as any)?.collectionMethod ?? (doc as any)?.collectionMethod ?? "self_ship",
    );
    const inboundRequired = true;
    const needsInboundTracking = inboundRequired && collectionMethod === "self_ship";

    const rawCancelStatus = doc?.cancelRequest?.status ?? null;
    let cancelReasonSummary: string | null = null;
    const reasonCode = doc?.cancelRequest?.reasonCode;
    const reasonText = doc?.cancelRequest?.reasonText;
    if (reasonCode) cancelReasonSummary = reasonCode + (reasonText ? ` (${reasonText})` : "");
    else if (reasonText) cancelReasonSummary = reasonText;

    const createdAt = toISO(doc.appliedAt ?? doc.createdAt ?? new ObjectId(doc._id).getTimestamp());
    const updatedAt = toISO(
      doc.updatedAt ?? doc.appliedAt ?? doc.createdAt ?? new ObjectId(doc._id).getTimestamp(),
    );
    const sortAt = isoMax(updatedAt, createdAt);
    const paymentContext = resolveStringingPaymentContext(doc);
    const stringSelection = summarizeStringSelection(doc);
    groups.push({
      key: `application:${String(doc._id)}`,
      kind: "application",
      sortAt,
      flowType: "application_only",
      flowLabel: "교체서비스 단독 신청",
      detailTarget: {
        type: "application",
        id: String(doc._id),
      },
      todoReasonCode: null,
      application: {
        id: String(doc._id),
        createdAt,
        updatedAt,
        status: doc.status ?? "접수",
        racketType: summarizeRacketType(details),
        orderId: doc.orderId ? String(doc.orderId) : null,
        rentalId: doc.rentalId ? String(doc.rentalId) : null,
        hasTracking,
        userConfirmedAt:
          doc.userConfirmedAt instanceof Date
            ? doc.userConfirmedAt.toISOString()
            : typeof doc.userConfirmedAt === "string"
              ? doc.userConfirmedAt
              : null,
        cancelStatus: rawCancelStatus,
        cancelReasonSummary,
        inboundRequired,
        needsInboundTracking,
        collectionMethod,
        packageApplied: paymentContext.packageApplied,
        paymentStatus: paymentContext.paymentStatus,
        paymentProvider: paymentContext.paymentProvider,
        serviceReviewPending:
          (reviewBundlesByApplicationId.get(String(doc._id))?.counts.remaining ?? 0) > 0,
        reviewContext:
          reviewBundlesByApplicationId.get(String(doc._id))?.nextTarget?.reviewContext ??
          reviewBundlesByApplicationId.get(String(doc._id))?.targets[0]?.reviewContext ??
          null,
        reviewPendingCount:
          reviewBundlesByApplicationId.get(String(doc._id))?.counts.remaining ?? 0,
        reviewAllDone: Boolean(reviewBundlesByApplicationId.get(String(doc._id))?.allReviewed),
        reviewNextTargetProductId:
          reviewBundlesByApplicationId.get(String(doc._id))?.nextTarget?.primaryProductId ?? null,
        reviewNextApplicationId:
          reviewBundlesByApplicationId.get(String(doc._id))?.nextTarget?.primaryApplicationId ??
          null,
        reviewTargetBundle: reviewBundlesByApplicationId.get(String(doc._id)) ?? null,
        nextReviewTarget: reviewBundlesByApplicationId.get(String(doc._id))?.nextTarget ?? null,
        ...stringSelection,
      },
    });
  }

  const groupsWithTodoReason = groups.map((group): ActivityGroup => {
    if (group.kind === "application") {
      return { ...group, todoReasonCode: resolveApplicationTodoReason(group.application) };
    }
    if (group.kind === "order") {
      return {
        ...group,
        todoReasonCode: resolveOrderTodoReason({
          status: group.order?.status,
          userConfirmedAt: group.order?.userConfirmedAt,
          reviewPendingCount: group.order?.reviewPendingCount,
          linkedApplications: group.order?.applicationSummaries,
          primaryApplication: group.application,
          withStringService: group.order?.withStringService,
        }),
      };
    }
    return {
      ...group,
      todoReasonCode: resolveRentalTodoReason({
        status: group.rental?.status,
        userConfirmedAt: group.rental?.userConfirmedAt,
        dueAt: group.rental?.dueAt ?? null,
        returnedAt: group.rental?.returnedAt ?? null,
        hasReturnShipping: group.rental?.hasReturnShipping,
        todayYmd,
        linkedApplications: group.rental?.applicationSummaries,
        primaryApplication: group.application,
        reviewPendingCount: group.rental?.reviewPendingCount,
        stringingApplicationId: group.rental?.stringingApplicationId,
        withStringService: group.rental?.withStringService,
      }),
    };
  });

  // 7) scope 필터 + 정렬 + 페이지 슬라이스
  const scopedGroups = groupsWithTodoReason.filter((group) => {
    if (scope === "all") return true;
    if (scope === "order") return group.kind === "order";
    if (scope === "rental") return group.kind === "rental";
    if (scope === "application") return group.kind === "application" || Boolean(group.application);

    if (scope === "todo") {
      return group.todoReasonCode !== null;
    }

    return true;
  });

  scopedGroups.sort((a, b) => new Date(b.sortAt).getTime() - new Date(a.sortAt).getTime());
  const paged = scopedGroups.slice(skip, skip + pageSize);

  return NextResponse.json({
    page,
    pageSize,
    total: scopedGroups.length,
    items: paged,
  });
}
