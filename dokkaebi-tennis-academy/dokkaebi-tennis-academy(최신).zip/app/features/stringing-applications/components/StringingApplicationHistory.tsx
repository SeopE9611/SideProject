'use client';

import React, { useState, useEffect } from 'react';
import useSWR from 'swr';
import { Card, CardHeader, CardContent, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Clock, CheckCircle, XCircle, Search, ClipboardCheck, Edit2, MessageSquare, DollarSign, User, Truck, Package, Calendar } from 'lucide-react';

const LIMIT = 5;
const fetcher = (url: string) => fetch(url, { credentials: 'include' }).then((res) => res.json());

function getIconProps(status: string) {
  switch (status.trim()) {
    // 기본 신청 상태
    case '접수완료':
    case '접수 완료':
      return {
        Icon: ClipboardCheck,
        wrapperClasses: 'border-yellow-300 bg-yellow-100 ' + 'dark:border-yellow-500/40 dark:bg-yellow-500/10',
        iconClasses: 'text-yellow-700 dark:text-yellow-300',
      };

    case '검토 중':
      return {
        Icon: Search,
        wrapperClasses: 'border-blue-300 bg-blue-100 ' + 'dark:border-blue-500/40 dark:bg-blue-500/10',
        iconClasses: 'text-blue-700 dark:text-blue-300',
      };
    case '작업 중':
      return {
        Icon: Edit2,
        wrapperClasses: 'border-indigo-300 bg-indigo-100 ' + 'dark:border-indigo-500/40 dark:bg-indigo-500/10',
        iconClasses: 'text-indigo-700 dark:text-indigo-300',
      };
    case '교체완료':
    case '교체 완료':
      return {
        Icon: CheckCircle,
        wrapperClasses: 'border-green-300 bg-green-100 ' + 'dark:border-green-500/40 dark:bg-green-500/10',
        iconClasses: 'text-green-700 dark:text-green-300',
      };
    case '취소':
      return {
        Icon: XCircle,
        wrapperClasses: 'border-red-300 bg-red-100 ' + 'dark:border-red-500/40 dark:bg-red-500/10',
        iconClasses: 'text-red-700 dark:text-red-300',
      };

    // 커스텀 이력 항목
    // 커스텀 이력 항목
    case '고객정보수정':
      return {
        Icon: User,
        wrapperClasses: 'border-purple-300 bg-purple-100 ' + 'dark:border-purple-500/40 dark:bg-purple-500/10',
        iconClasses: 'text-purple-700 dark:text-purple-300',
      };
    case '요청사항 수정':
      return {
        Icon: MessageSquare,
        wrapperClasses: 'border-indigo-300 bg-indigo-100 ' + 'dark:border-indigo-500/40 dark:bg-indigo-500/10',
        iconClasses: 'text-indigo-700 dark:text-indigo-300',
      };
    case '스트링 정보 수정':
      return {
        Icon: Edit2,
        wrapperClasses: 'border-blue-300 bg-blue-100 ' + 'dark:border-blue-500/40 dark:bg-blue-500/10',
        iconClasses: 'text-blue-700 dark:text-blue-300',
      };
    case '결제 금액 자동 업데이트':
      return {
        Icon: DollarSign,
        wrapperClasses: 'border-green-300 bg-green-100 ' + 'dark:border-green-500/40 dark:bg-green-500/10',
        iconClasses: 'text-green-700 dark:text-green-300',
      };

    // 자가 발송(사용자 → 매장) 운송장 관련
    case '자가발송 운송장 등록':
    case '자가발송 운송장 수정':
      return {
        Icon: Truck,
        wrapperClasses: 'border-teal-300 bg-teal-100 ' + 'dark:border-teal-500/40 dark:bg-teal-500/10',
        iconClasses: 'text-teal-700 dark:text-teal-300',
      };

    // 매장 발송(매장 → 사용자) 운송장 관련
    case '매장 발송 운송장 등록':
    case '매장 발송 운송장 수정':
      return {
        Icon: Package,
        wrapperClasses: 'border-blue-300 bg-blue-100 ' + 'dark:border-blue-500/40 dark:bg-blue-500/10',
        iconClasses: 'text-blue-700 dark:text-blue-300',
      };
    // 매장 발송 정보(방식/예정일/운송장 통합 로그)
    case '매장 발송 정보 등록':
    case '매장 발송 정보 수정':
      return {
        Icon: Clock,
        wrapperClasses: 'border-slate-300 bg-slate-100 ' + 'dark:border-slate-500/40 dark:bg-slate-700/20',
        iconClasses: 'text-slate-700 dark:text-slate-200',
      };

    // default
    default:
      return {
        Icon: Clock,
        wrapperClasses: 'border-gray-300 bg-gray-100 ' + 'dark:border-slate-600/50 dark:bg-slate-700/30',
        iconClasses: 'text-gray-700 dark:text-slate-300',
      };
  }
}

interface HistoryItem {
  status: string;
  date: string;
  description: string;
}

interface HistoryResponse {
  history: HistoryItem[];
  total: number;
}

export default function StringingApplicationHistory({ applicationId, onHistoryMutate }: { applicationId: string; onHistoryMutate?: (mutateFn: () => Promise<any>) => void }) {
  const [page, setPage] = useState(1);
  const url = `/api/applications/stringing/${applicationId}/history?page=${page}&limit=${LIMIT}`;

  const {
    data: res,
    isValidating,
    mutate: mutateHistory,
  } = useSWR<HistoryResponse>(url, fetcher, {
    revalidateOnFocus: false,
    revalidateOnReconnect: false,
  });

  useEffect(() => {
    if (onHistoryMutate) onHistoryMutate(mutateHistory);
  }, [mutateHistory, onHistoryMutate]);

  const isLoading = !res && isValidating;
  const history = res?.history ?? [];
  const total = res?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / LIMIT));

  const historyItems = [...history].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <Card className="md:col-span-3 rounded-xl border border-border/60 bg-card text-card-foreground shadow-md dark:bg-slate-900/60">
      <CardHeader className="pb-3 border-b border-border/60 bg-muted/30 dark:bg-slate-900/30 rounded-t-xl">
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5 text-indigo-600" />
          <CardTitle className="text-2xl font-semibold">처리 이력</CardTitle>
        </div>

        <p className="mt-1 text-sm text-muted-foreground">최신 변경이 맨 위에 표시됩니다.</p>
      </CardHeader>

      <CardContent>
        {isLoading ? (
          Array.from({ length: LIMIT }).map((_, i) => (
            <div key={i} className="flex animate-pulse space-x-4 py-3">
              <div className="h-10 w-10 rounded-full bg-muted" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-1/3" />
                <Skeleton className="h-4 w-full" />
              </div>
            </div>
          ))
        ) : historyItems.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground">아직 처리 이력이 없습니다.</div>
        ) : (
          historyItems.map((log, idx) => {
            const { Icon, wrapperClasses, iconClasses } = getIconProps(log.status);
            return (
              <div key={idx} className={`flex space-x-4 py-3 ${idx === 0 ? 'rounded-lg bg-slate-50/80 dark:bg-slate-900/40 px-3 -mx-3' : ''}`}>
                <div className={`h-10 w-10 flex items-center justify-center rounded-full border ${wrapperClasses}`}>
                  <Icon className={`h-6 w-6 ${iconClasses}`} />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <span className="font-semibold">{log.status}</span>
                    <span className="text-sm text-muted-foreground">
                      {new Intl.DateTimeFormat('ko-KR', {
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                      }).format(new Date(log.date))}
                    </span>
                  </div>
                  {(() => {
                    // "문장 (추가정보...)" 형태를 앞/뒤로 나누기
                    const [main, detailWithParen] = log.description.split('(', 2);
                    const detail = detailWithParen ? detailWithParen.replace(/\)$/, '') : '';

                    return (
                      <p className="mt-1 text-sm text-slate-700 dark:text-slate-300">
                        {main?.trim()}
                        {detail && <span className="ml-1 font-medium text-blue-600 dark:text-blue-300">({detail})</span>}
                      </p>
                    );
                  })()}
                </div>
              </div>
            );
          })
        )}

        {totalPages > 1 && (
          <div className="mt-6 flex justify-center gap-3">
            <Button size="sm" variant="outline" disabled={page === 1} onClick={() => setPage(page - 1)}>
              이전
            </Button>
            <span className="text-sm text-muted-foreground">
              {page} / {totalPages}
            </span>
            <Button size="sm" variant="outline" disabled={page === totalPages} onClick={() => setPage(page + 1)}>
              다음
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
