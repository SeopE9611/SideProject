import AdminRacketsClient from '@/app/admin/rackets/_components/AdminRacketsClient';

export const dynamic = 'force-dynamic';
export default function Page() {
  return <AdminRacketsClient />;
}
