import BoardsPageClient from '@/app/admin/boards/BoardsClient';

export default async function BoardsPage() {
  return <BoardsPageClient />;
}
