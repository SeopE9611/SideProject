// 'use client';

// import { OrderCancelButton } from './OrderCancelButton';

// export default function OrderCancelButtonClient({ orderId, alreadyCancelledReason }: { orderId: string; alreadyCancelledReason?: string | null }) {
//   return <OrderCancelButton orderId={orderId} alreadyCancelledReason={alreadyCancelledReason} />;
// }
// // 혹시몰라서 안지움
