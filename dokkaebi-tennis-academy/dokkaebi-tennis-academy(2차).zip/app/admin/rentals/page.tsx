import AdminRentalsClient from '@/app/admin/rentals/_components/AdminRentalsClient';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <AdminRentalsClient />;
}
