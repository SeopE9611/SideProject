'use client';
import NotFound from '@/components/system/NotFound';
export default NotFound;
