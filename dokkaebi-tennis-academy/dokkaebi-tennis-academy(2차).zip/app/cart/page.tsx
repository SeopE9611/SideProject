'use client';

import CartPageClient from '@/app/cart/CartPageClient';

export default function CartPage() {
  return <CartPageClient />;
}
