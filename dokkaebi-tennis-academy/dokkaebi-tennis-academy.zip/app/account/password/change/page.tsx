import ForceChangePasswordClient from '@/app/account/password/change/_components/ForceChangePasswordClient';

export default function Page() {
  return <ForceChangePasswordClient />;
}
