'use client';

import { useMemo, useState } from 'react';
import useSWR from 'swr';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Eye, EyeOff, RefreshCcw, ShieldAlert, CheckCircle2, XCircle, ExternalLink, MessageSquare, ThumbsUp, BarChart3, FileText, AlertTriangle } from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { showErrorToast, showSuccessToast } from '@/lib/toast';

type PostItem = {
  id: string;
  type: string;
  postNo: number | null;
  title: string;
  nickname: string;
  status: 'public' | 'hidden';
  createdAt: string;
  viewCount: number;
  likeCount: number;
  commentsCount: number;
};

type ReportItem = {
  id: string;
  targetType: 'post' | 'comment';
  boardType: string;
  reason: string;
  status: 'pending' | 'resolved' | 'rejected';
  reporterNickname: string;
  createdAt: string;
  resolvedAt: string | null;
  post: { id: string | null; title: string; postNo: number | null; status: string } | null;
  comment: { id: string | null; content: string; nickname: string; status: string } | null;
};

const fetcher = async (url: string) => {
  const res = await fetch(url);
  if (!res.ok) throw new Error(await res.text().catch(() => 'Request failed'));
  return res.json();
};

const boardLabel: Record<string, string> = {
  notice: '공지',
  qna: 'Q&A',
  free: '자유',
  gear: '장비',
  market: '중고',
  hot: '인기',
  brands: '브랜드',
};

function fmt(dt: string) {
  try {
    return new Date(dt).toLocaleString('ko-KR');
  } catch {
    return dt;
  }
}

const LIMIT = 20;

export default function BoardsClient() {
  const router = useRouter();
  const sp = useSearchParams();

  const tab = sp.get('tab') === 'reports' ? 'reports' : 'posts';

  // 게시글 필터
  const [postType, setPostType] = useState<string>('all');
  const [postStatus, setPostStatus] = useState<string>('all');
  const [postQ, setPostQ] = useState<string>('');
  const [postPage, setPostPage] = useState<number>(1);

  // 신고 필터
  const [reportType, setReportType] = useState<string>('all');
  const [reportStatus, setReportStatus] = useState<string>('pending');
  const [reportQ, setReportQ] = useState<string>('');
  const [reportPage, setReportPage] = useState<number>(1);

  const postsUrl = useMemo(() => {
    const qs = new URLSearchParams({
      page: String(postPage),
      limit: String(LIMIT),
      type: postType,
      status: postStatus,
      q: postQ,
      sort: 'createdAt',
      dir: 'desc',
    });
    return `/api/admin/community/posts?${qs.toString()}`;
  }, [postPage, postType, postStatus, postQ]);

  const reportsUrl = useMemo(() => {
    const qs = new URLSearchParams({
      page: String(reportPage),
      limit: String(LIMIT),
      boardType: reportType,
      status: reportStatus,
      q: reportQ,
    });
    return `/api/admin/community/reports?${qs.toString()}`;
  }, [reportPage, reportType, reportStatus, reportQ]);

  const { data: postsData, error: postsErr, isLoading: postsLoading, mutate: mutatePosts } = useSWR(tab === 'posts' ? postsUrl : null, fetcher);

  const { data: reportsData, error: reportsErr, isLoading: reportsLoading, mutate: mutateReports } = useSWR(tab === 'reports' ? reportsUrl : null, fetcher);

  const posts: PostItem[] = postsData?.items ?? [];
  const postsTotal: number = postsData?.total ?? 0;
  const postsTotalPages = Math.max(1, Math.ceil(postsTotal / LIMIT));

  const reports: ReportItem[] = reportsData?.items ?? [];
  const reportsTotal: number = reportsData?.total ?? 0;
  const reportsTotalPages = Math.max(1, Math.ceil(reportsTotal / LIMIT));

  const switchTab = (next: 'posts' | 'reports') => {
    const qs = new URLSearchParams(sp.toString());
    if (next === 'reports') qs.set('tab', 'reports');
    else qs.delete('tab');
    router.replace(`/admin/boards?${qs.toString()}`);
  };

  const togglePostVisibility = async (p: PostItem) => {
    try {
      const next = p.status === 'public' ? 'hidden' : 'public';
      const res = await fetch(`/api/admin/community/posts/${p.id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: next }),
      });
      if (!res.ok) throw new Error(await res.text());
      showSuccessToast(next === 'hidden' ? '게시글을 숨김 처리했습니다.' : '게시글을 공개 처리했습니다.');
      mutatePosts();
    } catch (e: any) {
      showErrorToast(e?.message ?? '상태 변경 실패');
    }
  };

  const processReport = async (r: ReportItem, action: 'resolve' | 'reject' | 'resolve_hide_target') => {
    try {
      const res = await fetch(`/api/admin/community/reports/${r.id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      if (!res.ok) throw new Error(await res.text());
      showSuccessToast('신고 처리가 완료되었습니다.');
      mutateReports();
      // 대상 숨김까지 했다면 게시글 목록도 최신화하는 게 안전
      mutatePosts();
    } catch (e: any) {
      showErrorToast(e?.message ?? '신고 처리 실패');
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="grid gap-5 md:grid-cols-4">
        <Card className="border-border/40 bg-card/50 backdrop-blur hover:border-border/60 transition-all duration-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-500/10">
                <FileText className="h-6 w-6 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">전체 게시글</p>
                <p className="text-2xl font-bold">{postsTotal.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/40 bg-card/50 backdrop-blur hover:border-border/60 transition-all duration-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/10">
                <Eye className="h-6 w-6 text-emerald-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">공개 게시글</p>
                <p className="text-2xl font-bold">{posts.filter((p) => p.status === 'public').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/40 bg-card/50 backdrop-blur hover:border-border/60 transition-all duration-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-red-500/10">
                <AlertTriangle className="h-6 w-6 text-red-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">대기 중 신고</p>
                <p className="text-2xl font-bold">{reports.filter((r) => r.status === 'pending').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/40 bg-card/50 backdrop-blur hover:border-border/60 transition-all duration-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-500/10">
                <EyeOff className="h-6 w-6 text-amber-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">숨김 게시글</p>
                <p className="text-2xl font-bold">{posts.filter((p) => p.status === 'hidden').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/40 bg-card/50 backdrop-blur">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-6">
          <div>
            <CardTitle className="text-2xl">게시판 관리</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">커뮤니티 게시글 및 신고 관리</p>
          </div>

          <Tabs value={tab} onValueChange={(v) => switchTab(v as any)}>
            <TabsList className="bg-muted/50">
              <TabsTrigger value="posts" className="gap-2">
                <FileText className="h-4 w-4" />
                게시글
              </TabsTrigger>
              <TabsTrigger value="reports" className="gap-2">
                <ShieldAlert className="h-4 w-4" />
                신고
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>

        <CardContent>
          {tab === 'posts' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-3 p-4 rounded-lg border border-border/40 bg-muted/30">
                <Select value={postType} onValueChange={(v) => (setPostPage(1), setPostType(v))}>
                  <SelectTrigger className="w-[140px] bg-background/50">
                    <SelectValue placeholder="게시판" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체</SelectItem>
                    {Object.keys(boardLabel).map((k) => (
                      <SelectItem key={k} value={k}>
                        {boardLabel[k]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={postStatus} onValueChange={(v) => (setPostPage(1), setPostStatus(v))}>
                  <SelectTrigger className="w-[140px] bg-background/50">
                    <SelectValue placeholder="상태" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체</SelectItem>
                    <SelectItem value="public">공개</SelectItem>
                    <SelectItem value="hidden">숨김</SelectItem>
                  </SelectContent>
                </Select>

                <Input value={postQ} onChange={(e) => setPostQ(e.target.value)} placeholder="제목/작성자/내용 검색" className="w-[260px] bg-background/50" />

                <Button variant="outline" onClick={() => (setPostPage(1), mutatePosts())} className="gap-2">
                  <RefreshCcw className="h-4 w-4" />
                </Button>

                <div className="ml-auto text-sm font-medium">총 {postsTotal.toLocaleString()}건</div>
              </div>

              {postsLoading && (
                <div className="space-y-3">
                  <Skeleton className="h-32 w-full" />
                  <Skeleton className="h-32 w-full" />
                  <Skeleton className="h-32 w-full" />
                </div>
              )}

              {postsErr && <div className="p-4 rounded-lg border border-red-500/50 bg-red-500/10 text-red-600 dark:text-red-400 text-sm">게시글 목록 로드 실패: {(postsErr as any)?.message ?? 'error'}</div>}

              {!postsLoading && !postsErr && (
                <>
                  <div className="space-y-3">
                    {posts.map((p) => (
                      <Card key={p.id} className="group border-border/40 bg-background/50 backdrop-blur hover:border-border/60 hover:shadow-md transition-all duration-200">
                        <CardContent className="p-5">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1 space-y-2">
                              <div className="flex items-center gap-2 flex-wrap">
                                <Badge variant="outline" className="font-medium">
                                  {boardLabel[p.type] ?? p.type}
                                </Badge>
                                <span className="text-sm text-muted-foreground">#{p.postNo ?? '-'}</span>
                                {p.status === 'public' ? (
                                  <Badge className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30">공개</Badge>
                                ) : (
                                  <Badge className="bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30">숨김</Badge>
                                )}
                              </div>

                              <Link href={`/board/${p.type}/${p.postNo ?? ''}`} className="block group/link" target="_blank">
                                <h3 className="text-base font-semibold group-hover/link:text-primary transition-colors inline-flex items-center gap-2">
                                  {p.title}
                                  <ExternalLink className="h-4 w-4 opacity-0 group-hover/link:opacity-100 transition-opacity" />
                                </h3>
                              </Link>

                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <span className="font-medium">{p.nickname || '-'}</span>
                                <span>{fmt(p.createdAt)}</span>
                              </div>

                              <div className="flex items-center gap-4 text-sm">
                                <div className="flex items-center gap-1.5">
                                  <BarChart3 className="h-4 w-4 text-blue-500" />
                                  <span className="font-medium">{p.viewCount}</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <ThumbsUp className="h-4 w-4 text-emerald-500" />
                                  <span className="font-medium">{p.likeCount}</span>
                                </div>
                                <div className="flex items-center gap-1.5">
                                  <MessageSquare className="h-4 w-4 text-violet-500" />
                                  <span className="font-medium">{p.commentsCount}</span>
                                </div>
                              </div>
                            </div>

                            <Button variant="outline" size="sm" onClick={() => togglePostVisibility(p)} className="gap-2 shrink-0">
                              {p.status === 'public' ? (
                                <>
                                  <EyeOff className="h-4 w-4" />
                                  숨김
                                </>
                              ) : (
                                <>
                                  <Eye className="h-4 w-4" />
                                  공개
                                </>
                              )}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}

                    {posts.length === 0 && (
                      <Card className="border-dashed border-border/40">
                        <CardContent className="flex flex-col items-center justify-center py-16">
                          <FileText className="h-12 w-12 text-muted-foreground/50 mb-3" />
                          <p className="text-sm text-muted-foreground">표시할 게시글이 없습니다.</p>
                        </CardContent>
                      </Card>
                    )}
                  </div>

                  {posts.length > 0 && (
                    <div className="flex flex-col items-center justify-between gap-3 border-t border-border/40 pt-5 sm:flex-row">
                      <div className="text-sm text-muted-foreground">
                        총 <span className="font-semibold text-foreground">{postsTotal}</span>건 · 페이지 <span className="font-semibold text-foreground">{postPage}</span> / {postsTotalPages}
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm" onClick={() => setPostPage((p) => Math.max(1, p - 1))} disabled={postPage <= 1} className="border-border/40 hover:border-border/60">
                          이전
                        </Button>
                        <div className="flex h-9 items-center rounded-md border border-border/40 bg-background/50 px-3 text-sm font-medium">{postPage}</div>
                        <Button variant="outline" size="sm" onClick={() => setPostPage((p) => Math.min(postsTotalPages, p + 1))} disabled={postPage >= postsTotalPages} className="border-border/40 hover:border-border/60">
                          다음
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {tab === 'reports' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-3 p-4 rounded-lg border border-border/40 bg-muted/30">
                <Select value={reportType} onValueChange={(v) => (setReportPage(1), setReportType(v))}>
                  <SelectTrigger className="w-[140px] bg-background/50">
                    <SelectValue placeholder="게시판" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">전체</SelectItem>
                    {Object.keys(boardLabel).map((k) => (
                      <SelectItem key={k} value={k}>
                        {boardLabel[k]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={reportStatus} onValueChange={(v) => (setReportPage(1), setReportStatus(v))}>
                  <SelectTrigger className="w-[140px] bg-background/50">
                    <SelectValue placeholder="상태" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">대기</SelectItem>
                    <SelectItem value="resolved">완료</SelectItem>
                    <SelectItem value="rejected">반려</SelectItem>
                    <SelectItem value="all">전체</SelectItem>
                  </SelectContent>
                </Select>

                <Input value={reportQ} onChange={(e) => setReportQ(e.target.value)} placeholder="사유/신고자 검색" className="w-[260px] bg-background/50" />

                <Button variant="outline" onClick={() => (setReportPage(1), mutateReports())} className="gap-2">
                  <RefreshCcw className="h-4 w-4" />
                </Button>

                <div className="ml-auto text-sm font-medium">총 {reportsTotal.toLocaleString()}건</div>
              </div>

              {reportsLoading && (
                <div className="space-y-3">
                  <Skeleton className="h-40 w-full" />
                  <Skeleton className="h-40 w-full" />
                  <Skeleton className="h-40 w-full" />
                </div>
              )}

              {reportsErr && <div className="p-4 rounded-lg border border-red-500/50 bg-red-500/10 text-red-600 dark:text-red-400 text-sm">신고 목록 로드 실패: {(reportsErr as any)?.message ?? 'error'}</div>}

              {!reportsLoading && !reportsErr && (
                <>
                  <div className="space-y-3">
                    {reports.map((r) => {
                      const isPending = r.status === 'pending';
                      const postHref = r.post?.postNo != null ? `/board/${r.boardType}/${r.post.postNo}` : undefined;

                      return (
                        <Card
                          key={r.id}
                          className={`group border-border/40 bg-background/50 backdrop-blur hover:border-border/60 hover:shadow-md transition-all duration-200 ${
                            isPending ? 'border-red-500/30 dark:border-red-900/30 bg-red-500/5 dark:bg-red-950/10' : ''
                          }`}
                        >
                          <CardContent className="p-5">
                            <div className="space-y-4">
                              <div className="flex items-start justify-between gap-4">
                                <div className="flex-1 space-y-2">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    {r.targetType === 'post' ? (
                                      <Badge className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30">게시글</Badge>
                                    ) : (
                                      <Badge className="bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30">댓글</Badge>
                                    )}
                                    <Badge variant="outline" className="font-medium">
                                      {boardLabel[r.boardType] ?? r.boardType}
                                    </Badge>
                                    {r.status === 'pending' && <Badge className="bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/30">대기</Badge>}
                                    {r.status === 'resolved' && <Badge className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30">완료</Badge>}
                                    {r.status === 'rejected' && <Badge className="bg-gray-500/10 text-gray-600 dark:text-gray-400 border-gray-500/30">반려</Badge>}
                                  </div>

                                  <div>
                                    <p className="text-sm text-muted-foreground mb-1">신고 사유</p>
                                    <p className="text-base font-medium">{r.reason}</p>
                                  </div>

                                  <div>
                                    <p className="text-sm text-muted-foreground mb-1">신고 대상</p>
                                    {postHref ? (
                                      <Link href={postHref} target="_blank" className="inline-flex items-center gap-2 text-base hover:text-primary transition-colors group/link">
                                        {r.post?.title ?? '(제목 없음)'}
                                        <ExternalLink className="h-4 w-4 opacity-0 group-hover/link:opacity-100 transition-opacity" />
                                      </Link>
                                    ) : (
                                      <span className="text-base text-muted-foreground">(대상 글 정보 없음)</span>
                                    )}
                                  </div>

                                  <div className="flex items-center gap-4 text-sm text-muted-foreground pt-2">
                                    <span>
                                      신고자: <span className="font-medium">{r.reporterNickname || '-'}</span>
                                    </span>
                                    <span>{fmt(r.createdAt)}</span>
                                  </div>
                                </div>
                              </div>

                              <div className="flex flex-wrap gap-2 pt-2 border-t border-border/40">
                                <Button size="sm" variant="outline" disabled={!isPending} onClick={() => processReport(r, 'resolve')} className="gap-2">
                                  <CheckCircle2 className="h-4 w-4" />
                                  완료
                                </Button>

                                <Button size="sm" variant="outline" disabled={!isPending} onClick={() => processReport(r, 'reject')} className="gap-2">
                                  <XCircle className="h-4 w-4" />
                                  반려
                                </Button>

                                <Button size="sm" disabled={!isPending} onClick={() => processReport(r, 'resolve_hide_target')} className="gap-2 bg-red-600 hover:bg-red-700 text-white">
                                  <ShieldAlert className="h-4 w-4" />
                                  대상 숨김 + 완료
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}

                    {reports.length === 0 && (
                      <Card className="border-dashed border-border/40">
                        <CardContent className="flex flex-col items-center justify-center py-16">
                          <ShieldAlert className="h-12 w-12 text-muted-foreground/50 mb-3" />
                          <p className="text-sm text-muted-foreground">표시할 신고가 없습니다.</p>
                        </CardContent>
                      </Card>
                    )}
                  </div>

                  {reports.length > 0 && (
                    <div className="flex flex-col items-center justify-between gap-3 border-t border-border/40 pt-5 sm:flex-row">
                      <div className="text-sm text-muted-foreground">
                        총 <span className="font-semibold text-foreground">{reportsTotal}</span>건 · 페이지 <span className="font-semibold text-foreground">{reportPage}</span> / {reportsTotalPages}
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm" onClick={() => setReportPage((p) => Math.max(1, p - 1))} disabled={reportPage <= 1} className="border-border/40 hover:border-border/60">
                          이전
                        </Button>
                        <div className="flex h-9 items-center rounded-md border border-border/40 bg-background/50 px-3 text-sm font-medium">{reportPage}</div>
                        <Button variant="outline" size="sm" onClick={() => setReportPage((p) => Math.min(reportsTotalPages, p + 1))} disabled={reportPage >= reportsTotalPages} className="border-border/40 hover:border-border/60">
                          다음
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
