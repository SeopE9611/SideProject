import ProductsClient from '@/app/admin/products/ProductsClient';
import React from 'react';

export default function ProductsPage() {
  return <ProductsClient />;
}
