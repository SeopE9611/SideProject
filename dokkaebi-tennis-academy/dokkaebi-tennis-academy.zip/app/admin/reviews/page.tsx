import ReviewsClient from '@/app/admin/reviews/ReviewsClient';

export default async function ReviewsPage() {
  return <ReviewsClient />;
}
