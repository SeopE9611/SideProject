import AdminNotificationsClient from '@/app/admin/notifications/_components/AdminNotificationsClient';

export default function AdminNotificationsPage() {
  return (
    <div className="p-6">
      <AdminNotificationsClient />
    </div>
  );
}
