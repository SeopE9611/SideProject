import AdminRacketNewClient from '@/app/admin/rackets/new/_components/AdminRacketNewClient';

export const dynamic = 'force-dynamic';
export default function Page() {
  return <AdminRacketNewClient />;
}
