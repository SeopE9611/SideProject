import { CardGridSkeleton } from '@/components/system/PageLoading';

export default function Loading() {
  return <CardGridSkeleton />;
}
